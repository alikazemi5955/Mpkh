# Puzzle Kala 1.13.0 — Kasra Plus Live Catalog

## Scope
- Kasra Plus is the only operational supplier in this edition.
- Supplier catalog is polled every 5 minutes by default through the existing agent cycle.
- Available, price-bearing products are automatically imported, including mobile phones.
- Site price uses the approved supplier markup percentage (default 5%), applied once.
- A successfully fetched catalog that no longer contains an auto-imported product marks it out of stock; transient fetch failures do not.

## Important limitation
This is polling-based near-real-time sync, not instantaneous push. True event-level sync requires a supplier webhook/push feed. Live behavior also depends on Kasra Plus API availability and the shape/meaning of its stock fields.

## Verification
Static edits are applied. Run `npm install`, `npm run lint`, `npm test`, and `npm run build` in the deployment environment before replacing a live site.

> **نسخهٔ اصلاح‌شده:** برای رفع خطای واردکردن خودکار کالاها و تست‌های مخصوص کسری پلاس، از `HANDOFF-1.13.1-kasra-live.md` و نسخهٔ 1.13.1 استفاده کنید.
