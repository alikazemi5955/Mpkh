# Puzzle Kala — Handoff Notes (1.9.3)

## Purpose
This archive continues the existing Puzzle Kala project. It is not a rewrite and does not claim that the store is production-ready before deployment review.

## Changes in this package
- Version metadata aligned to 1.9.3.
- Product normalization treats stock count as authoritative. A zero/invalid stock count cannot be made purchasable merely by a truthy `inStock` value.
- Customer order creation rejects products marked out of stock and rejects invalid/non-positive prices and invalid stock values.
- Generic admin order edits cannot change payment/refund fields; those require dedicated, confirmed payment/refund workflows.
- Deleting an order through the existing admin endpoint now archives it and records an audit event instead of erasing the order/financial history.
- The project retains its current files and structure.
- Server-side order quote endpoint `/api/orders/quote` calculates totals from current product prices, active shipping tiers, and coupon configuration; client-provided totals are not trusted.
- Customer order creation now stores a snapshot of subtotal, discount, coupon, shipping method/tier, and total, and uses the same server-side calculations.
- Coupon validation checks active state, start/end dates, minimum order, usage limits, product eligibility, and maximum discount. Successful orders increment usage count.
- Admin bulk order synchronization preserves existing order identity, item/price/payment/refund snapshots and does not erase orders omitted from a sync payload; status changes are audit logged.
- Customer address book API supports listing, adding, updating, deleting, and selecting a default address. Existing order address snapshots are not rewritten when an address changes.
- Return-request APIs allow a customer to request a return after delivery and let an admin review/update its state. Return requests are stored separately from refund completion.


## Important operational boundaries
- Customer phone verification by SMS is not implemented merely because registration validates a phone number. Until an OTP provider/workflow is connected, `phoneVerified` must remain false.
- Payment and refund state must only be changed by a verified payment gateway callback or a controlled admin workflow that records the real manual action. Never infer payment from returning to the website.
- Supplier sync failures must not be interpreted as stock-out. Keep last valid supplier values with the last successful check time and expose the current check result separately.
- Supplier matching and supplier choice remain human-reviewed. No automatic purchase order, supplier choice, or publish-to-site action is enabled by this handoff.
- Configure a persistent writable data directory on the host. The default local JSON storage is not a substitute for backups or database-level concurrency controls.
- Use HTTPS in production, strong admin credentials, restricted environment secrets, and a correctly configured reverse proxy before collecting customer identity or payment information.

## Google AI Studio / hosting handoff
1. Upload or import the project archive into the existing Google AI Studio project; do not create a replacement project.
2. Preserve the current project and its environment variables. Do not put real API keys or supplier passwords into source files.
3. On the eventual host, configure a persistent `PUZZLEKALA_DATA_DIR`, `NODE_ENV=production`, and only the needed secret variables.
4. Review the README's startup and hosting notes against the actual host runtime. This project uses an Express server and Vite/React front end; it is not a static-only website.
5. Perform end-to-end checks after deployment, before opening the store to real customers.

## Added API routes in 1.9.3
- `POST /api/orders/quote` — server-side quote using current products, shipping tiers, and coupon rules.
- `GET/POST /api/account/addresses` — list and manage the authenticated customer's address book (`POST` uses `action: add|update|delete|default`).
- `GET/POST /api/returns` and `PUT /api/returns/:id` — customer return request and admin review flow.

## Remaining implementation areas
The Notion specification covers more than the changes in this handoff. Before launch, reconcile and complete: verified SMS OTP and safe account identity linking; persistent address book and order address snapshots; shipping/coupon UI integration and full validation of server-side shipping and coupon policy; payment gateway verification; real refund tracking; supplier source health/last-success data; role-scoped staff accounts; notification deduplication; return requests; production persistence/backups; and end-to-end order/payment/shipping flows.

## Current implementation boundary
- This is a further code-completion pass, not a test report. The requested deployment/host tests remain deferred until the user moves the project to hosting.
- OTP and payment/refund gateways remain unimplemented because the actual SMS provider and payment gateway/API credentials/configuration have not been specified. Registration must not be represented as phone-verified, and no payment success may be inferred from browser return alone.
- Shipping tiers are derived from the existing `settings.json`; method-specific tariffs should be configured explicitly before launch. The order quote API is available, but the existing checkout UI still needs to call it and display the returned values.
- JSON-file persistence is retained for compatibility with the current project; concurrent writes, durable database transactions, and production backup/restore still need a deployment design.

## Scope of this note
This file documents code changes and remaining gaps; it is not a test report and does not state that deployment, build, payment integration, or supplier integrations have been tested.
