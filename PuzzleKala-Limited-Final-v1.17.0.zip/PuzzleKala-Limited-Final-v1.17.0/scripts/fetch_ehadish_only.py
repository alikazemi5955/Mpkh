#!/usr/bin/env python3
# Deprecated legacy helper. Do not run this file: older revisions used fallback
# prices and only scraped a subset of categories. The current deployment candidate
# syncs the complete Ehadish sitemap through src/supplierEngine.ts and never invents
# a price when the source page has no valid price.

print("این اسکریپت قدیمی غیرفعال است. همگام‌سازی هدیش از داخل سرور پازل‌کالا انجام می‌شود.")
print("قیمت ساختگی تولید نمی‌شود و فایل products.json توسط این اسکریپت تغییر نمی‌کند.")
