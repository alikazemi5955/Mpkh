# Puzzle Kala v1.12.2 — Full-surface audit fixes

## Implemented
- Successful live supplier syncs append price/stock changes to `data/supplier_price_stock_history.json` (last 5,000 events retained).
- Price moves over 30% are tagged `needs_review`; this is a review flag, not automatic order cancellation or an automatic customer alert.
- Admin-only `GET /api/suppliers/price-stock-history` supports `productId`, `supplierId`, `anomaliesOnly=true`, and `limit` (1–500).
- Dry-run supplier preview does not write history.

## Validation and limitations
- Archive integrity is checked after packaging.
- Full TypeScript/build/test suite and live-host behavior are not verified in this environment because project dependencies are not installed.
- Ensure `PUZZLEKALA_DATA_DIR` points to persistent storage on the host; otherwise JSON history may be lost during redeploys.
- History is capped at 5,000 events; this is an initial lightweight JSON implementation, not a database-backed audit warehouse.


## اصلاحیه بازبینی 1.12.1

- رفع نقص: قبلاً تولید رویدادهای تاریخچه از `plannedChanges` محدودشده به ۵۰۰ مورد انجام می‌شد؛ بنابراین تغییرات بعد از ۵۰۰ محصول می‌توانستند از تاریخچه جا بمانند. اکنون تاریخچه از مجموعه کامل تغییرات ساخته می‌شود و سقف ۵۰۰ مورد فقط برای پاسخ API باقی مانده است.
- آزمون dry-run به فهرست فایل‌های تحت مراقبت `supplier_price_stock_history.json` را اضافه می‌کند تا عدم نوشتن تاریخچه در پیش‌نمایش نیز بررسی شود.
- اعتبارسنجی کامل خودکار انجام نشد: نصب وابستگی‌ها در محیط اجرا به مهلت برخورد کرد؛ `npm test`, `npm run lint`, `npm run build` هنوز اجرا/تأیید نشده‌اند. تست هاست همچنان برای زمان انتقال به هاست محفوظ است.


## اصلاحیه ممیزی سرتاسری 1.12.2

- عملیات ثبت/همگام‌سازی کالای داخلی، رکوردهای تأمین‌کننده را حفظ می‌کند و شناسه‌های آن‌ها را به شناسهٔ کالای داخلی تبدیل نمی‌کند.
- مسیر ویرایش کالای داخلی دیگر رکوردهای تأمین‌کننده را هدف نمی‌گیرد.
- تعداد سفارش در سرور به‌صورت عدد صحیح و مجموعِ تکرارهای یک کالا در برابر موجودی اعتبارسنجی می‌شود.
- در صورت وجود جدول تعرفه‌های ارسال، روش فاقد تعرفه رد می‌شود.
- دریافت تصویر بیرونی بدون redirect و با سقف حجم/قالب مشخص انجام می‌شود؛ قالب ذخیره‌شده در حالت بدون sharp با محتوای تصویر هماهنگ است.
- دستیار خرید موجودی گزینه‌های رنگ را نیز بررسی می‌کند.
- فایل JSON خراب/خالی برای بازیابی حفظ می‌شود؛ فایل موقت نوشتن نام یکتا دارد و فرادادهٔ حساس گزارش حسابرسی به‌صورت بازگشتی حذف می‌شود.
- تست‌های موجود و تازه‌شده با transpile محلی اجرا شدند: 49 تست موفق، 0 ناموفق. این اجرای جایگزین، build واقعی Vite/TypeScript و تست روی هاست نیست؛ وابستگی‌های npm در محیط ممیزی نصب نشدند.

## اصلاحیه ادامه ممیزی — نسخه 1.12.3

- پاک‌سازی محرمانگی به صورت بازگشتی برای فیلدهای تو‌در‌تو و نام‌های کلید متفاوت انجام می‌شود.
- محدودیت طول رمز و سقف حافظه محدودکننده ورود تقویت شد.
- تست sanitizer: ۲ موفق، ۰ ناموفق. `tsc --noEmit` به دلیل نبود `vite/client` در محیط اجرا کامل نشد؛ تست هاست هنوز طبق تصمیم کاربر به بعد از انتقال موکول است.


## نسخه 1.12.4 — تکمیل ممیزی امنیتی

- اصلاح افشای احتمالی فراداده داخلی تأمین‌کننده در خروجی عمومی دستیار خرید با استفاده از public product projection.
- اصلاح sanitizer: در عمق بیش از ۱۲ سطح دیگر شیء ورودی خام بازگردانده نمی‌شود؛ خروجی در این مرز null است تا اسرار عمیق تو‌در‌تو افشا نشوند.
- تست‌های تکمیلی به `tests/security-sanitizers.test.ts` و `tests/assistant-availability.test.ts` اضافه شد.
- build کامل وابستگی‌ها و آزمون زنده هاست همچنان باید جداگانه اجرا شود.

## نسخه 1.12.4 — تکمیل ممیزی امنیتی

- اصلاح افشای احتمالی فراداده داخلی تأمین‌کننده در خروجی عمومی دستیار خرید.
- اصلاح sanitizer برای جلوگیری از بازگشت شیء خام در عمق بیش از ۱۲ سطح.
- تست‌های مرتبط به sanitizer و projection عمومی کالا افزوده شد.
- build کامل و تست هاست به‌علت نبود وابستگی‌های npm در محیط فعلی تأیید نشده‌اند.

## نسخه 1.12.5 — محدودسازی حافظه rate-limit

- سقف سخت ۱۰٬۰۰۰ ورودی برای حافظهٔ rate-limit دستیار و ثبت هوشمند اضافه شد.
- توکن خام Authorization از کلیدهای Map حذف شد.
- در صورت فشار، ورودی‌های قدیمی/منقضی‌شده پاک می‌شوند؛ این محدودکننده همچنان درون‌فرآیندی است و برای چند سرور باید از ذخیره‌ساز مشترک استفاده شود.

## نسخه 1.12.6 — اصلاحات بازبینی ایستا
- تاریخ شروع/پایان نامعتبر کوپن دیگر به‌صورت خاموش نادیده گرفته نمی‌شود؛ اعتبارسنجی در صورت تاریخ نامعتبر fail-closed است.
- API عمومی کوپن فقط فیلدهای لازم برای نمایش/استفاده را می‌دهد؛ شمارنده و سقف استفاده و فراداده داخلی فقط برای مدیر برمی‌گردد. مسیر مدیر برای سازگاری با پنل، فهرست کامل را حفظ می‌کند.
- تغییر وضعیت سفارش از مسیر مدیر به گذارهای مجاز محدود شد تا سفارش تحویل‌شده/ارسال‌شده با درخواست معمولی به مرحله قبلی برنگردد.
- به‌روزرسانی تیکت از ورودی دلخواه جلوگیری می‌کند و فقط فیلدهای مشخص با وضعیت و اولویت مجاز را می‌پذیرد؛ پاسخ خالی رد می‌شود و طول متن محدود است.
- این نسخه حاصل بازبینی ایستای کد است؛ تست میزبانی، پرداخت واقعی، ارسال پیامک و یکپارچه‌سازی تأمین‌کنندگان اجرا نشده‌اند.
- محدودکنندهٔ درخواست دستیار دیگر در عبور از آستانه کل نقشهٔ rate limit را پاک نمی‌کند؛ ابتدا ورودی‌های منقضی را حذف و سپس اندازه را محدود می‌کند.


## نسخه 1.12.7 — بازبینی ایستای نهایی
- کلیدهای محرمانه با پیشوند و camelCase نیز پاک‌سازی می‌شوند.
- خروجی عمومی کالاها اطلاعات داخلی تأمین‌کننده را در تمام عمق حذف می‌کند.
- لغو عادی سفارش ارسال/تحویل‌شده مسدود شد؛ تأیید پرداخت سفارش لغوشده و تکمیل بازپرداخت کامل از وضعیت بازپرداخت جزئی مسدود شد.
- کیف پول: اعتبارسنجی کاربر/موجودی، شناسه UUID و بازگردانی best-effort در شکست دفتر تراکنش.
- اعتبارسنجی کدهای تخفیف و جلوگیری از کد تکراری بدون حساسیت به حروف کوچک/بزرگ.
- پورت از محیط خوانده می‌شود؛ حالت production بدون `dist/` خطای روشن 503 می‌دهد.
- گزارش کامل: `docs/audits/AUDIT-REPORT-v1.12.7-FA.md`.


## v1.12.8 API hardening (2026-10-26)
- `/api/settings` public output now uses an allowlist; admin output remains scrubbed full settings.
- Admin `POST /api/orders` validates items array, amount bounds, unique ID, and permitted initial status.
- `PUT /api/orders` SyncBridge path validates duplicate IDs/status transitions/new order snapshots, limits updates to operational metadata, and preserves immutable financial/order fields.
- `PUT /api/orders/:id` now accepts only an explicit set of operational fields.
- Official TypeScript build remains unverified because local dependency/type availability is incomplete.

## v1.12.8 — API hardening (2026-10-26)
- Public `/api/settings` response is allowlisted; unknown settings are private by default.
- Admin order creation and `PUT /api/orders` SyncBridge path validate order shape, ID uniqueness, allowed status, and monetary snapshots.
- Existing order sync now updates only permitted operational fields, preserving immutable order/financial snapshots.
- `PUT /api/orders/:id` now uses an explicit mutable-field allowlist.
- Added `src/orderWorkflowSafety.ts` and tests; 59 transpile-based tests passed.
- Full official TypeScript build and live-host verification are still pending.


## v1.12.9 — final static review pass (2026-10-26)

### Changes
- Validate order item snapshots on admin/manual and SyncBridge order creation; line items must have a valid product identifier, integer quantity from 1 to 100, positive finite unit price, at most 100 lines, and arithmetic subtotal matching the snapshot.
- Ensure default discount and shipping values are persisted as zero on privileged-created orders.
- Check order/coupon persistence outcomes during checkout and attempt an explicit rollback if coupon usage cannot be saved. Rollback success/failure is audit logged.
- Guard full manual refunds so they require a cancelled order or an explicit pending-refund state.
- Validate coupon percentage <= 100, minimum order amount, valid date strings, and start <= end at save time.
- Check JSON persistence results before reporting success on order, return and ticket updates.

### Verification
- 60 tests passed using TypeScript transpileModule (ES module output) followed by `node --test`.
- `node --check public/legacy/puzzlekala-ui.js` and `node --check public/virtual-employees-ui.js` passed.
- ZIP integrity check performed after packaging.
- Official `tsc --noEmit` remains blocked by missing `vite/client` type definitions; official Vite build, browser tests, payment/SMS integration tests, and hosting tests have not been verified.

### Remaining architectural risks
- JSON file writes are atomic per file only; there is no cross-file transaction or multi-process locking. Coupon usage and order creation are still not fully atomic across multiple server processes. For production correctness, migrate order, coupon, wallet and return state to a transactional database with constraints/idempotency keys.
- Static tests do not prove correct browser layout, real payment confirmation, OTP/SMS delivery, supplier website compatibility, or host-specific path/permission behavior.
