# PuzzleKala 1.14.0 — Kasra Plus + Ehadish

## Purpose
This is a separate deployment candidate based on the Kasra Plus edition. The full multi-supplier Puzzle Kala baseline is unchanged.

## Suppliers
- Kasra Plus remains enabled and uses its existing paginated API adapter.
- Ehadish is added as a second enabled supplier, sourced from `https://www.ehadish.com/` via the public sitemap and product pages.
- No other supplier is enabled in this edition.
- Ehadish iPhone handsets are excluded; other product categories and mobile accessories remain eligible.

## Ehadish catalog import
- The adapter reads product URLs from the sitemap (including sitemap-index child files), then parses the source product pages with bounded concurrency.
- A successful full crawl is cached for 15 minutes to avoid re-fetching the entire website during every 5-minute sync.
- A network failure on a product page invalidates the snapshot; stale 404 sitemap entries are skipped. An empty or unparseable catalog is not accepted as a successful sync.
- Source prices are required. The code does not invent fallback prices. Items with a real price are imported even when currently out of stock, but remain marked unavailable. Items with no parseable price are skipped until the source publishes one.
- Product IDs exposed to customers use a generated `prod-auto-<hash>` value. Supplier IDs remain in server-side linkage.
- After a successful complete feed, previously auto-imported items missing from that supplier's feed are marked unavailable, not deleted. Failed feeds preserve previous stock/pricing state.

## Pricing
- Uses the existing approved markup setting, default 5%, calculated from source price once.
- No repeated markup compounding is introduced.

## Verification limits
- Unit tests cover supplier selection, iPhone exclusion, price parsing, auto-import, and out-of-stock handling with local fixtures.
- The live Ehadish sitemap/page crawl and the Kasra API require deployment-time verification; this environment cannot certify that the supplier sites will permit every request or that every current page uses the expected markup. Review the first sync logs and supplier status after deployment.
