# PuzzleKala 1.13.3 — Kasra Plus deployment candidate

## Purpose
This edition is intentionally restricted to Kasra Plus. It is separate from the full multi-supplier edition.

## Supplier catalog ingestion
- Requests up to 100 records per page and supports several common response envelopes (`dataProvider.items/models`, nested `data.items/products/results/records`, and top-level lists).
- Follows page-count, total-count, and next-page metadata when provided.
- A repeated page, unrecognized response shape, missing product identifiers, empty catalog, early empty page, or short catalog relative to the declared total is treated as a failed sync, not as a successful partial catalog. This prevents a partial feed from marking products unavailable.
- Normalizes common product, price, image, stock, availability, and variant field names.
- Imports products only when there is a positive price and stock evidence; a price by itself is not proof of stock. Phones and accessories are both eligible.

## Pricing and privacy
- Default approved markup is 5%, calculated from supplier price rather than repeatedly marking up the prior site price.
- New auto-imported public IDs use `prod-auto-<hash>` without the supplier name. Internal supplier linkage remains on the server and is removed from customer-facing product views.
- Existing product IDs are not renamed, to avoid breaking order references.

## Sync behavior
- Default interval is 5 minutes, with the first sync scheduled shortly after server startup.
- Products missing from a complete successful feed are marked unavailable, not deleted.
- Failed, suspicious, or incomplete catalog fetches preserve existing stock/pricing state.

## Deployment note
This package is code-complete to the extent possible without credentials or access to the production hosting environment. The live API endpoint and its exact schema could not be verified from this packaging environment. After deployment, the first sync logs must be reviewed to confirm the supplier API accepts the configured endpoint, authentication requirements (if any), pagination, stock, and price fields. Do not treat the website's visible product list as proof that the API feed returns the same complete catalog.
