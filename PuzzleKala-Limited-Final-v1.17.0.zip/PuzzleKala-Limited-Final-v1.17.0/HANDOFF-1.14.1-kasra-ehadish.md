# PuzzleKala 1.14.1 — Kasra Plus + Ehadish (audited)

## Changes from 1.14.0
- Product URLs without numeric IDs now receive a stable path-derived internal ID instead of being silently dropped.
- Ehadish stock parsing now evaluates the separate stock-status element as well as the add-to-cart area.
- A disabled add-to-cart control is not treated as proof of stock.
- Regression tests added for slug-only IDs, disabled add-to-cart controls, and out-of-stock status shown separately from the button.

## Test results
- 56 automated tests passed in an isolated Node runtime after TypeScript transpilation.
- `npm install` could not complete in this environment, so the standard dependency-backed `npm test`, Vite production build, and full typecheck were not run.
- Live crawling of `https://www.ehadish.com/` and the Kasra API could not be verified from this environment. The first deployed sync must be checked in the admin supplier status/logs before assuming the full catalog imported.

## Existing rules retained
- Only Kasra Plus and Ehadish are configured in this edition.
- Kasra Plus stays enabled; Ehadish can be toggled in admin.
- Ehadish iPhone handsets are excluded; accessories remain eligible.
- Real source price is required; markup defaults to 5% and is applied once.
- Failed/incomplete source fetches preserve prior stock/pricing; missing items in a complete successful feed become unavailable, not deleted.
- Public product IDs do not disclose supplier names.
