import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const bundle = fs.readFileSync(path.join(process.cwd(), 'public/legacy/puzzlekala-ui.js'), 'utf8');

test('رابط مدیریت آمار ورود هدیش و نتیجهٔ واقعی همگام‌سازی را نمایش می‌دهد', () => {
  assert.match(bundle, /"ثبت‌شده و موجود"/);
  assert.match(bundle, /"نیازمند بررسی قیمت"/);
  assert.match(bundle, /"گوشی‌های حذف‌شده از هدیش"/);
  assert.match(bundle, /"همگام‌سازی ناموفق بود؛ وضعیت اتصال و گزارش خطا را بررسی کنید\."/);
  assert.match(bundle, /"خطا در ارتباط با سرور هنگام همگام‌سازی؛ نتیجه نامشخص است\."/);
  assert.match(bundle, /value:"ehadish",children:"هدیش"/);
  assert.doesNotMatch(bundle, /matchedCount:\s*64/);
  assert.match(bundle, /ثبت قیمت/);
  assert.match(bundle, /ابتدا قیمت معتبر ثبت کنید؛ کالای بدون قیمت قابل فعال‌سازی نیست/);
  assert.match(bundle, /نیازمند قیمت/);
});
