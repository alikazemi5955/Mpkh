// تست‌های نسخهٔ کسری پلاس + هدیش؛ هیچ تستی نباید به سایت واقعی تأمین‌کننده وصل شود.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { createServer } from 'http';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pk-kasra-test-'));
process.env.PUZZLEKALA_DATA_DIR = dir;
const E = await import('../src/supplierEngine.js');
const I = await import('../src/identity.js');
const C = await import('../src/productClassifier.js');

const supplier = { id: 'kasra', name: 'کسری پلاس (Kasra Plus)', enabled: true, baseUrl: 'https://example.invalid/catalog', connectionType: 'api_feed', status: 'unavailable', lastSyncAt: null, lastSuccessAt: null, lastError: null, sourceTotalProducts: 0, sourceInStockProducts: 0, sourceOutOfStockProducts: 0, matchedCount: 0, ambiguousCount: 0, variantsCount: 0, inStockColorsCount: 0 } as any;
const ehadishSupplier = { id: 'ehadish', name: 'هدیش (Ehadish)', enabled: true, baseUrl: 'https://www.ehadish.com/', connectionType: 'html_feed', status: 'unavailable', lastSyncAt: null, lastSuccessAt: null, lastError: null, sourceTotalProducts: 0, sourceInStockProducts: 0, sourceOutOfStockProducts: 0, matchedCount: 0, ambiguousCount: 0, variantsCount: 0, inStockColorsCount: 0 } as any;
const read = (f: string) => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
const write = (f: string, data: any) => fs.writeFileSync(path.join(dir, f), JSON.stringify(data));
const phone = (id = 'a57') => ({
  id, name: 'Samsung Galaxy A57 5G 12GB RAM 256GB',
  persianName: 'گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت',
  price: 1000, inStock: true, active: true,
  variants: [{ type: 'color', title: 'رنگ', options: [
    { id: `${id}-blue`, name: 'آبی یخی', value: 'آبی یخی', inStock: true, price: 1000 },
    { id: `${id}-navy`, name: 'سرمه‌ای', value: 'سرمه‌ای', inStock: true, price: 1000 },
  ] }],
});

async function run(products: any[], catalog: any[] | 'fail', settings: any = { supplierMarkupPercent: 5 }) {
  write('products.json', products);
  write('settings.json', settings);
  write('suppliers.json', [supplier, { ...ehadishSupplier, enabled: false }]);
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() {
    return catalog === 'fail' ? { success: false, items: [], error: 'fixture failure' } : { success: true, items: catalog };
  } });
  const result = await E.executeMultiSupplierSync();
  return { result, products: read('products.json') as any[], details: read('supplier_match_details.json') as any };
}

const feedPhone = (id: string, price = 20000000, stock = 5) => ({
  id, product_id: id, title: 'Samsung Galaxy A57 5G 12GB RAM 256GB',
  name: 'گوشی موبایل سامسونگ Galaxy A57 5G ظرفیت 256 گیگابایت رم 12 گیگابایت',
  price, stock, inStock: stock > 0,
  variants: [{ name: 'آبی یخی', price, stock, inStock: stock > 0 }],
});


test('پارس کردن XML واقعی API کسری، فهرست کالا و متادیتای صفحه‌بندی را تشخیص می‌دهد', async () => {
  const xml = `<?xml version="1.0"?><response><dataProvider><items><item><id>6279</id><category_id>52</category_id><product_name>فلش مموری تست</product_name><product_name_en>Test Flash</product_name><slug>test-flash</slug><site_visible>1</site_visible><price>1500000</price><stock>3</stock><src>https://cdn.example.test/test.webp</src></item></items></dataProvider><_meta><totalCount>1</totalCount><pageCount>1</pageCount><currentPage>1</currentPage></_meta><filters><leafCategories><item><id>52</id><name>فلش مموری</name></item></leafCategories></filters></response>`;
  const server = createServer((_req, res) => { res.writeHead(200, { 'content-type': 'application/xml' }); res.end(xml); });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address(); assert.ok(address && typeof address === 'object');
    const feed = await E.KasraAdapter.fetchCatalog({ ...supplier, baseUrl: `http://127.0.0.1:${address.port}/catalog` } as any);
    assert.equal(feed.success, true, String((feed as any).error));
    assert.equal(feed.items.length, 1);
    assert.equal(feed.items[0].id, '6279');
    assert.equal(feed.items[0].price, 1500000);
    assert.equal(feed.items[0].category, 'فلش مموری');
  } finally { await new Promise<void>((resolve, reject) => server.close((err) => err ? reject(err) : resolve())); }
});

test('پارس صفحهٔ عمومی کسری قیمت فعلی را از قیمت خط‌خورده جدا می‌کند و وضعیت را می‌خواند', () => {
  const html = '<html><h1>پاوربانک شیائومی PB2020MI</h1><span>5,190,000 تومان</span><del>5,290,000 تومان</del><button>افزودن به سبد خرید</button></html>';
  const parsed = E.parseKasraProductPage(html, { id: '4572', slug: 'xiaomi-pb2020mi', price: 0 });
  assert.equal(parsed.price, 5190000);
  assert.equal(parsed.priceMissing, false);
  assert.equal(parsed.inStock, true);
  const out = E.parseKasraProductPage('<html><h1>کالای ناموجود</h1><span>1,000,000 تومان</span><p>outofstock</p></html>', { id: 'out', slug: 'out', price: 0 });
  assert.equal(out.price, 1000000);
  assert.equal(out.inStock, false);
});

test('پارس قیمت رندرشدهٔ SSR کسری را بدون Nuxt JSON یا برچسب تومان استخراج می‌کند', () => {
  const html = `<html><div id="__nuxt"><h1>پاوربانک شیائومی PB2020MI ظرفیت 20000 میلی آمپر ساعت</h1><section class="lg:col-span-5"><div class="flex items-center gap-2"><span class="text-2xl font-bold">5,190,000</span><del class="line-through"><span>5,290,000</span></del></div><button>افزودن به سبد خرید</button></section><ul><li><span>ظرفیت</span><span>20,000</span></li><li><span>وزن</span><span>400</span></li></ul></div></html>`;
  const parsed = E.parseKasraProductPage(html, { id: '4572', slug: 'xiaomi-pb2020mi', price: 0 });
  assert.equal(parsed.price, 5190000, 'قیمت فروش SSR باید بدون نیاز به Nuxt JSON یا واژهٔ تومان استخراج شود');
  assert.equal(parsed.priceMissing, false);
  assert.equal(parsed.inStock, true);
});

test('قیمت پایین‌تر کارت کالای پیشنهادی نباید جای قیمت کالای اصلی کسری را بگیرد', () => {
  const related = `<article class="related-product"><h2>کابل ارزان</h2><span class="price">100,000 تومان</span></article>`;
  const html = `<html><h1>پاوربانک شیائومی PB2020MI</h1><div class="price-area"><span class="text-2xl font-bold">5,190,000</span><del class="line-through"><span>5,290,000</span></del></div><button id="AddToBasket">افزودن به سبد خرید</button>${related}</html>`;
  const parsed = E.parseKasraProductPage(html, { id: 'main-product', slug: 'pb2020mi', price: 0 });
  assert.equal(parsed.price, 5190000);
});

test('آداپتر کسری پاسخ کاتالوگ تو در تو را می‌خواند و بدون شاهد موجودی، کالا را موجود فرض نمی‌کند', async () => {
  const server = createServer((req, res) => {
    const page = new URL(req.url || '/', 'http://127.0.0.1').searchParams.get('page');
    res.writeHead(200, { 'content-type': 'application/json' });
    if (page === '1') {
      res.end(JSON.stringify({ data: { items: [
        { id: 'visible', title: 'کالای موجود با نمایش فعال', price: 1000, site_visible: 1 },
        { id: 'unknown', title: 'کالای بدون وضعیت موجودی', price: 2000 },
        { id: 'out', title: 'کالای ناموجود', price: 3000, stock: 0 },
      ] } }));
    } else {
      res.end(JSON.stringify({ data: { items: [] } }));
    }
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address();
    assert.ok(address && typeof address === 'object');
    const feed = await E.KasraAdapter.fetchCatalog({ ...supplier, baseUrl: `http://127.0.0.1:${address.port}/catalog` } as any);
    assert.equal(feed.success, true);
    assert.equal(feed.items.length, 3);
    assert.equal(feed.items.find((p: any) => p.id === 'visible').inStock, true);
    assert.equal(feed.items.find((p: any) => p.id === 'unknown').inStock, false);
    assert.equal(feed.items.find((p: any) => p.id === 'out').inStock, false);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((err) => err ? reject(err) : resolve()));
  }
});

test('آداپتر تمام صفحات اعلام‌شده را می‌خواند و متادیتای صفحه‌بندی را رعایت می‌کند', async () => {
  const server = createServer((req, res) => {
    const page = new URL(req.url || '/', 'http://127.0.0.1').searchParams.get('page');
    res.writeHead(200, { 'content-type': 'application/json' });
    if (page === '1') res.end(JSON.stringify({ dataProvider: { items: [
      { id: 'p1', title: 'کالای اول', price: 1000, stock: 2 },
      { id: 'p2', title: 'کالای دوم', price: 2000, stock: 1 },
    ], pagination: { pageCount: 2, totalCount: 3 } } }));
    else res.end(JSON.stringify({ dataProvider: { items: [
      { id: 'p3', title: 'کالای سوم', price: 3000, stock: 4 },
    ], pagination: { pageCount: 2, totalCount: 3 } } }));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address();
    assert.ok(address && typeof address === 'object');
    const feed = await E.KasraAdapter.fetchCatalog({ ...supplier, baseUrl: `http://127.0.0.1:${address.port}/catalog` } as any);
    assert.equal(feed.success, true);
    assert.deepEqual(feed.items.map((p: any) => p.id), ['p1', 'p2', 'p3']);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((err) => err ? reject(err) : resolve()));
  }
});

test('آداپتر صفحهٔ تکراری را کاتالوگ کامل فرض نمی‌کند', async () => {
  const server = createServer((_req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ data: { items: Array.from({ length: 100 }, (_, i) => ({ id: `p${i}`, title: `کالا ${i}`, price: 1000, stock: 1 })) } }));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address();
    assert.ok(address && typeof address === 'object');
    const feed = await E.KasraAdapter.fetchCatalog({ ...supplier, baseUrl: `http://127.0.0.1:${address.port}/catalog` } as any);
    assert.equal(feed.success, false);
    assert.match(String(feed.error), /تکراری/);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((err) => err ? reject(err) : resolve()));
  }
});

test('نسخهٔ مستقل فقط کسری پلاس و هدیش را نگه می‌دارد و کسری همیشه فعال است', () => {
  write('suppliers.json', [supplier, { ...supplier, id: 'other', name: 'Other' }]);
  const suppliers = E.getSuppliersList();
  assert.equal(suppliers.length, 2);
  assert.deepEqual(suppliers.map((s: any) => s.id), ['kasra', 'ehadish']);
  assert.equal(suppliers[0].enabled, true);
  assert.match(suppliers[0].name, /کسری پلاس/);
  assert.equal(suppliers[1].enabled, true);
  assert.match(suppliers[1].name, /هدیش/);
  assert.deepEqual(read('suppliers.json').map((s: any) => s.id), ['kasra', 'ehadish']);
});

test('هر کالای قابل‌شناسایی کسری ثبت می‌شود؛ ناموجود با موجودی صفر و بدون قیمت غیرفعال می‌ماند', async () => {
  const items = [
    feedPhone('phone-1'),
    { id: 'console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', name: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4, inStock: true },
    { id: 'out-1', title: 'کابل ناموجود', price: 300000, stock: 0, inStock: false },
    { id: 'price-0', title: 'کابل بدون قیمت', price: 0, stock: 10, inStock: true },
  ];
  const { products, result } = await run([], items);
  assert.equal(result.success, true);
  assert.equal(products.length, 4);
  assert.ok(products.every((p: any) => p.autoCreated));
  assert.ok(products.every((p: any) => !/kasra/i.test(String(p.id))), 'شناسه عمومی کالا نباید نام تأمین‌کننده را داشته باشد');
  assert.ok(products.every((p: any) => /kasra\|/.test(String(p.autoKey))), 'کلید داخلی تطبیق تأمین‌کننده باید برای همگام‌سازی حفظ شود');
  const p = products.find((p: any) => /A57/.test(p.name));
  const consoleItem = products.find((p: any) => /PlayStation/.test(p.name));
  assert.ok(p);
  assert.equal(p.price, 21000000);
  assert.equal(consoleItem.price, 31500000);
  const out = products.find((p: any) => p.name === 'کابل ناموجود');
  assert.ok(out);
  assert.equal(out.price, 315000);
  assert.equal(out.inStock, false);
  const noPrice = products.find((p: any) => /کابل بدون قیمت/.test(p.name));
  assert.ok(noPrice, 'کالای بدون قیمت نیز برای بررسی ثبت می‌شود');
  assert.equal(noPrice.price, 0);
  assert.equal(noPrice.active, false);
  assert.equal(noPrice.syncStatus, 'needs_price');
});

test('هدیش همه کالاها را به‌جز گوشی‌های آیفون و اندروید وارد می‌کند و موجودی/قیمت مشترک اعمال می‌شود', async () => {
  write('products.json', []);
  write('settings.json', { supplierMarkupPercent: 5 });
  write('suppliers.json', [supplier, ehadishSupplier]);
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() {
    return { success: false, items: [], error: 'fixture: Kasra skipped' };
  } });
  const hadishItems = [
    { id: 'h-1', title: 'Logitech C920 HD Webcam', name: 'وب کم لاجیتک C920', category: 'لوازم جانبی', price: 2000000, stock: 3, inStock: true, image: 'https://www.ehadish.com/c920.jpg' },
    { id: 'h-2', title: 'Apple iPhone 16 128GB', name: 'گوشی موبایل اپل آیفون 16', category: 'گوشی موبایل', price: 50000000, stock: 4, inStock: true },
    { id: 'h-3', title: 'TP-Link Router AX3000', name: 'روتر تی پی لینک AX3000', category: 'تجهیزات شبکه', price: 3500000, stock: 0, inStock: false },
    { id: 'h-4', title: 'USB Cable No Price', name: 'کابل بدون قیمت', category: 'لوازم جانبی', price: 0, stock: 2, inStock: true },
    { id: 'h-5', title: 'Spigen iPhone 16 Case', name: 'قاب آیفون 16 اسپایگن', category: 'لوازم جانبی موبایل', price: 900000, stock: 5, inStock: true },
    { id: 'h-6', title: 'Samsung Galaxy A57 5G 256GB 12GB RAM', name: 'گوشی موبایل سامسونگ Galaxy A57 5G ظرفیت 256 گیگابایت رم 12 گیگابایت', category: 'گوشی موبایل', price: 22000000, stock: 2, inStock: true },
  ];
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'ehadish', name: ehadishSupplier.name, async fetchCatalog() {
    return { success: true, items: hadishItems };
  } });
  const result = await E.executeMultiSupplierSync();
  const products = read('products.json');
  assert.equal(result.supplierStats.ehadish.status, 'connected');
  assert.equal(products.length, 4);
  assert.equal(result.supplierStats.ehadish.sourceCatalogUrlCount, 6);
  assert.equal(result.supplierStats.ehadish.sourceTotalProducts, 4);
  assert.equal(result.supplierStats.ehadish.importedProductsCount, 4);
  assert.equal(result.supplierStats.ehadish.importedInStockProductsCount, 3);
  assert.equal(result.supplierStats.ehadish.importedOutOfStockProductsCount, 1);
  assert.equal(result.supplierStats.ehadish.productsNeedingPriceCount, 1);
  assert.equal(result.supplierStats.ehadish.excludedMobilePhonesCount, 2);
  assert.ok(products.some((p: any) => /C920/.test(p.name)));
  assert.equal(products.find((p: any) => /C920/.test(p.name)).category, 'cat-computer-accessories');
  assert.ok(products.some((p: any) => /AX3000/.test(p.name)));
  assert.equal(products.find((p: any) => /AX3000/.test(p.name)).category, 'cat-computer-accessories');
  assert.equal(products.find((p: any) => /iPhone 16 Case/.test(p.name)).category, 'cat-mobile-accessories');
  assert.ok(products.some((p: any) => /iPhone 16 Case/.test(p.name)), 'لوازم جانبی آیفون باید وارد شوند');
  assert.ok(!products.some((p: any) => /گوشی موبایل اپل آیفون|Apple iPhone 16 128GB/i.test(p.name)), 'گوشی آیفون هدیش نباید وارد شود');
  assert.ok(!products.some((p: any) => /Galaxy A57|گوشی موبایل سامسونگ/i.test(p.name)), 'گوشی اندرویدی هدیش نباید وارد شود');
  const noPrice = products.find((p: any) => /بدون قیمت|No Price/i.test(p.name));
  assert.ok(noPrice, 'کالای بدون قیمت ثبت می‌شود اما برای فروش فعال نمی‌شود');
  assert.equal(noPrice.active, false);
  assert.equal(noPrice.price, 0);
  const inStock = products.find((p: any) => /C920/.test(p.name));
  const outStock = products.find((p: any) => /AX3000/.test(p.name));
  assert.equal(inStock.price, 2100000);
  assert.equal(inStock.inStock, true);
  assert.equal(outStock.price, 3675000);
  assert.equal(outStock.inStock, false);
  const caseItem = products.find((p: any) => /iPhone 16 Case/.test(p.name));
  assert.equal(caseItem.price, 945000);
  assert.equal(caseItem.inStock, true);
  assert.ok(products.every((p: any) => !/ehadish/i.test(String(p.id))));
  assert.ok(products.every((p: any) => String(p.autoKey).startsWith('ehadish|')));
});

test('پارس صفحهٔ واقعی‌نمای کسری از Nuxt قیمت تخفیفی، موجودی و دسته‌بندی را استخراج می‌کند', () => {
  const html = `<html><script>window.__NUXT__ = {"data":[{"props":{"__detail__":{"id":4572,"name":"پاوربانک شیائومی PB2020MI","sku":"PB2020MI","price":5290000,"discount_price":5190000,"stock":100,"is_active":1,"is_publish":1,"image":"/Product/4572/main.png","image_gallery":["/Product/4572/main.png","/Product/4572/second.png"],"category":{"id":1,"name":"پاوربانک","slug":"power-bank"},"available_variations":[]}}}]};</script></html>`;
  const product = E.parseKasraProductPage(html, { id: '4572', slug: 'power-bank-xiaomi-pb2020mi-33w-20000-mah' });
  assert.equal(product.price, 5190000, 'قیمت تخفیفی باید به‌جای قیمت قبل از تخفیف استفاده شود');
  assert.equal(product.sourcePrice, 5190000);
  assert.equal(product.stock, 100);
  assert.equal(product.inStock, true);
  assert.equal(product.category, 'پاوربانک');
  assert.match(product.image, /cdn\.kasratel\.ir\/Product\/4572\/main\.png/);
  assert.equal(product.priceMissing, false);
});

test('پارس XML کاتالوگ کسری فهرست کالاها و متادیتای صفحه‌بندی را می‌خواند', () => {
  const xml = `<response><dataProvider><items><item><id>6279</id><category_id>52</category_id><brand_id>81</brand_id><site_visible>1</site_visible><slug>silicon-power-blaze</slug><product_name>فلش مموری سیلیکون پاور</product_name><product_name_en>Silicon Power Blaze</product_name><src>https://cdn.kasratel.ir/1.webp</src></item></items><_meta><totalCount>324</totalCount><pageCount>4</pageCount><currentPage>1</currentPage></_meta><_links><next>https://api.kasrapars.ir/api/web/v10/product/index?page=2</next></_links></dataProvider><filters><leafCategories><item><id>52</id><name>فلش مموری</name></item></leafCategories></filters></response>`;
  const parsed = E.parseKasraXmlPayload(xml);
  assert.ok(parsed);
  const page = E.kasraExtractPage(parsed);
  assert.equal(page.totalCount, 324);
  assert.equal(page.pageCount, 4);
  assert.equal(page.hasMore, true);
  assert.equal(page.items[0].id, '6279');
});

test('پارس کردن صفحهٔ هدیش قیمت واقعی را می‌خواند و گوشی آیفون را حذف می‌کند', () => {
  const url = 'https://www.ehadish.com/product/category-mobile/12345-iphone-16';
  const html = '<html><title>Apple iPhone 16</title><text id=ProductNameFa>گوشی موبایل اپل آیفون 16</text><div class=bx-price>50,000,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  assert.equal(E.parseEhadishProduct(html, url), null);
  const androidHtml = '<html><title>Samsung Galaxy A57 5G 256GB 12GB RAM</title><h1>Samsung Galaxy A57 5G 256GB 12GB RAM</h1><div class=bx-price>22,000,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  assert.equal(E.parseEhadishProduct(androidHtml, 'https://www.ehadish.com/product/12351-samsung-galaxy-a57-5g-256gb-12gb-ram'), null, 'گوشی اندرویدی نیز باید حذف شود حتی اگر URL دسته‌بندی نداشته باشد');
  const androidWithoutSpecs = '<html><title>Samsung Galaxy A17</title><h1>Samsung Galaxy A17</h1><div class=bx-price>8,000,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  assert.equal(E.parseEhadishProduct(androidWithoutSpecs, 'https://www.ehadish.com/product/12352-samsung-galaxy-a17'), null, 'گوشی اندرویدی حتی بدون RAM/حافظه/5G نیز باید حذف شود');
  const nonPhone = '<html><title>Logitech Webcam</title><text id=ProductNameFa>وب کم لاجیتک C920</text><div class=bx-price>2,000,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  const parsed = E.parseEhadishProduct(nonPhone, 'https://www.ehadish.com/product/category-accessories/12346-logitech-c920');
  assert.equal(parsed.id, '12346');
  assert.equal(parsed.price, 2000000);
  assert.equal(parsed.inStock, true);
  const iphoneCase = '<html><title>Spigen iPhone Case</title><text id=ProductNameFa>قاب آیفون 16 اسپایگن</text><div class=bx-price>900,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  const caseParsed = E.parseEhadishProduct(iphoneCase, 'https://www.ehadish.com/product/category-mobile-accessories/12347-spigen-iphone-case');
  assert.ok(caseParsed, 'لوازم جانبی آیفون نباید به‌عنوان گوشی حذف شود');
  assert.notEqual(caseParsed.category, 'گوشی موبایل');

  const noPriceHtml = '<html><title>کابل بدون قیمت</title><h1>کابل USB بدون قیمت</h1><button id=AddToBasket disabled>افزودن به سبد</button></html>';
  const noPriceParsed = E.parseEhadishProduct(noPriceHtml, 'https://www.ehadish.com/product/12350-usb-cable-no-price');
  assert.ok(noPriceParsed, 'محصول قابل شناسایی بدون قیمت نباید از کاتالوگ حذف شود');
  assert.equal(noPriceParsed.price, 0);
  assert.equal(noPriceParsed.priceMissing, true);
  assert.equal(noPriceParsed.inStock, false);

  const noNumericId = '<html><title>USB-C Hub</title><h1>هاب USB-C هفت پورت</h1><div class=bx-price>1,200,000</div><button id=AddToBasket>افزودن به سبد</button></html>';
  const slugOnly = E.parseEhadishProduct(noNumericId, 'https://www.ehadish.com/product/usb-c-hub-seven-port');
  assert.ok(slugOnly?.id.startsWith('url-'), 'صفحات دارای slug بدون شناسه عددی نباید بی‌دلیل حذف شوند');
  assert.equal(slugOnly.price, 1200000);

  const jsonLdPrice = '<html><title>هاب USB-C</title><h1>هاب USB-C هفت پورت</h1><script type="application/ld+json">{"@context":"https://schema.org","@type":"Product","name":"USB-C Hub","offers":{"@type":"Offer","price":"1,750,000","priceCurrency":"IRR"}}</script><button id=AddToBasket>افزودن به سبد</button></html>';
  const jsonLdParsed = E.parseEhadishProduct(jsonLdPrice, 'https://www.ehadish.com/product/12353-usb-c-hub');
  assert.equal(jsonLdParsed.price, 1750000, 'قیمت موجود در JSON-LD نیز باید استخراج شود');
  const visiblePriceHtml = '<html><title>لپ تاپ تست</title><h1>لپ تاپ تست</h1><div>قیمت <strong>425,900,000</strong> تومان</div><button id=AddToBasket>افزودن به سبد</button></html>';
  const visiblePriceParsed = E.parseEhadishProduct(visiblePriceHtml, 'https://www.ehadish.com/product/category-laptop/12354-test-laptop');
  assert.equal(visiblePriceParsed.price, 425900000, 'قیمت قابل مشاهده در متن صفحه نیز باید استخراج شود');

  const disabledButton = '<html><title>کابل USB</title><h1>کابل USB</h1><div class=bx-price>300,000</div><button id=AddToBasket disabled>افزودن به سبد</button></html>';
  const disabledParsed = E.parseEhadishProduct(disabledButton, 'https://www.ehadish.com/product/12348-usb-cable');
  assert.equal(disabledParsed.inStock, false, 'دکمهٔ غیرفعال نباید به‌عنوان موجودی مثبت تفسیر شود');

  const separateOutOfStock = '<html><title>کابل HDMI</title><h1>کابل HDMI</h1><div class=bx-price>400,000</div><div class=stock-status>ناموجود</div><button id=AddToBasket>افزودن به سبد</button></html>';
  const outParsed = E.parseEhadishProduct(separateOutOfStock, 'https://www.ehadish.com/product/12349-hdmi-cable');
  assert.equal(outParsed.inStock, false, 'وضعیت ناموجود در بخش جداگانه باید بر وجود دکمهٔ سبد خرید اولویت داشته باشد');
});

test('اگر چند صفحهٔ هدیش پس از retry ناموفق بمانند، کالاهای دریافت‌شده ثبت و کاتالوگ ناقص علامت‌گذاری می‌شود', async () => {
  const originalFetch = globalThis.fetch;
  let failedPageAttempts = 0;
  const sitemap = `<urlset><url><loc>https://www.ehadish.com/product/category-accessories/90101-usb-c-hub</loc></url><url><loc>https://www.ehadish.com/product/category-accessories/90102-usb-cable</loc></url></urlset>`;
  const goodProduct = `<html><title>هاب USB-C هفت پورت</title><h1>هاب USB-C هفت پورت</h1><div class="bx-price">1,200,000</div><button id="AddToBasket">افزودن به سبد</button></html>`;
  globalThis.fetch = (async (input: any) => {
    const url = String(input);
    if (url.endsWith('/robots.txt')) return { ok: false, status: 404, text: async () => '' } as any;
    if (url.endsWith('/sitemap.xml')) return { ok: true, status: 200, text: async () => sitemap } as any;
    if (url.includes('90101-usb-c-hub')) return { ok: true, status: 200, text: async () => goodProduct } as any;
    if (url.includes('90102-usb-cable')) { failedPageAttempts++; return { ok: false, status: 503, text: async () => '' } as any; }
    return { ok: false, status: 404, text: async () => '' } as any;
  }) as any;
  try {
    const result = await E.EhadishAdapter.fetchCatalog({ ...ehadishSupplier, baseUrl: 'https://www.ehadish.com/' } as any);
    assert.equal(result.success, true, 'صفحات سالم باید پردازش شوند حتی اگر یک صفحه پس از retry در دسترس نباشد');
    assert.equal(result.items.length, 1);
    assert.equal(result.items[0].price, 1200000);
    assert.equal((result as any).meta.catalogComplete, 0);
    assert.equal((result as any).meta.failedPagesCount, 1);
    assert.ok(String(result.error).includes('ناقص'));
    assert.equal(failedPageAttempts, 4, 'صفحهٔ خطادار باید یک تلاش اولیه و سه تلاش مجدد داشته باشد');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('افزایش قیمت مصوب ۵٪ فقط یک بار اعمال می‌شود و با همگام‌سازی بعدی مرکب نمی‌شود', async () => {
  const first = await run([], [feedPhone('phone-1')]);
  assert.equal(first.products[0].price, 21000000);
  const second = await run(first.products, [feedPhone('phone-1')]);
  assert.equal(second.products.length, 1);
  assert.equal(second.products[0].price, 21000000);
});

test('اگر کاتالوگ موفق باشد اما کالای خودکار دیگر در آن نباشد، کالا ناموجود می‌شود نه حذف', async () => {
  const first = await run([], [{ id: 'console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4, inStock: true }]);
  assert.equal(first.products.length, 1);
  const second = await run(first.products, [{ id: 'different-1', title: 'Nintendo Switch OLED 64GB', price: 12000000, stock: 2, inStock: true }]);
  const old = second.products.find((p: any) => p.id === first.products[0].id);
  assert.ok(old);
  assert.equal(old.inStock, false);
  assert.equal(old.stock, 0);
  assert.ok(second.products.some((p: any) => /Nintendo/.test(p.name)));
});

test('اگر دریافت کاتالوگ خطا بدهد، وضعیت و قیمت قبلی کالا حفظ می‌شود', async () => {
  const first = await run([], [{ id: 'console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4, inStock: true }]);
  const before = first.products[0];
  const second = await run(first.products, 'fail');
  const after = second.products.find((p: any) => p.id === before.id);
  assert.ok(after);
  assert.equal(after.inStock, before.inStock);
  assert.equal(after.price, before.price);
  assert.equal(after.stock, before.stock);
});

test('ثبت خودکار تکراری ساخته نمی‌شود و فهرست نادیده‌های قدیمی مانع واردکردن کالا نمی‌شود', async () => {
  write(E.IGNORED_FILE, ['kasra|sony playstation 5 slim disc 1tb']);
  const first = await run([], [{ id: 'console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4, inStock: true }]);
  assert.equal(first.products.length, 1);
  const second = await run(first.products, [{ id: 'console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4, inStock: true }]);
  assert.equal(second.products.length, 1);
  assert.equal(second.products[0].id, first.products[0].id);
});

test('پیش‌نمایش همگام‌سازی فایل‌های داده را تغییر نمی‌دهد', async () => {
  await run([], [feedPhone('phone-1')]);
  const files = ['products.json', 'settings.json', 'suppliers.json', 'supplier_match_details.json', 'audit_logs.json', 'supplier_price_stock_history.json'];
  const before = new Map(files.map((f) => [f, fs.existsSync(path.join(dir, f)) ? fs.readFileSync(path.join(dir, f), 'utf8') : null]));
  await E.executeMultiSupplierSync(undefined, { dryRun: true });
  for (const f of files) {
    const after = fs.existsSync(path.join(dir, f)) ? fs.readFileSync(path.join(dir, f), 'utf8') : null;
    assert.equal(after, before.get(f), `${f} نباید در حالت پیش‌نمایش تغییر کند`);
  }
});

test('کالای خودکار در همگام‌سازی بعدی قیمت، موجودی و نام تأمین‌کننده را اصلاح می‌کند', async () => {
  const first = await run([], [{ id: 'accessory-1', title: 'قاب محافظ آیفون 16 Pro Max', price: 100000, stock: 3, inStock: true }]);
  assert.equal(first.products.length, 1);
  assert.equal(first.products[0].source, 'kasra');
  assert.equal(first.products[0].supplierName, 'کسری پلاس (Kasra Plus)');
  assert.equal(first.products[0].price, 105000);
  const second = await run(first.products, [{ id: 'accessory-1', title: 'قاب محافظ آیفون 16 Pro Max', price: 200000, stock: 0, inStock: false }]);
  assert.equal(second.products.length, 1);
  assert.equal(second.products[0].price, 210000);
  assert.equal(second.products[0].inStock, false);
  assert.equal(second.products[0].stock, 0);
  assert.equal(second.products[0].source, 'kasra');
});

test('کالای موجود بدون قیمت، موجودی منبع را حفظ می‌کند اما قابل فروش نمی‌شود', async () => {
  const result = await run([], [{ id: 'no-price-1', title: 'کابل USB-C موجود بدون قیمت', stock: 4, inStock: true }]);
  assert.equal(result.products.length, 1);
  assert.equal(result.products[0].inStock, true);
  assert.equal(result.products[0].stock, 4);
  assert.equal(result.products[0].price, 0);
  assert.equal(result.products[0].active, false);
  assert.equal(result.products[0].priceMissing, true);
});

test('قیمت JSON-LD هدیش استخراج می‌شود و موجودی به وجود قیمت وابسته نیست', () => {
  const html = `<html><title>هاب USB-C</title><h1>هاب USB-C هفت پورت</h1><script type="application/ld+json">{"@type":"Product","offers":{"@type":"Offer","price":"1,250,000"}}</script><button id="AddToBasket">افزودن به سبد</button></html>`;
  const product = E.parseEhadishProduct(html, 'https://www.ehadish.com/product/99123-usb-c-hub');
  assert.ok(product);
  assert.equal(product.price, 1250000);
  assert.equal(product.inStock, true);
});

test('لوازم جانبی و تجهیزات شبکه در دستهٔ مخصوص خود قرار می‌گیرند، نه گوشی موبایل', () => {
  const phoneCase = C.classifyProduct({ name: 'قاب محافظ آیفون 16 Pro Max' });
  assert.equal(phoneCase.category, 'قاب و کاور موبایل');
  assert.equal(phoneCase.categorySlug, 'mobile-accessories');
  const screen = C.classifyProduct({ name: 'گلس محافظ صفحه Samsung Galaxy S25' });
  assert.equal(screen.category, 'محافظ صفحه و لنز');
  assert.equal(screen.categorySlug, 'mobile-accessories');
  assert.equal(C.classifyProduct({ name: 'شارژر دیواری USB-C 45W' }).category, 'شارژر دیواری و بی سیم');
  assert.equal(C.classifyProduct({ name: 'Logitech C920 HD Webcam', category: 'لوازم جانبی' }).categorySlug, 'computer-accessories');
  assert.equal(C.classifyProduct({ name: 'TP-Link Router AX3000', category: 'تجهیزات شبکه' }).categorySlug, 'computer-accessories');
  assert.equal(C.classifyProduct({ name: 'Spigen iPhone 16 Case', category: 'لوازم جانبی موبایل' }).categorySlug, 'mobile-accessories');
  assert.equal(C.classifyProduct({ name: 'USB-C Wall Charger 45W', category: 'شارژر' }).categorySlug, 'chargers');
  assert.equal(C.classifyProduct({ name: 'ASUS VivoBook 15 Laptop', category: 'لپ تاپ' }).categorySlug, 'laptop');
  assert.equal(C.classifyProduct({ name: 'Generic Digital Accessory', category: 'لوازم جانبی' }).categorySlug, 'other-digital');
  assert.equal(C.classifyProduct({ name: 'Samsung USB-C Cable for Galaxy A55' }).categorySlug, 'chargers', 'کابل سازگار با گوشی سامسونگ نباید گوشی موبایل طبقه‌بندی شود');
  assert.equal(C.classifyProduct({ name: 'Generic Phone Adapter' }).categorySlug, 'chargers', 'آداپتور عمومی نباید گوشی موبایل طبقه‌بندی شود');
  assert.notEqual(C.classifyProduct({ name: 'Bluetooth accessory for iPhone' }).categorySlug, 'mobile', 'اکسسوری عمومی نباید به دسته گوشی موبایل سقوط کند');
});

test('استخراج هویت عنوان‌های فارسی و انگلیسی همچنان دقیق است', () => {
  const x = I.identityFromText('گوشی موبایل سامسونگ مدل Galaxy A57 5G دو سیم کارت ظرفیت 256 گیگابایت و رم 8 گیگابایت');
  assert.deepEqual([x.brand, x.model, x.ram, x.storage, x.network, x.sim], ['samsung', 'a57', 8, 256, '5G', 'dual']);
  const y = I.identityFromText('Apple iPhone 16 Pro Max 256GB CH/A');
  assert.deepEqual([y.brand, y.model, y.modifiers.join('+'), y.storage, y.part], ['apple', 'iphone 16', 'max+pro', 256, 'CH/A']);
});

test('کلمات توصیفی مدل را تغییر نمی‌دهند و تطبیق رنگ مبهم را قطعی فرض نمی‌کند', () => {
  const x = I.identityFromText('Samsung Galaxy A57 5G 256GB Dual SIM Exynos 1580 Aluminum Frame IP68 series processor feature');
  assert.equal(x.model, 'a57');
  assert.deepEqual(x.modifiers, []);
  assert.equal(x.region, null);
  const amb = I.mapColors(['آبی روشن', 'آبی تیره'], ['آبی']);
  assert.equal(amb.pairs.length, 0);
  assert.equal(amb.ambiguousSupplier.length, 1);
});

test('کالای یکسان در کسری و هدیش به‌صورت دو محصول مستقل ثبت می‌شود و قیمت هرکدام فقط از منبع خودش افزایش می‌گیرد', async () => {
  write('products.json', []);
  write('settings.json', { supplierMarkupPercent: 5 });
  write('suppliers.json', [supplier, { ...ehadishSupplier, enabled: true }]);
  const kasraRow = { id: 'kasra-console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', name: 'Sony PlayStation 5 Slim Disc 1TB', price: 1000000, stock: 4, inStock: true };
  const ehadishRow = { id: 'ehadish-console-1', title: 'Sony PlayStation 5 Slim Disc 1TB', name: 'Sony PlayStation 5 Slim Disc 1TB', price: 1500000, stock: 7, inStock: true };
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() { return { success: true, items: [kasraRow] }; } });
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'ehadish', name: ehadishSupplier.name, async fetchCatalog() { return { success: true, items: [ehadishRow] }; } });
  const result = await E.executeMultiSupplierSync();
  const products = read('products.json') as any[];
  assert.equal(result.success, true);
  assert.equal(products.length, 2, 'حتی با عنوان یکسان، هر ردیف منبع باید محصول مستقل باشد');
  const kasra = products.find((p: any) => p.supplierId === 'kasra');
  const ehadish = products.find((p: any) => p.supplierId === 'ehadish');
  assert.ok(kasra && ehadish);
  assert.equal(kasra.price, 1050000, 'قیمت کسری باید فقط با نرخ ۵٪ خودش افزایش یابد');
  assert.equal(ehadish.price, 1575000, 'قیمت هدیش باید فقط با نرخ ۵٪ خودش افزایش یابد');
  assert.deepEqual(Object.keys(kasra.supplierMatches), ['kasra']);
  assert.deepEqual(Object.keys(ehadish.supplierMatches), ['ehadish']);
  assert.equal(result.supplierStats.kasra.importedProductsCount, 1);
  assert.equal(result.supplierStats.ehadish.importedProductsCount, 1);
});

test('دو ردیف متفاوت در کاتالوگ یک تأمین‌کننده با عنوان یکسان نیز مستقل ثبت می‌شوند', async () => {
  write('products.json', []);
  write('settings.json', { supplierMarkupPercent: 5 });
  write('suppliers.json', [supplier, { ...ehadishSupplier, enabled: false }]);
  const rows = [
    { id: 'same-title-1', title: 'کابل USB-C مدل TEST طول یک متر', name: 'کابل USB-C مدل TEST طول یک متر', price: 100000, stock: 2, inStock: true },
    { id: 'same-title-2', title: 'کابل USB-C مدل TEST طول یک متر', name: 'کابل USB-C مدل TEST طول یک متر', price: 200000, stock: 3, inStock: true },
  ];
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() { return { success: true, items: rows }; } });
  const result = await E.executeMultiSupplierSync();
  const products = read('products.json') as any[];
  assert.equal(result.success, true);
  assert.equal(products.length, 2);
  assert.deepEqual(products.map((p: any) => p.sourceProductId).sort(), ['same-title-1', 'same-title-2']);
  assert.deepEqual(products.map((p: any) => p.price).sort((a: number, b: number) => a - b), [105000, 210000]);
});

test('قیمت مفقود کسری نباید با قیمت هدیش جبران شود؛ هر منبع قیمت خودش را مستقل نگه می‌دارد', async () => {
  write('products.json', []);
  write('settings.json', { supplierMarkupPercent: 5 });
  write('suppliers.json', [supplier, { ...ehadishSupplier, enabled: true }]);
  const kasraRow = { id: 'kasra-console-no-price', title: 'Sony PlayStation 5 Slim Disc 1TB', name: 'Sony PlayStation 5 Slim Disc 1TB', price: 0, priceMissing: true, stock: 3, inStock: true };
  const ehadishRow = { id: 'ehadish-console-priced', title: 'Sony PlayStation 5 Slim Disc 1TB', name: 'Sony PlayStation 5 Slim Disc 1TB', price: 2000000, stock: 5, inStock: true };
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() { return { success: true, items: [kasraRow] }; } });
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'ehadish', name: ehadishSupplier.name, async fetchCatalog() { return { success: true, items: [ehadishRow] }; } });
  await E.executeMultiSupplierSync();
  const products = read('products.json') as any[];
  assert.equal(products.length, 2);
  const kasra = products.find((p: any) => p.supplierId === 'kasra');
  const ehadish = products.find((p: any) => p.supplierId === 'ehadish');
  assert.equal(kasra.price, 0);
  assert.equal(kasra.active, false);
  assert.equal(kasra.priceMissing, true);
  assert.equal(ehadish.price, 2100000);
  assert.equal(ehadish.active, true);
  assert.equal(ehadish.priceMissing, false);
});
test('محصول واردشده نام دقیق دسته‌بندی تأمین‌کننده را حفظ می‌کند', async () => {
  const result = await run([], [{ id: 'category-exact-1', product_id: 'category-exact-1', title: 'فلش مموری آزمایشی 64 گیگابایت', name: 'فلش مموری آزمایشی 64 گیگابایت', category: 'فلش مموری', categoryName: 'فلش مموری', price: 100000, stock: 2, inStock: true }]);
  const imported = result.products.find((p: any) => p.sourceProductId === 'category-exact-1');
  assert.ok(imported, 'محصول منبع باید ساخته شود');
  assert.equal(imported.categoryLabel, 'فلش مموری');
  assert.equal(imported.supplierCategory, 'فلش مموری');
  assert.equal(imported.sourceCategory, 'فلش مموری');
  assert.equal(imported.subcategory, 'فلش مموری');
});

test('پارس کردن صفحه هدیش نام دسته‌بندی اصلی تأمین‌کننده را بدون بازنویسی عمومی نگه می‌دارد', () => {
  const html = `<html><h1>ساعت هوشمند آزمایشی</h1><div class="cat"><a href="/category-smartwatch">گجت‌های پوشیدنی</a></div><meta property="og:image" content="https://www.ehadish.com/test.jpg"><script type="application/ld+json">{"@type":"Product","name":"ساعت هوشمند آزمایشی","offers":{"@type":"Offer","price":"1250000"}}</script><button id="AddToBasket">افزودن به سبد خرید</button></html>`;
  const parsed = E.parseEhadishProduct(html, 'https://www.ehadish.com/123-test-watch');
  assert.ok(parsed);
  assert.equal(parsed.category, 'گجتهای پوشیدنی');
});


test('نام، مشخصات و تمام تصاویر منبع حفظ می‌شوند و قیمت همیشه دقیقاً ۵٪ افزایش می‌یابد', async () => {
  write('products.json', []);
  // Deliberately set a conflicting admin setting; limited integration must enforce the agreed fixed 5%.
  write('settings.json', { supplierMarkupPercent: 17 });
  write('suppliers.json', [supplier, { ...ehadishSupplier, enabled: false }]);
  const originalTitle = 'کابل USB-C مدل X-100 رنگ مشکی طول ۱.۵ متر (نسخه اصلی)';
  const row = {
    id: 'exact-source-1', title: originalTitle, name: originalTitle, price: 100000,
    stock: 2, inStock: true, category: 'کابل و مبدل',
    description: 'شرح دقیق تأمین‌کننده',
    specifications: [{ name: 'طول', value: '۱.۵ متر' }, { name: 'رنگ', value: 'مشکی' }],
    images: ['https://cdn.example.test/a.jpg', 'https://cdn.example.test/b.webp'],
    variants: [{ id: 'v-black', name: 'مشکی', price: 100000, stock: 2 }],
  };
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() { return { success: true, items: [row] }; } });
  const result = await E.executeMultiSupplierSync();
  assert.equal(result.success, true);
  const [product] = read('products.json') as any[];
  assert.equal(product.name, originalTitle, 'نام و عبارت‌های مدل/رنگ نباید حذف شوند');
  assert.equal(product.persianName, originalTitle);
  assert.equal(product.price, 105000, 'قیمت نمایشی باید ۵٪ باشد، نه مقدار تنظیمات یا افزایش مرکب');
  assert.equal(product.description, 'شرح دقیق تأمین‌کننده');
  assert.deepEqual(product.specifications, row.specifications);
  assert.deepEqual(product.images, row.images);
  assert.deepEqual(product.supplierOriginalVariants, row.variants);
  assert.equal(product.supplierId, 'kasra');
  assert.deepEqual(Object.keys(product.supplierMatches), ['kasra']);

  // Next poll must calculate from the newly fetched source price, not compound the previous retail price.
  row.price = 120000;
  E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 'kasra', name: supplier.name, async fetchCatalog() { return { success: true, items: [row] }; } });
  await E.executeMultiSupplierSync();
  const refreshed = (read('products.json') as any[])[0];
  assert.equal(refreshed.price, 126000, 'هر بار باید قیمت مبدأ جدید × ۱.۰۵ محاسبه شود');
  assert.deepEqual(refreshed.images, row.images);
});


test('قطع ارتباط تأمین‌کننده کالا، آخرین قیمت معتبر و موجودی ذخیره‌شده را حفظ می‌کند', async () => {
  const previous = {
    id: 'prod-auto-preserve-outage', name: 'کابل USB-C مدل حفظ قیمت', title: 'کابل USB-C مدل حفظ قیمت',
    price: 105000, sourcePrice: 100000, syncedPrice: 105000, stock: 4, inStock: true, active: true,
    autoCreated: true, autoKey: 'kasra|id:outage-item', sourceProductId: 'outage-item', supplierId: 'kasra', source: 'kasra',
    referenceSupplierId: 'kasra', referenceSupplierName: supplier.name, supplierName: supplier.name,
    supplierMatches: { kasra: { supplierProductId: 'outage-item', itemIds: ['outage-item'] } },
  };
  const { products, result } = await run([previous], 'fail');
  assert.equal(result.success, true);
  assert.equal(products.length, 1, 'کالا هنگام قطع ارتباط نباید حذف شود');
  assert.equal(products[0].price, 105000, 'آخرین قیمت نمایش‌داده‌شده حفظ شود');
  assert.equal(products[0].sourcePrice, 100000, 'آخرین قیمت مبدأ معتبر حفظ شود');
  assert.equal(products[0].inStock, true, 'قطع ارتباط نباید به اشتباه ناموجودی ایجاد کند');
  assert.equal(products[0].stock, 4);
});

test('پس از وصل مجدد تأمین‌کننده، قیمت تازه خودکار اعمال می‌شود و نیازی به تأیید نیست', async () => {
  const previous = {
    id: 'prod-auto-recover', name: 'کابل USB-C مدل بازیابی', title: 'کابل USB-C مدل بازیابی',
    price: 105000, sourcePrice: 100000, syncedPrice: 105000, stock: 4, inStock: true, active: true,
    autoCreated: true, autoKey: 'kasra|id:recover-item', sourceProductId: 'recover-item', supplierId: 'kasra', source: 'kasra',
    referenceSupplierId: 'kasra', referenceSupplierName: supplier.name, supplierName: supplier.name,
    supplierMatches: { kasra: { supplierProductId: 'recover-item', itemIds: ['recover-item'] } },
  };
  const failed = await run([previous], 'fail');
  assert.equal(failed.products[0].price, 105000);
  const fresh = { id: 'recover-item', title: 'کابل USB-C مدل بازیابی', name: 'کابل USB-C مدل بازیابی', price: 250000, stock: 0, inStock: false };
  const recovered = await run(failed.products, [fresh]);
  assert.equal(recovered.products.length, 1, 'همان رکورد قبلی به‌روزرسانی شود، نه رکورد تکراری');
  assert.equal(recovered.products[0].sourcePrice, 250000);
  assert.equal(recovered.products[0].price, 262500, 'قیمت جدید باید بی‌درنگ با فرمول ۵٪ اعمال شود');
  assert.equal(recovered.products[0].inStock, false, 'ناموجودی صریح تأمین‌کننده باید اعمال شود');
  assert.equal(recovered.products[0].stock, 0);
  assert.equal(recovered.products[0].active, true, 'ناموجودی به معنی حذف یا غیرفعال‌کردن خود رکورد کالا نیست');
});

test('نبود قیمت یا شاهد موجودی در پاسخ ناقص، قیمت و موجودی قبلی را بازنویسی نمی‌کند', async () => {
  const previous = {
    id: 'prod-auto-partial', name: 'شارژر مدل پاسخ ناقص', title: 'شارژر مدل پاسخ ناقص',
    price: 52500, sourcePrice: 50000, syncedPrice: 52500, stock: 3, inStock: true, active: true,
    autoCreated: true, autoKey: 'kasra|id:partial-item', sourceProductId: 'partial-item', supplierId: 'kasra', source: 'kasra',
    referenceSupplierId: 'kasra', referenceSupplierName: supplier.name, supplierName: supplier.name,
    supplierMatches: { kasra: { supplierProductId: 'partial-item', itemIds: ['partial-item'] } },
  };
  const partial = { id: 'partial-item', title: 'شارژر مدل پاسخ ناقص', name: 'شارژر مدل پاسخ ناقص', price: 0, priceMissing: true, stock: 0, inStock: false, is_available: false, stockKnown: false };
  const { products } = await run([previous], [partial]);
  assert.equal(products[0].price, 52500, 'قیمت قبلی باید حفظ شود');
  assert.equal(products[0].sourcePrice, 50000, 'قیمت مبدأ قبلی باید حفظ شود');
  assert.equal(products[0].inStock, true, 'نبود شاهد موجودی نباید به ناموجودی تعبیر شود');
  assert.equal(products[0].stock, 3);
  assert.equal(products[0].active, true);
});
