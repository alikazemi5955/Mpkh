import test from 'node:test';
import assert from 'node:assert/strict';
import { ensureDefaultTestAdmin, isDefaultTestAdminLoginAllowed } from '../src/testAdminLogin.js';

test('historical default admin credential works in development mode', () => {
  assert.equal(isDefaultTestAdminLoginAllowed('admin', 'admin123', { NODE_ENV: 'development' }), true);
  assert.equal(isDefaultTestAdminLoginAllowed(' ADMIN ', 'admin123', { NODE_ENV: 'test' }), true);
});

test('default admin credential is disabled in production unless test mode is explicitly enabled', () => {
  assert.equal(isDefaultTestAdminLoginAllowed('admin', 'admin123', { NODE_ENV: 'production' }), false);
  assert.equal(isDefaultTestAdminLoginAllowed('admin', 'admin123', { NODE_ENV: 'production', PUZZLEKALA_TEST_MODE: 'true' }), true);
});

test('wrong credentials never trigger the test account bootstrap', () => {
  assert.equal(isDefaultTestAdminLoginAllowed('not-admin', 'admin123', { NODE_ENV: 'development' }), false);
  assert.equal(isDefaultTestAdminLoginAllowed('admin', 'wrong', { NODE_ENV: 'development' }), false);
});

test('test account bootstrap creates a hashed admin or resets the existing admin without duplication', () => {
  const users: any[] = [];
  const fakeHash = (password: string) => `hashed:${password}`;
  const first = ensureDefaultTestAdmin(users, fakeHash, '2026-10-29T00:00:00.000Z');
  assert.equal(first.username, 'admin');
  assert.equal(first.password, 'hashed:admin123');
  assert.equal(first.isActive, true);
  const second = ensureDefaultTestAdmin(users, fakeHash, '2026-10-29T00:01:00.000Z');
  assert.equal(users.length, 1);
  assert.equal(second.password, 'hashed:admin123');
  assert.equal(second.isActive, true);
});
