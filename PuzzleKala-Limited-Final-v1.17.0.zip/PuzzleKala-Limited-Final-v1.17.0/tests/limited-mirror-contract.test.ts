import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

test('limited edition polls supplier catalog on startup and every five minutes', () => {
  const server = fs.readFileSync(path.join(process.cwd(), 'server.ts'), 'utf8');
  assert.match(server, /Initial supplier sync/);
  assert.match(server, /setInterval\(\(\) => \{ void runLimitedSupplierSync\('Five-minute supplier sync'\); \}, 5 \* 60 \* 1000\)/);
});

test('supplier engine hard-limits enabled integrations to Kasra Plus and Ehadish and fixed 5% markup', () => {
  const engine = fs.readFileSync(path.join(process.cwd(), 'src/supplierEngine.ts'), 'utf8');
  assert.match(engine, /s\.id === 'kasra' \|\| s\.id === 'ehadish'/);
  assert.match(engine, /const approvedMarkupPercent = 5/);
  assert.match(engine, /product\.price = Math\.round\(sourcePrice \* 1\.05\)/);
});
