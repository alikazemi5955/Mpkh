import test from 'node:test';
import assert from 'node:assert/strict';
import { reserveRequestedQuantity } from '../src/orderSafety.js';

test('order quantity validation rejects fractions, zero, negatives and unsafe numbers', () => {
  for (const quantity of [0, -1, 1.5, '2.1', Number.MAX_SAFE_INTEGER + 1, 'not-a-number']) {
    assert.equal(reserveRequestedQuantity(new Map(), 'p1', quantity, 20), null, String(quantity));
  }
});

test('repeated product lines share one stock limit', () => {
  const requested = new Map<string, number>();
  assert.equal(reserveRequestedQuantity(requested, 'p1', 2, 5), 2);
  assert.equal(reserveRequestedQuantity(requested, 'p1', 3, 5), 3);
  assert.equal(reserveRequestedQuantity(requested, 'p1', 1, 5), null);
  assert.equal(requested.get('p1'), 5);
});

test('quantity validation never accepts more than the per-order cap', () => {
  assert.equal(reserveRequestedQuantity(new Map(), 'p1', 101, 1000), null);
});
