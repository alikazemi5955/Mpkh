import test from 'node:test';
import assert from 'node:assert/strict';
import { publicProductView } from '../src/productPublicView.js';

test('public product view removes supplier pricing and matching fields recursively', () => {
  const product = {
    id: 'prod-1', name: 'Phone', price: 120, autoKey: 'kasra|phone model',
    sourcePrice: 100, referenceSupplierId: 'sup-a', supplierMatches: { supA: { supplierProductId: 'x' } },
    variants: [{ type: 'color', options: [{ name: 'Black', price: 120, sourcePrice: 100, referenceSupplierId: 'sup-a', referenceSupplierName: 'Supplier A', supplierPrice: 100, supplierId: 'sup-a', inStock: true }] }],
  };
  const publicView = publicProductView(product, false);
  assert.equal(publicView.price, 120);
  assert.equal(publicView.sourcePrice, undefined);
  assert.equal(publicView.referenceSupplierId, undefined);
  assert.equal(publicView.supplierMatches, undefined);
  assert.equal(publicView.autoKey, undefined);
  assert.equal(publicView.variants[0].options[0].price, 120);
  for (const key of ['sourcePrice', 'referenceSupplierId', 'referenceSupplierName', 'supplierPrice', 'supplierId']) {
    assert.equal(publicView.variants[0].options[0][key], undefined, key);
  }
});

test('admin product view retains supplier metadata for management screens', () => {
  const product = { id: 'prod-1', sourcePrice: 100, autoKey: 'kasra|phone model', variants: [{ options: [{ referenceSupplierId: 'sup-a' }] }] };
  const adminView = publicProductView(product, true);
  assert.equal(adminView.sourcePrice, 100);
  assert.equal(adminView.autoKey, 'kasra|phone model');
  assert.equal(adminView.variants[0].options[0].referenceSupplierId, 'sup-a');
});
