import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

test('نسخه محدود، تازه‌سازی سبد خرید را فقط هنگام داشتن کالا هر ۳۰ ثانیه اجرا می‌کند', () => {
  const bundle = fs.readFileSync(path.join(process.cwd(), 'public/legacy/puzzlekala-ui.js'), 'utf8');
  assert.match(bundle, /setInterval\(refreshCartProducts,30000\)/);
  assert.match(bundle, /if\(!Array\.isArray\(k\)\|\|k\.length===0\)return/);
  assert.match(bundle, /\[\"kasra\",\"ehadish\"\]/);
});

test('کلیک همگام‌سازی مدیر در صورت اجرای همگام‌سازی قبلی منتظر می‌ماند', () => {
  const server = fs.readFileSync(path.join(process.cwd(), 'server.ts'), 'utf8');
  assert.match(server, /for \(let attempt = 0; attempt < 180; attempt\+\+\)/);
  assert.match(server, /await new Promise\(\(resolve\) => setTimeout\(resolve, 1000\)\)/);
});
