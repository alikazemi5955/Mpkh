import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizePrice, normalizeStock, normalizeActive } from '../src/productSafety.js';

test('price normalization rejects negative and non-finite values', () => {
  assert.equal(normalizePrice(120), 120);
  assert.equal(normalizePrice(-1), 0);
  assert.equal(normalizePrice('NaN'), 0);
  assert.equal(normalizePrice(Infinity), 0);
});

test('stock count is authoritative and never allows negative or fractional stock', () => {
  assert.deepEqual(normalizeStock(4.8, true), { stock: 4, inStock: true });
  assert.deepEqual(normalizeStock(0, true), { stock: 0, inStock: false });
  assert.deepEqual(normalizeStock(-3, true), { stock: 0, inStock: false });
  assert.deepEqual(normalizeStock(5, 'false'), { stock: 5, inStock: false });
});

test('active flag parses string booleans instead of treating false strings as true', () => {
  assert.equal(normalizeActive(undefined), true);
  assert.equal(normalizeActive('false'), false);
  assert.equal(normalizeActive('off'), false);
  assert.equal(normalizeActive('true'), true);
});
