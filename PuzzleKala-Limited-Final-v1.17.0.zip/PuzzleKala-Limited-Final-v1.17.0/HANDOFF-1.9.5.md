# Puzzle Kala — Handoff Notes (1.9.5)

## Change in this version
- Added an explicit return-request state machine in `src/returnWorkflow.ts`.
- Return status changes now follow an allowed sequence: pending → approved/rejected; approved → received/rejected; received → refund_pending/closed; refund_pending → closed. Rejected and closed requests are terminal. Repeating the current status is idempotent.
- Rejecting a return requires an explanatory admin note.
- Moving a return to `refund_pending` requires the associated order to have a confirmed `paid` or `partially_refunded` payment status.
- Added unit tests for permitted and prohibited transitions.

## Known release blockers
- Real SMS OTP, payment gateway callback/signature validation, real refund provider, and SMS delivery remain unintegrated.
- Checkout UI still needs to call the server-side quote endpoint; its editable source is absent from this archive's current legacy bundle.
- Supplier source access, supplier error vs confirmed out-of-stock handling, shipping tariff configuration, durable database, atomic transactions, backups, staff roles, and complete acceptance coverage remain incomplete.

## Testing
- Host/deployment tests remain deferred at the user's request. Do not represent this archive as production-ready or as having passed build/tests unless these are actually run in an environment with dependencies installed.
