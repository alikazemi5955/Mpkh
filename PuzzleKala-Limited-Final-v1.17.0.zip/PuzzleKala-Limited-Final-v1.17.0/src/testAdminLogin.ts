/** Development/test-only check for the historical PuzzleKala admin credential. */
export function isDefaultTestAdminLoginAllowed(
  username: unknown,
  password: unknown,
  env: Record<string, string | undefined> = process.env,
): boolean {
  const testMode = env.PUZZLEKALA_TEST_MODE === 'true' || env.NODE_ENV !== 'production';
  return testMode
    && String(username ?? '').trim().toLowerCase() === 'admin'
    && String(password ?? '').trim() === 'admin123';
}

/** Ensure the historical test account exists; caller must gate this by the function above. */
export function ensureDefaultTestAdmin(
  users: any[],
  hashPassword: (password: string) => string,
  nowIso = new Date().toISOString(),
): any {
  let admin = users.find((u) => u?.role === 'admin' && String(u.username || '').toLowerCase() === 'admin');
  if (!admin) {
    admin = { id: 'admin-test-default', name: 'مدیر فروشگاه (حساب آزمایشی)', username: 'admin', role: 'admin', isActive: true, createdAt: nowIso };
    users.push(admin);
  }
  admin.password = hashPassword('admin123');
  admin.isActive = true;
  return admin;
}
