export const ORDER_STATUS_ALIASES = [
  'در حال بررسی', 'pending', 'under_review', 'تأییدشده', 'تاییدشده',
  'در حال آماده‌سازی', 'ارسال‌شده', 'تحویل‌شده', 'cancelled', 'canceled', 'لغو شده', 'لغو‌شده',
] as const;

export function normalizeOrderStatus(value: unknown): string {
  const v = String(value || '').trim().toLowerCase();
  if (['cancelled', 'canceled', 'لغو شده', 'لغو‌شده'].includes(v)) return 'cancelled';
  if (['تأییدشده', 'تاییدشده'].includes(v)) return 'approved';
  if (v === 'در حال آماده‌سازی') return 'preparing';
  if (v === 'ارسال‌شده') return 'shipped';
  if (v === 'تحویل‌شده') return 'delivered';
  if (['pending', 'under_review', 'در حال بررسی'].includes(v)) return 'review';
  return v;
}

const ALLOWED_NEXT: Record<string, readonly string[]> = {
  review: ['review', 'approved', 'cancelled'],
  approved: ['approved', 'preparing', 'cancelled'],
  preparing: ['preparing', 'shipped', 'cancelled'],
  shipped: ['shipped', 'delivered'],
  delivered: ['delivered'],
  cancelled: ['cancelled'],
};

export function canTransitionOrderStatus(current: unknown, next: unknown): boolean {
  const from = normalizeOrderStatus(current);
  const to = normalizeOrderStatus(next);
  return (ALLOWED_NEXT[from] || []).includes(to);
}

export function isValidOrderAmount(value: unknown): boolean {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 && n <= 1e15 && Number.isSafeInteger(Math.round(n));
}

export function isConsistentOrderTotal(subtotal: unknown, discount: unknown, shipping: unknown, total: unknown): boolean {
  if (![subtotal, discount, shipping, total].every((v) => Number.isFinite(Number(v)))) return false;
  const sub = Number(subtotal), off = Number(discount), ship = Number(shipping), grand = Number(total);
  if (sub < 0 || off < 0 || ship < 0 || grand < 0 || off > sub) return false;
  return Math.abs(Math.round(grand) - Math.round(Math.max(0, sub - off) + ship)) <= 1;
}
