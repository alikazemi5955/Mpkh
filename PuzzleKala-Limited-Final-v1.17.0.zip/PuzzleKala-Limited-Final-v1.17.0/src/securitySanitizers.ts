/** Remove secret-bearing fields at every nesting level before returning objects to clients. */
const SENSITIVE_TOKENS = new Set([
  'password', 'passwd', 'pwd', 'salt', 'secret', 'token', 'authorization',
  'credential', 'credentials', 'apikey', 'privatekey', 'clientsecret',
  'webhooksecret', 'adminsecret', 'suppliercredentials',
]);
const SENSITIVE_COMPOUNDS = [
  'apikey', 'privatekey', 'clientsecret', 'webhooksecret', 'adminsecret',
  'suppliercredentials', 'accesstoken', 'refreshtoken', 'passwordhash',
  'passwordsalt', 'tokenhash', 'secretkey',
];

export function isSensitiveKey(key: string): boolean {
  // Split camelCase as well as underscores/dashes so keys such as adminPassword,
  // googleApiKey and sessionTokenHash are treated as sensitive too.
  const separated = String(key).replace(/([a-z0-9])([A-Z])/g, '$1 $2');
  const tokens = separated.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  if (tokens.some((token) => SENSITIVE_TOKENS.has(token))) return true;
  const normalized = String(key).replace(/[^a-z0-9]/gi, '').toLowerCase();
  if (SENSITIVE_COMPOUNDS.some((compound) => normalized.includes(compound))) return true;
  if ((tokens.includes('api') && tokens.includes('key')) || (tokens.includes('private') && tokens.includes('key')) ||
      (tokens.includes('client') && tokens.includes('secret')) || (tokens.includes('webhook') && tokens.includes('secret')) ||
      (tokens.includes('admin') && tokens.includes('secret')) || (tokens.includes('access') && tokens.includes('token')) ||
      (tokens.includes('refresh') && tokens.includes('token')) || (tokens.includes('supplier') && tokens.includes('credentials'))) return true;
  return false;
}

export function scrubSensitiveFields<T>(value: T, depth = 0): T {
  // Fail closed at the recursion limit: returning the original nested value would leak secrets.
  if (depth > 12) return null as T;
  if (value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map((item) => scrubSensitiveFields(item, depth + 1)) as T;
  const output: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
    if (!isSensitiveKey(key)) output[key] = scrubSensitiveFields(item, depth + 1);
  }
  return output as T;
}
