/** Conservative normalization for inventory-facing fields. */
export function normalizePrice(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

export function normalizeStock(value: unknown, inStock?: unknown): { stock: number; inStock: boolean } {
  const parsed = Number(value);
  const stock = Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
  const flagAllowsSale = inStock !== false && String(inStock).trim().toLowerCase() !== 'false';
  return { stock, inStock: stock > 0 && flagAllowsSale };
}

export function normalizeActive(value: unknown): boolean {
  if (value === undefined || value === null) return true;
  if (value === false || value === 0) return false;
  return !['false', '0', 'no', 'off'].includes(String(value).trim().toLowerCase());
}
