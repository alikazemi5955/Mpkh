import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import {
  identityFromItem, identityFromProduct, compareIdentity, mapColors, colorKey, colorFromTokens, tokenize,
  DEFAULT_RULES, FIELD_FA,
} from './identity.js';
import type { Identity, MatchingRules } from './identity.js';

import { DATA_DIR } from './paths.js';
import { classifyProduct } from './productClassifier.js';
import { createHash } from 'crypto';

// ============================================================================
// 1. Types & Interfaces (Multi-Supplier Architecture)
// ============================================================================

export interface Supplier {
  id: string;
  name: string;
  enabled: boolean;
  baseUrl: string;
  connectionType: 'api_feed' | 'rest_api' | 'json_feed' | 'graphql' | 'html_feed';
  lastSyncAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  status: 'connected' | 'disconnected' | 'error' | 'unavailable';
  sourceTotalProducts?: number;
  sourceCatalogUrlCount?: number;
  sourceInStockProducts?: number;
  sourceOutOfStockProducts?: number;
  importedProductsCount?: number;
  importedInStockProductsCount?: number;
  importedOutOfStockProductsCount?: number;
  productsNeedingPriceCount?: number;
  excludedMobilePhonesCount?: number;
  catalogComplete?: boolean;
  matchedCount: number;
  ambiguousCount: number;
  variantsCount: number;
  inStockColorsCount: number;
  username?: string;
  password?: string;
  apiKey?: string;
}

export interface SupplierVariant {
  sourceVariantId?: string | number;
  colorName: string;
  normalizedColorName: string;
  sourcePrice: number;
  inStock: boolean;
  stock?: number;
  sourceUpdatedAt?: string;
}

export interface SupplierProductMatch {
  supplierId: string;
  supplierProductId?: string | number;
  sku?: string;
  barcode?: string;
  modelCode?: string;
  normalizedIdentity: string;
  variants: SupplierVariant[];
  confidence: 'exact' | 'high' | 'ambiguous' | 'none';
  matchReason?: string;
  /** شناسه‌ی همه‌ی ردیف‌های تأمین‌کننده که در این تطبیق مصرف شده‌اند */
  itemIds?: string[];
  candidates?: { id?: string | number; title: string; price?: number; color?: string; variants?: any[]; why?: string }[];
}

export interface SupplierAdapter {
  id: string;
  name: string;
  fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string; meta?: Record<string, number> }>;
  matchProduct(masterProduct: any, supplierItems: any[], index?: SupplierCatalogIndex): SupplierProductMatch | null;
}

export interface AuditLogEntry {
  id: string;
  action: string;
  details: string;
  actor: string;
  metadata?: any;
  timestamp: string;
}

export interface SupplierCatalogIndex {
  idMap: Map<string, any>;
  items: any[];
}



// ============================================================================
// 2. Safe JSON Helpers & Audit Log (Rule 20, 21 - Max 1000 Records, No Secrets)
// ============================================================================

export function readJsonFile<T>(filePath: string, fallback: T): T {
  if (!fs.existsSync(filePath)) return fallback;
  let content = '';
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (err: any) {
    console.error(`[SupplierEngine] Failed to read JSON file ${filePath}:`, err?.message || err);
    return fallback;
  }
  if (!content.trim()) {
    // Preserve an empty file as a recoverable artifact rather than silently treating
    // it as valid empty data; the next intentional write may then create a fresh file.
    try { fs.renameSync(filePath, `${filePath}.empty.${process.pid}.${Date.now()}`); }
    catch (err: any) { console.error(`[SupplierEngine] Could not preserve empty JSON file ${filePath}:`, err?.message || err); }
    return fallback;
  }
  try {
    return JSON.parse(content) as T;
  } catch (err: any) {
    // Do not let a later read-modify-write operation silently overwrite corrupted data.
    const backupPath = `${filePath}.corrupt.${process.pid}.${Date.now()}`;
    try {
      fs.renameSync(filePath, backupPath);
      console.error(`[SupplierEngine] Invalid JSON preserved at ${backupPath}; using fallback for this read.`);
    } catch (preserveErr: any) {
      console.error(`[SupplierEngine] Invalid JSON in ${filePath}; preservation failed:`, preserveErr?.message || preserveErr);
    }
    return fallback;
  }
}

export function writeJsonFile<T>(filePath: string, data: T): boolean {
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const tempFile = `${filePath}.tmp.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2, 10)}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, filePath);
    return true;
  } catch (err) {
    console.error(`[SupplierEngine] Failed to write JSON to ${filePath}:`, err);
    return false;
  }
}

export function recordAuditLog(
  action: string,
  details: string,
  actor: string = 'system',
  metadata?: any
): void {
  try {
    const auditFile = path.join(DATA_DIR, 'audit_logs.json');
    const logs = readJsonFile<AuditLogEntry[]>(auditFile, []);

    // Redact sensitive fields recursively; audit metadata may contain nested payloads.
    const sensitiveKey = (key: string) => /(password|passwd|salt|token|secret|api.?key|authorization|credential|cookie)/i.test(key);
    const sanitizeMeta = (value: any, depth = 0): any => {
      if (depth > 8 || value === null || typeof value !== 'object') return value;
      if (Array.isArray(value)) return value.slice(0, 500).map((item) => sanitizeMeta(item, depth + 1));
      const out: Record<string, any> = {};
      for (const [key, item] of Object.entries(value)) {
        if (sensitiveKey(key)) continue;
        out[key] = sanitizeMeta(item, depth + 1);
      }
      return out;
    };
    const sanitizedMeta = metadata && typeof metadata === 'object' ? sanitizeMeta(metadata) : metadata;

    const entry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      action,
      details,
      actor,
      metadata: sanitizedMeta,
      timestamp: new Date().toISOString(),
    };

    logs.unshift(entry);

    if (logs.length > 1000) {
      logs.splice(1000);
    }

    writeJsonFile(auditFile, logs);
  } catch {
    // Non-blocking
  }
}



// ============================================================================
// 3. Normalizers
// ============================================================================

export function normalizeText(text?: string | null): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // remove zero-width chars
    .replace(/[ي]/g, 'ی')
    .replace(/[ك]/g, 'ک')
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[\/\-_,.:;+()\[\]{}|\\!@#$%^&*~`]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** رنگ را به شکل استاندارد (کلید مقایسه) برمی‌گرداند؛ برای نمایش، نام اصلی حفظ می‌شود. */
export function normalizeColor(rawColor?: string | null): string {
  if (!rawColor) return '';
  const k = colorKey(rawColor);
  return k || String(rawColor).trim();
}

/** رنگ را از عنوان کالا (آخرین دنباله‌ی واژه‌های رنگ) می‌خواند. */
export function extractColorFromTitle(title?: string | null): string | null {
  if (!title) return null;
  return colorFromTokens(tokenize(String(title)));
}


// ============================================================================
// 4. HTTP Fetcher with Independent Timeout (Rule 26)
// ============================================================================

function decodeXmlEntity(value: string): string {
  return value.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&apos;|&#39;/g, "'").replace(/&amp;/g, '&')
    .replace(/&#x([0-9a-f]+);/gi, (_m, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)));
}

// The live Kasra catalog endpoint may return XML even when JSON is requested.
// Convert repeated XML nodes into arrays so the existing catalog normalizer can
// consume dataProvider/items and _meta in the same shape as the JSON fixtures.
export function parseKasraXmlPayload(xml: string): any | null {
  if (!/<[A-Za-z_][\w:.-]*(?:\s[^>]*)?>/.test(xml) || !/<\/?[A-Za-z_][\w:.-]*/.test(xml)) return null;
  type Node = { name: string; children: Node[]; text: string };
  const root: Node = { name: '__root__', children: [], text: '' };
  const stack: Node[] = [root];
  const tokens = xml.match(/<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<![^>]*>|<[^>]+>|[^<]+/g) || [];
  for (const token of tokens) {
    if (token.startsWith('<!--') || token.startsWith('<?') || token.startsWith('<!')) continue;
    if (token.startsWith('</')) { if (stack.length > 1) stack.pop(); continue; }
    if (token.startsWith('<')) {
      const match = token.match(/^<\s*([\w:.-]+)/);
      if (!match) continue;
      const node: Node = { name: match[1].split(':').pop()!, children: [], text: '' };
      stack[stack.length - 1].children.push(node);
      if (!/\/\s*>$/.test(token)) stack.push(node);
      continue;
    }
    stack[stack.length - 1].text += decodeXmlEntity(token);
  }
  const convert = (node: Node): any => {
    const out: Record<string, any> = {};
    for (const child of node.children) {
      const value = convert(child);
      if (Object.prototype.hasOwnProperty.call(out, child.name)) {
        if (!Array.isArray(out[child.name])) out[child.name] = [out[child.name]];
        out[child.name].push(value);
      } else out[child.name] = value;
    }
    const textValue = node.text.trim();
    if (!node.children.length) return textValue;
    if (textValue) out._text = textValue;
    return out;
  };
  const result = convert(root);
  if (!result || !Object.keys(result).length) return null;
  const rootKeys = Object.keys(result);
  return rootKeys.length === 1 && result[rootKeys[0]] && typeof result[rootKeys[0]] === 'object' ? result[rootKeys[0]] : result;
}

function fetchJson<T>(url: string, timeoutMs: number = 5000): Promise<{ data: T | null; error?: string }> {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(url);
      if (!['https:', 'http:'].includes(parsedUrl.protocol)) return resolve({ data: null, error: 'پروتکل URL تأمین‌کننده مجاز نیست.' });
      if (parsedUrl.username || parsedUrl.password) return resolve({ data: null, error: 'URL تأمین‌کننده نباید شامل credential باشد.' });
      const isHttps = parsedUrl.protocol === 'https:';
      const client = isHttps ? https : http;

      const req = client.get(
        url,
        {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            Accept: 'application/json, text/plain, */*',
          },
          timeout: timeoutMs,
        },
        (res) => {
          if (res.statusCode && (res.statusCode < 200 || res.statusCode >= 300)) {
            res.resume();
            return resolve({
              data: null,
              error: `HTTP ${res.statusCode} ${res.statusMessage || ''}`,
            });
          }

          let raw = '';
          let bytes = 0;
          const maxBytes = 8 * 1024 * 1024;
          res.setEncoding('utf-8');
          res.on('data', (chunk) => {
            bytes += Buffer.byteLength(String(chunk), 'utf8');
            if (bytes > maxBytes) {
              req.destroy();
              return resolve({ data: null, error: 'پاسخ تأمین‌کننده بیش از حد بزرگ است.' });
            }
            raw += chunk;
          });
          res.on('end', () => {
            try {
              const parsed = JSON.parse(raw);
              resolve({ data: parsed });
            } catch (err: any) {
              const xmlParsed = parseKasraXmlPayload(raw);
              if (xmlParsed) resolve({ data: xmlParsed });
              else resolve({ data: null, error: `پاسخ نامعتبر JSON/XML: ${err.message}` });
            }
          });
        }
      );

      req.on('timeout', () => {
        req.destroy();
        resolve({ data: null, error: `اتصال به تأمین‌کننده به پایان مهلت (${timeoutMs}ms) رسید` });
      });

      req.on('error', (err) => {
        resolve({ data: null, error: err.message || 'خطا در ارتباط شبکه' });
      });
    } catch (err: any) {
      resolve({ data: null, error: err.message || 'نشانی نامعتبر' });
    }
  });
}


// ============================================================================
// 5. Suppliers Management (Rule 3 & 13)
// ============================================================================

const DEFAULT_SUPPLIERS: Supplier[] = [
  {
    id: 'kasra', name: 'کسری پلاس (Kasra Plus)', enabled: true,
    baseUrl: 'https://api.kasrapars.ir/api/web/v10/product/index?per-page=100', connectionType: 'api_feed',
    lastSyncAt: null, lastSuccessAt: null, lastError: null, status: 'unavailable',
    sourceTotalProducts: 0, sourceCatalogUrlCount: 0, sourceInStockProducts: 0, sourceOutOfStockProducts: 0,
    matchedCount: 0, ambiguousCount: 0, variantsCount: 0, inStockColorsCount: 0,
  },
  {
    id: 'ehadish', name: 'هدیش (Ehadish)', enabled: true,
    baseUrl: 'https://www.ehadish.com/', connectionType: 'html_feed',
    lastSyncAt: null, lastSuccessAt: null, lastError: null, status: 'unavailable',
    sourceTotalProducts: 0, sourceCatalogUrlCount: 0, sourceInStockProducts: 0, sourceOutOfStockProducts: 0,
    matchedCount: 0, ambiguousCount: 0, variantsCount: 0, inStockColorsCount: 0,
  },
];

export function getSuppliersList(): Supplier[] {
  const filePath = path.join(DATA_DIR, 'suppliers.json');
  const sups = readJsonFile<Supplier[]>(filePath, []);
  if (!Array.isArray(sups) || sups.length === 0) {
    saveSuppliersList(DEFAULT_SUPPLIERS);
    return DEFAULT_SUPPLIERS.map((s) => ({ ...s }));
  }
  // This edition intentionally supports exactly Kasra Plus and Ehadish. Preserve
  // operational state for these two providers, discard legacy providers, and
  // always keep Kasra enabled while allowing Ehadish to be toggled by an admin.
  const allowed = DEFAULT_SUPPLIERS.map((base) => {
    const existing = sups.find((s) => s.id === base.id);
    return { ...base, ...(existing || {}), id: base.id, name: base.name,
      enabled: base.id === 'kasra' ? true : existing?.enabled !== false };
  });
  if (sups.length !== allowed.length || allowed.some((a, i) => sups[i]?.id !== a.id || sups[i]?.name !== a.name)) saveSuppliersList(allowed);
  return allowed;
}

export function saveSuppliersList(suppliers: Supplier[]): void {
  const filePath = path.join(DATA_DIR, 'suppliers.json');
  writeJsonFile(filePath, suppliers);
}


// ============================================================================
// 6. Universal Supplier Adapter (تطبیق چندمشخصه‌ی دقیق بر پایه‌ی هویت کالا)
// ============================================================================

let currentRules: MatchingRules = DEFAULT_RULES;

/** قوانین تطبیق: پیش‌فرض + فایل اختیاری data/matching-rules.json */
export function loadMatchingRules(): MatchingRules {
  const f = readJsonFile<Partial<MatchingRules>>(path.join(DATA_DIR, 'matching-rules.json'), {});
  return {
    ...DEFAULT_RULES,
    ...f,
    requiredIfMasterHas: Array.isArray(f.requiredIfMasterHas) ? f.requiredIfMasterHas : DEFAULT_RULES.requiredIfMasterHas,
    softFields: Array.isArray(f.softFields) ? f.softFields : DEFAULT_RULES.softFields,
    identityLabels: Array.isArray(f.identityLabels) ? f.identityLabels : DEFAULT_RULES.identityLabels,
    requiredByCategory: { ...DEFAULT_RULES.requiredByCategory, ...(f.requiredByCategory || {}) },
  };
}

const productIdentityCache = new WeakMap<object, Identity>();
const itemIdentityCache = new WeakMap<object, Identity>();
export const identityOfProduct = (p: any): Identity => {
  let id = productIdentityCache.get(p);
  if (!id) { id = identityFromProduct(p); productIdentityCache.set(p, id); }
  return id;
};
export const identityOfItem = (it: any): Identity => {
  let id = itemIdentityCache.get(it);
  if (!id) { id = identityFromItem(it); itemIdentityCache.set(it, id); }
  return id;
};

const DEFAULT_COLOR_NAMES = new Set(['پیش‌فرض', 'پیشفرض', 'پیش فرض', 'default', 'عمومی', 'بدون رنگ', '']);
const isDefaultColor = (name: string) => DEFAULT_COLOR_NAMES.has(String(name || '').trim().toLowerCase());
const titleOf = (it: any) => String(it?.title || it?.name || it?.product_name_en || it?.product_name || it?.persianName || '').slice(0, 160);

/** واریانت‌های رنگی یک یا چند ردیف هم‌هویت تأمین‌کننده؛ رنگ خالی یعنی «قیمت برای همه‌ی رنگ‌ها» */
function buildVariants(sourceItems: any[]): SupplierVariant[] {
  const variants: SupplierVariant[] = [];
  const now = new Date().toISOString();
  for (const sourceItem of sourceItems) {
    const rawPriceValue = sourceItem.price ?? sourceItem.sell_price ?? sourceItem.sellPrice ?? sourceItem.sourcePrice ?? sourceItem.source_price
      ?? sourceItem.final_price ?? sourceItem.finalPrice ?? sourceItem.product_price ?? sourceItem.productPrice
      ?? sourceItem.price_toman ?? sourceItem.priceToman ?? sourceItem.current_price ?? sourceItem.currentPrice
      ?? sourceItem.sale_price ?? sourceItem.salePrice ?? sourceItem.discounted_price ?? sourceItem.discountedPrice
      ?? sourceItem.regular_price ?? sourceItem.regularPrice ?? sourceItem.price_amount ?? sourceItem.priceAmount
      ?? (sourceItem.product_variants && sourceItem.product_variants[0]?.price)
      ?? (sourceItem.productVariants && sourceItem.productVariants[0]?.price)
      ?? (sourceItem.variants && sourceItem.variants[0]?.price)
      ?? (sourceItem.colors && sourceItem.colors[0]?.price) ?? 0;
    const rawPrice = typeof rawPriceValue === 'number' ? rawPriceValue : Number(String(rawPriceValue).replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[٬,\s]/g, '').replace(/تومان|ریال|IRR|IRT/gi, '')) || 0;
    const itemStock = sourceItem.stock !== undefined && sourceItem.stock !== null && sourceItem.stock !== '' ? Number(sourceItem.stock) : undefined;
    const list: any[] = Array.isArray(sourceItem.variants) && sourceItem.variants.length > 0 ? sourceItem.variants
      : Array.isArray(sourceItem.colors) && sourceItem.colors.length > 0 ? sourceItem.colors : [];
    if (list.length > 0) {
      for (const v of list) {
        const colName = typeof v === 'string' ? v : v.color || v.color_name || v.name || v.title || '';
        const colPrice = Number((typeof v === 'object' && (v.price || v.sell_price || v.sourcePrice)) || rawPrice);
        const vStock = typeof v === 'object' && v.stock !== undefined && v.stock !== null && v.stock !== '' ? Number(v.stock) : undefined;
        const inStock = typeof v === 'object'
          ? (vStock !== undefined ? vStock > 0 : v.inStock !== undefined ? Boolean(v.inStock) : v.is_available !== undefined ? Boolean(v.is_available) : true)
          : true;
        variants.push({
          sourceVariantId: typeof v === 'object' ? v.id : undefined,
          colorName: isDefaultColor(colName) ? '' : String(colName),
          normalizedColorName: isDefaultColor(colName) ? '' : colorKey(String(colName)),
          sourcePrice: colPrice,
          inStock,
          stock: vStock,
          sourceUpdatedAt: now,
        });
      }
    } else if (rawPrice > 0) {
      // ردیف بدون واریانت: رنگ از عنوان خوانده می‌شود؛ اگر نبود، قیمت برای همه‌ی رنگ‌هاست
      const phrase = identityOfItem(sourceItem).colorPhrase || '';
      const inStock = itemStock !== undefined ? itemStock > 0 : sourceItem.inStock !== undefined ? Boolean(sourceItem.inStock) : sourceItem.is_available === false || sourceItem.no_longer_available === true ? false : true;
      variants.push({
        colorName: phrase,
        normalizedColorName: phrase ? colorKey(phrase) : '',
        sourcePrice: rawPrice,
        inStock,
        stock: itemStock,
        sourceUpdatedAt: now,
      });
    }
  }
  return variants;
}

function buildMatch(sourceItems: any[], supplierId: string, confidence: 'exact' | 'high' | 'ambiguous', reason?: string): SupplierProductMatch {
  const first = sourceItems[0] || {};
  return {
    supplierId,
    supplierProductId: first.id || first.product_id,
    sku: first.sku,
    barcode: first.barcode || first.gtin,
    modelCode: first.model_code,
    normalizedIdentity: normalizeText(titleOf(first)),
    variants: buildVariants(sourceItems),
    confidence,
    matchReason: reason,
    itemIds: sourceItems.map((x) => String(x.id ?? x.product_id ?? '')).filter(Boolean),
  };
}

const candidateRow = (it: any, why: string) => {
  const variants = buildVariants([it]).filter((v) => v.colorName).map((v) => ({ name: v.colorName, price: v.sourcePrice, stock: v.stock }));
  const price = Number(it.price || it.sell_price || it.sourcePrice || (it.variants && it.variants[0]?.price) || 0) || undefined;
  return { id: it.id, title: titleOf(it), price, color: identityOfItem(it).colorPhrase || variants.map((v) => v.name).join('، ') || 'پیش‌فرض / نامشخص', variants, why };
};

export const UniversalSupplierAdapter: SupplierAdapter = {
  id: 'universal',
  name: 'تأمین‌کننده عمومی استاندارد',

  async fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string }> {
    if (!supplier.enabled) {
      return { success: false, items: [], error: 'تأمین‌کننده غیرفعال است' };
    }
    const res = await fetchJson<any>(supplier.baseUrl, 5000);
    if (!res.data) {
      return { success: false, items: [], error: res.error || `خطا در استعلام از ${supplier.name}` };
    }
    let items: any[] = [];
    if (res.data.dataProvider && Array.isArray(res.data.dataProvider.items)) items = res.data.dataProvider.items;
    else if (Array.isArray(res.data.items)) items = res.data.items;
    else if (Array.isArray(res.data.products)) items = res.data.products;
    else if (Array.isArray(res.data.data)) items = res.data.data;
    else if (Array.isArray(res.data)) items = res.data;
    return { success: true, items };
  },

  matchProduct(masterProduct: any, supplierItems: any[], index?: SupplierCatalogIndex): SupplierProductMatch | null {
    if (!masterProduct || !supplierItems || supplierItems.length === 0) return null;
    const rules = currentRules;
    const master = identityOfProduct(masterProduct);
    // الف-۱) کالای ساخته‌شده‌ی خودکار از همین تأمین‌کننده (غیرگوشی): پیوند مستقیم با ردیف‌هایی که از آن ساخته شده
    const auto = masterProduct.autoCreated ? masterProduct.supplierMatches?.[this.id] : null;
    if (auto && Array.isArray(auto.itemIds)) {
      const rows = auto.itemIds.map((k: string) => (index && index.idMap.get(String(k))) || supplierItems.find((it) => String(it.id ?? it.product_id) === String(k))).filter(Boolean);
      return buildMatch(rows, this.id, 'exact', rows.length ? 'کالای ساخته‌شده‌ی خودکار از همین تأمین‌کننده' : 'ردیف تأمین‌کننده دیگر در کاتالوگ نیست');
    }

    // مدل کالای خودِ مدیر قابل تشخیص یا بدون تناقض نیست: هیچ تطبیق خودکاری انجام نمی‌شود (در فهرست «مشکل مشخصات کالا» گزارش می‌شود)
    if (!master.model || master.conflicts.length) {
      const manualOnly = masterProduct.supplierMatches?.[this.id]?.confirmedBy === 'admin';
      if (!manualOnly) return null;
    }

    // الف) تأیید دستی مدیر (از «پنل تأمین‌کنندگان ← تأیید تطبیق»): فقط اگر مشخصات صریحاً متناقض نباشد
    const manual = masterProduct.supplierMatches?.[this.id];
    if (manual && manual.confirmedBy === 'admin' && manual.supplierProductId) {
      const key = String(manual.supplierProductId).trim();
      const item = (index && index.idMap.get(key)) || supplierItems.find((it) => String(it.id ?? it.product_id) === key);
      if (item) {
        const cmp = compareIdentity(master, identityOfItem(item), rules);
        if (cmp.verdict === 'mismatch') {
          const m = buildMatch([item], this.id, 'ambiguous', `تأیید دستی مدیر با مشخصات کالا نمی‌خواند: ${cmp.reasons.join('؛ ')}`);
          m.candidates = [candidateRow(item, cmp.reasons.join('؛ '))];
          return m;
        }
        return buildMatch([item], this.id, 'exact', 'تأیید دستی مدیر');
      }
    }

    // ب) مقایسه‌ی همه‌ی مشخصات با تک‌تک ردیف‌های تأمین‌کننده
    const evals = supplierItems.map((it) => {
      const cId = identityOfItem(it);
      return { it, cId, cmp: compareIdentity(master, cId, rules) };
    });

    // مشخصه‌های «نرم» (شبکه/سیم یا رم‌ِ ننوشته‌ی هر دو طرف): فقط وقتی مشکل‌اند که تأمین‌کننده ردیف هم‌خانواده‌ی متفاوتی هم داشته باشد
    const onlyFields = (mm: string[], fields: string[]) => mm.length > 0 && mm.every((f) => fields.includes(f));
    const soft = new Set<string>(rules.softFields);
    const fullMatches: typeof evals = [];
    const nearMiss: { e: (typeof evals)[number]; why: string }[] = [];
    for (const e of evals) {
      if (e.cmp.verdict === 'unknown') { nearMiss.push({ e, why: e.cmp.reasons.join('؛ ') }); continue; }
      if (e.cmp.verdict !== 'match') continue;
      let conflict = '';
      for (const f of e.cmp.soft) {
        const key = f as keyof Identity;
        const sibling = evals.find((o) => o !== e && o.cId[key] !== null && o.cId[key] !== '' && o.cId[key] !== undefined &&
          o.cmp.mismatches.length > 0 && onlyFields(o.cmp.mismatches, [...soft, f]) && o.cmp.mismatches.includes(f));
        if (sibling) conflict = `تأمین‌کننده ${FIELD_FA[f] || f} را ننوشته و ردیف دیگری با ${FIELD_FA[f] || f} متفاوت هم دارد`;
      }
      if (conflict) nearMiss.push({ e, why: conflict }); else fullMatches.push(e);
    }

    if (fullMatches.length === 0) {
      if (nearMiss.length === 0) return null;
      const m = buildMatch([nearMiss[0].e.it], this.id, 'ambiguous', `مشخصات کالای تأمین‌کننده کامل نیست؛ برای اطمینان قیمت اعمال نشد (${nearMiss[0].why})`);
      m.candidates = nearMiss.slice(0, 5).map((n) => candidateRow(n.e.it, n.why));
      return m;
    }
    const reason = fullMatches.length === 1
      ? 'تطبیق همه‌ی مشخصات (برند، مدل، نسخه، رم، حافظه و ...)'
      : `${fullMatches.length} ردیف هم‌هویت (احتمالاً رنگ‌های جدا) ادغام شد`;
    return buildMatch(fullMatches.map((e) => e.it), this.id, 'high', reason);
  },
};


function kasraNumber(value: any): number | undefined {
  if (value === undefined || value === null || value === '') return undefined;
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined;
  const normalized = String(value)
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[٬,\s]/g, '')
    .replace(/تومان|ریال|IRR|IRT/gi, '')
    .trim();
  const n = Number(normalized);
  return Number.isFinite(n) ? n : undefined;
}

function kasraFirstNumber(...values: any[]): number | undefined {
  for (const value of values) {
    const candidate = value && typeof value === 'object'
      ? value.amount ?? value.value ?? value.gross?.amount ?? value.price?.amount
      : value;
    const parsed = kasraNumber(candidate);
    if (parsed !== undefined) return parsed;
  }
  return undefined;
}

export function kasraExtractPage(payload: any): { items: any[]; pageCount?: number; totalCount?: number; hasMore?: boolean; recognized: boolean } {
  const candidates = [
    payload?.dataProvider?.items,
    payload?.dataProvider?.items?.item,
    payload?.dataProvider?.items?.product,
    payload?.dataProvider?.item,
    payload?.dataProvider?.models,
    payload?.dataProvider?.data,
    payload?.data?.dataProvider?.items,
    payload?.data?.dataProvider?.item,
    payload?.data?.dataProvider?.models,
    payload?.data?.items,
    payload?.data?.items?.item,
    payload?.data?.items?.product,
    payload?.data?.products,
    payload?.data?.results,
    payload?.data?.records,
    payload?.data?.models,
    payload?.items,
    payload?.items?.item,
    payload?.items?.product,
    payload?.products,
    payload?.results,
    payload?.records,
    payload?.models,
    payload?._embedded?.items,
    payload?._embedded?.products,
    payload?.data,
  ];
  const itemsCandidate = candidates.find(Array.isArray) ?? candidates.find((candidate: any) => candidate && typeof candidate === 'object' && (candidate.id !== undefined || candidate.product_id !== undefined || candidate.product_name !== undefined || candidate.slug !== undefined));
  const items = (Array.isArray(itemsCandidate) ? itemsCandidate : itemsCandidate ? [itemsCandidate] : undefined) as any[] | undefined;
  const meta = payload?._meta || payload?.meta || payload?.pagination || payload?.dataProvider?._meta || payload?.dataProvider?.pagination || payload?.dataProvider?.paginationInfo || payload?.data?.meta || payload?.data?.pagination || {};
  const links = payload?.dataProvider?._links || payload?._links || {};
  const pageCount = kasraFirstNumber(meta.pageCount, meta.page_count, meta.totalPages, meta.total_pages, meta.last_page, payload?.pageCount, payload?.page_count, typeof links.last === 'string' ? new URL(links.last, 'https://api.kasrapars.ir').searchParams.get('page') : undefined);
  const totalCount = kasraFirstNumber(meta.totalCount, meta.total_count, meta.total, meta.count, payload?.totalCount, payload?.total_count);
  const explicitHasMore = typeof meta.hasMore === 'boolean' ? meta.hasMore
    : typeof meta.has_more === 'boolean' ? meta.has_more
    : typeof payload?.hasMore === 'boolean' ? payload.hasMore
    : typeof payload?.has_more === 'boolean' ? payload.has_more
    : undefined;
  const next = meta.next ?? meta.nextPage ?? meta.next_page ?? payload?.next ?? payload?.nextPage ?? payload?.next_page ?? payload?.links?.next ?? links.next;
  return { items: items || [], pageCount, totalCount, hasMore: explicitHasMore ?? (next ? true : undefined), recognized: Array.isArray(items) };
}

function normalizeKasraProduct(it: any): any {
  const rawVariants = [
    ...(Array.isArray(it?.variants) ? it.variants : []),
    ...(Array.isArray(it?.colors) ? it.colors : []),
    ...(Array.isArray(it?.product_variants) ? it.product_variants : []),
    ...(Array.isArray(it?.productVariants) ? it.productVariants : []),
    ...(Array.isArray(it?.offers) ? it.offers : []),
  ];
  const variantsArr = rawVariants;
  const unavailableFlag = [it?.no_longer_available, it?.is_available, it?.isAvailable, it?.available, it?.inStock, it?.in_stock, it?.site_visible, it?.is_visible, it?.isVisible, it?.active, it?.is_active]
    .some((v) => v === false || v === 0 || v === '0' || v === 'false');
  const explicitAvailable = [it?.is_available, it?.isAvailable, it?.available, it?.inStock, it?.in_stock, it?.site_visible, it?.is_visible, it?.isVisible, it?.active, it?.is_active]
    .some((v) => v === true || v === 1 || v === '1' || v === 'true');
  const rawStock = kasraFirstNumber(it?.stock, it?.quantity, it?.qty, it?.quantity_available, it?.quantityAvailable, it?.stock_quantity, it?.inventory_quantity);
  const anyVariantStock = variantsArr.some((v: any) => {
    const stock = kasraFirstNumber(v?.stock, v?.quantity, v?.qty, v?.quantity_available, v?.quantityAvailable, v?.stock_quantity, v?.inventory_quantity);
    return stock !== undefined ? stock > 0 : [v?.inStock, v?.in_stock, v?.is_available, v?.isAvailable, v?.available].some((x) => x === true || x === 1 || x === '1' || x === 'true');
  });
  const price = kasraFirstNumber(
    it?.price, it?.sell_price, it?.sellPrice, it?.sourcePrice, it?.source_price,
    it?.final_price, it?.finalPrice, it?.retail_price, it?.retailPrice,
    it?.price_amount, it?.priceAmount, it?.product_price, it?.productPrice,
    it?.price_toman, it?.priceToman, it?.price_irr, it?.priceIrr,
    it?.final_price_toman, it?.finalPriceToman, it?.current_price, it?.currentPrice,
    it?.sale_price, it?.salePrice, it?.discounted_price, it?.discountedPrice,
    it?.base_price, it?.basePrice, it?.regular_price, it?.regularPrice,
    it?.min_price, it?.minPrice, it?.amount, it?.price_value, it?.priceValue,
    it?.product_variants?.[0]?.price, it?.productVariants?.[0]?.price,
    it?.variants?.[0]?.price, it?.colors?.[0]?.price, it?.offers?.[0]?.price,
  ) ?? 0;
  const isUnavailable = it?.no_longer_available === true || it?.is_available === false || it?.is_available === 0 || it?.is_available === '0' || it?.site_visible === false || it?.site_visible === 0 || it?.site_visible === '0' || it?.is_visible === false || it?.is_visible === 0 || it?.active === false || it?.active === 0 || it?.is_active === false || it?.is_active === 0 || ['inactive', 'disabled', 'unavailable', 'out_of_stock'].includes(String(it?.status ?? '').toLowerCase());
  const isVisible = !isUnavailable && (rawStock !== undefined ? rawStock > 0 : anyVariantStock || explicitAvailable);
  const normalizedVariants = variantsArr.map((v: any) => {
    const variantStock = kasraFirstNumber(v?.stock, v?.quantity, v?.qty, v?.quantity_available, v?.quantityAvailable, v?.stock_quantity, v?.inventory_quantity);
    const variantPrice = kasraFirstNumber(v?.price, v?.sell_price, v?.sellPrice, v?.final_price, v?.price_amount, v?.priceAmount) ?? price;
    const variantUnavailable = [v?.is_available, v?.isAvailable, v?.available, v?.inStock, v?.in_stock].some((x) => x === false || x === 0 || x === '0' || x === 'false');
    const variantAvailable = [v?.is_available, v?.isAvailable, v?.available, v?.inStock, v?.in_stock].some((x) => x === true || x === 1 || x === '1' || x === 'true');
    const variantInStock = !isUnavailable && !variantUnavailable && (variantStock !== undefined ? variantStock > 0 : variantAvailable || (rawStock !== undefined ? rawStock > 0 : explicitAvailable));
    return { ...v, id: v?.id ?? v?.product_variant_id ?? v?.sku, name: v?.color_name ?? v?.color ?? v?.name ?? v?.title ?? v?.variant_name ?? '', color_name: v?.color_name ?? v?.color ?? v?.name ?? v?.title ?? v?.variant_name ?? '', price: variantPrice, stock: variantStock ?? (variantInStock ? 1 : 0), inStock: variantInStock, is_available: variantInStock };
  });
  const name = it?.product_name ?? it?.product_name_en ?? it?.short_name ?? it?.name ?? it?.title ?? it?.label ?? '';
  const nameEn = it?.product_name_en ?? it?.name_en ?? it?.nameEn ?? '';
  const imageCandidate = it?.src ?? it?.image ?? it?.image_url ?? it?.imageUrl ?? it?.thumbnail?.url ?? it?.thumbnail ?? it?.main_image ?? it?.mainImage ?? (Array.isArray(it?.images) ? (typeof it.images[0] === 'string' ? it.images[0] : it.images[0]?.url) : '');
  const image = typeof imageCandidate === 'string' ? imageCandidate : imageCandidate?.url ?? '';
  const id = it?.id ?? it?.product_id ?? it?.productId ?? it?.uuid ?? it?.sku ?? it?.barcode;
  return {
    ...it,
    id,
    product_id: it?.product_id ?? id,
    name,
    title: name,
    persianName: name,
    nameEn,
    inStock: isVisible,
    stockKnown: rawStock !== undefined || explicitAvailable || unavailableFlag,
    stock: rawStock !== undefined ? Math.max(0, rawStock) : isVisible ? 1 : 0,
    is_available: isVisible,
    site_visible: it?.site_visible !== undefined ? it.site_visible : isVisible ? 1 : 0,
    price,
    image,
    images: image ? [image] : [],
    variants: normalizedVariants,
    supplierId: 'kasra',
    supplierName: 'کسری پلاس (Kasra Plus)',
  };
}

async function fetchKasraPage(url: string, timeoutMs = 20000): Promise<{ ok: boolean; status: number; text: string }> {
  let last: { ok: boolean; status: number; text: string } = { ok: false, status: 0, text: '' };
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 PuzzleKalaSupplierSync/1.2',
          Accept: 'text/html,application/xhtml+xml,application/json,*/*',
          'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.7',
          'Cache-Control': 'no-cache',
        },
        signal: AbortSignal.timeout(timeoutMs),
      });
      if (response.ok) return { ok: true, status: response.status, text: await response.text() };
      last = { ok: false, status: response.status, text: '' };
      if (response.status === 404 || (response.status < 500 && ![403, 408, 425, 429].includes(response.status))) return last;
    } catch { last = { ok: false, status: 0, text: '' }; }
    if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 500 * (2 ** attempt)));
  }
  return last;
}

function extractNuxtPayload(html: string): any | null {
  const marker = html.indexOf('window.__NUXT__');
  if (marker < 0) return null;
  const equals = html.indexOf('=', marker);
  if (equals < 0) return null;
  const start = html.indexOf('{', equals);
  if (start < 0) return null;
  let depth = 0; let inString = false; let escaped = false;
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(html.slice(start, i + 1)); } catch { return null; }
      }
    }
  }
  return null;
}

function findNuxtDetail(payload: any): any | null {
  if (!payload || typeof payload !== 'object') return null;
  if (payload.__detail__ && typeof payload.__detail__ === 'object' && (payload.__detail__.discount_price !== undefined || payload.__detail__.price !== undefined) && payload.__detail__.name) return payload.__detail__;
  for (const value of Object.values(payload)) {
    const found = findNuxtDetail(value);
    if (found) return found;
  }
  return null;
}

function findNuxtStock(payload: any, productId: any): number | undefined {
  if (!payload || typeof payload !== 'object') return undefined;
  if (String(payload.id ?? payload.product_id ?? '') === String(productId) && payload.stock !== undefined) {
    const parsed = kasraNumber(payload.stock);
    if (parsed !== undefined) return parsed;
  }
  for (const value of Object.values(payload)) {
    const found = findNuxtStock(value, productId);
    if (found !== undefined) return found;
  }
  return undefined;
}

export function parseKasraProductPage(html: string, fallback: any = {}): any {
  const nuxt = extractNuxtPayload(html);
  const detail = findNuxtDetail(nuxt);
  const detailStock = detail ? (kasraNumber(detail.stock) ?? findNuxtStock(nuxt, detail.id)) : undefined;
  const decoded = decodeXmlEntity(html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (script) => {
    return /__NUXT__|application\/json|application\/ld\+json/i.test(script) ? script.replace(/<\/?script\b[^>]*>/gi, ' ') : ' ';
  }));
  const readNumericField = (key: string): number | undefined => {
    const match = decoded.match(new RegExp(`[\"']${key}[\"']\\s*:\\s*(?:\"([0-9۰-۹٠-٩,٬.]+)\"|([0-9۰-۹٠-٩,٬.]+))`, 'i'));
    return match ? kasraNumber(match[1] ?? match[2]) : undefined;
  };
  const candidates: number[] = [];
  for (const match of decoded.matchAll(/"(?:discount_price|discountPrice|sellingPrice|selling_price|currentPrice|current_price|finalPrice|final_price|salePrice|sale_price|price)"\s*:\s*"?([0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.]{3,})/gi)) {
    const n = kasraNumber(match[1]); if (n && n > 0) candidates.push(n);
  }
  // Restrict rendered/visible price parsing to the main product block. A whole-page
  // minimum can accidentally pick a cheaper related-product card instead of this item.
  const visibleHtmlFull = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ');
  const h1At = visibleHtmlFull.search(/<h1\b/i);
  const mainStart = h1At >= 0 ? h1At : 0;
  const afterTitle = visibleHtmlFull.slice(mainStart);
  const cartControl = /(?:id=[\"']AddToBasket|add-to-cart|افزودن\s*به\s*سبد(?:\s*خرید)?)/i.exec(afterTitle);
  const mainEnd = cartControl
    ? Math.min(visibleHtmlFull.length, mainStart + cartControl.index + cartControl[0].length)
    : Math.min(visibleHtmlFull.length, mainStart + 5000);
  const priceScopeHtml = visibleHtmlFull.slice(mainStart, mainEnd);
  const visibleScope = decodeXmlEntity(priceScopeHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '));
  const visiblePrices = [...visibleScope.matchAll(/([0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.]{4,})\s*(?:تومان|ریال)/gi)]
    .map((m) => kasraNumber(m[1])).filter((n): n is number => Boolean(n && n > 0));
  // The current storefront renders price numbers inside SSR spans without a nearby
  // currency label or inline __NUXT__ JSON. Prefer numeric spans in the main product
  // block, not numbers from related/recommended product cards elsewhere on the page.
  const renderedSpanPrices: number[] = [];
  const visibleHtml = priceScopeHtml;
  for (const match of visibleHtml.matchAll(/<span\b([^>]*)>([\s\S]*?)<\/span>/gi)) {
    const attrs = match[1] || '';
    const rawText = decodeXmlEntity(match[2].replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').trim());
    if (!/^[0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.\s]*$/.test(rawText)) continue;
    const value = kasraNumber(rawText);
    if (!value || value < 100000) continue;
    const pos = match.index ?? 0;
    const nearby = visibleHtml.slice(Math.max(0, pos - 700), Math.min(visibleHtml.length, pos + match[0].length + 700));
    if (/price|قیمت|تومان|ریال|discount|line-through|text-(?:xl|2xl|3xl)|font-bold|font-semibold/i.test(`${attrs} ${nearby}`)) renderedSpanPrices.push(value);
  }
  const detailCurrentPrice = detail ? [detail.discount_price, detail.discountPrice, detail.final_price, detail.finalPrice, detail.sale_price, detail.salePrice, detail.price].map((v) => kasraNumber(v)).find((v) => v !== undefined && v > 0) : undefined;
  const discountField = [readNumericField('discount_price'), readNumericField('discountPrice'), readNumericField('final_price'), readNumericField('sale_price')].find((v) => v !== undefined && v > 0);
  const renderedCurrentPrice = renderedSpanPrices.length ? Math.min(...renderedSpanPrices) : undefined;
  const price = detailCurrentPrice ?? discountField ?? (visiblePrices.length ? Math.min(...visiblePrices) : undefined) ?? renderedCurrentPrice ?? candidates.find((v) => v > 0) ?? (Number(fallback.price) || 0);
  const detailOut = detail && (detail.is_active === 0 || detail.is_active === false || detail.is_publish === 0 || detail.is_publish === false);
  const stockFallback = detailStock ?? readNumericField('stock');
  const activeFallback = readNumericField('is_active');
  const publishFallback = readNumericField('is_publish');
  const fallbackHasStockEvidence = stockFallback !== undefined || activeFallback !== undefined || publishFallback !== undefined;
  const detailInStock = detailStock !== undefined ? detailStock > 0 && !detailOut : fallbackHasStockEvidence ? (stockFallback === undefined || stockFallback > 0) && activeFallback !== 0 && publishFallback !== 0 : undefined;
  const outOfStock = detailInStock !== undefined ? !detailInStock : /outofstock|ناموجود|اتمام\s*موجودی|عدم\s*موجودی|sold\s*out/i.test(decoded);
  const inStockSignal = detailInStock !== undefined ? detailInStock : /inStock|instock|افزودن\s*به\s*سبد|افزودن به سبد خرید|موجود\s*است|موجودی\s*کافی/i.test(decoded);
  const title = detail?.name || decoded.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]
    || decoded.match(/"(?:product_name|productName|title|name)"\s*:\s*"([^"\\]{3,})"/i)?.[1];
  const cleanTitle = title ? String(title).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : '';
  const category = detail?.category?.name || detail?.category_name || decoded.match(/\"category\"\s*:\s*\{[^}]{0,500}?\"name\"\s*:\s*\"([^\"]+)\"/i)?.[1] || fallback.category;
  const imageRaw = detail?.image || detail?.image_full || fallback.image;
  const image = imageRaw ? (/^https?:\/\//i.test(String(imageRaw)) ? String(imageRaw) : `https://cdn.kasratel.ir${String(imageRaw).startsWith('/') ? '' : '/'}${imageRaw}`) : fallback.image;
  const variants = Array.isArray(detail?.available_variations) ? detail.available_variations : fallback.variants;
  return {
    ...fallback,
    ...(cleanTitle ? { title: decodeXmlEntity(cleanTitle), name: decodeXmlEntity(cleanTitle), persianName: decodeXmlEntity(cleanTitle) } : {}),
    ...(category ? { category, categoryName: category, category_name: category } : {}),
    ...(image ? { image, images: [image, ...(Array.isArray(detail?.image_gallery) ? detail.image_gallery.map((v: string) => /^https?:\/\//i.test(v) ? v : `https://cdn.kasratel.ir${v.startsWith('/') ? '' : '/'}${v}`) : [])].filter((v, i, a) => a.indexOf(v) === i) } : {}),
    ...(detail?.sku ? { sku: detail.sku } : {}),
    price,
    sourcePrice: price,
    priceMissing: !(price > 0),
    inStock: !outOfStock && inStockSignal,
    stock: stockFallback ?? (!outOfStock && inStockSignal ? 1 : 0),
    site_visible: !outOfStock && inStockSignal ? 1 : 0,
    ...(Array.isArray(variants) ? { variants } : {}),
    sourceUrl: fallback.sourceUrl || (fallback.slug ? `https://plus.kasrapars.ir/product/${fallback.slug}` : undefined),
  };
}

let kasraCatalogCache: { at: number; items: any[]; meta: Record<string, number> } | null = null;
const KASRA_CACHE_TTL_MS = 4 * 60 * 1000; // Refresh cache before the 5-minute polling cycle.

export const KasraAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'kasra',
  name: 'کسری پلاس (Kasra Plus)',
  async fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string; meta?: Record<string, number> }> {
    if (String(supplier.baseUrl || '').includes('api.kasrapars.ir') && kasraCatalogCache && Date.now() - kasraCatalogCache.at < KASRA_CACHE_TTL_MS) {
      return { success: true, items: kasraCatalogCache.items.map((item) => ({ ...item })), meta: { ...kasraCatalogCache.meta } };
    }
    // Fetch every page. Any ambiguous/failed pagination is treated as a failed sync,
    // never as a successful partial catalog, so existing stock is not incorrectly cleared.
    const PAGE_SIZE = 100;
    const MAX_PAGES = 1000;
    const allItems: any[] = [];
    const categoryNames = new Map<string, string>();
    const seenIds = new Set<string>();
    let page = 1;
    let expectedPageCount: number | undefined;
    let expectedTotalCount: number | undefined;

    while (page <= MAX_PAGES) {
      const base = new URL(supplier.baseUrl);
      base.searchParams.set('per-page', String(PAGE_SIZE));
      base.searchParams.set('per_page', String(PAGE_SIZE));
      base.searchParams.set('page', String(page));

      const res = await fetchJson<any>(base.toString(), 15000);
      if (!res.data) return { success: false, items: [], error: res.error || `خطا در دریافت صفحه ${page} از ${supplier.name}` };

      const extracted = kasraExtractPage(res.data);
      const categoryRows = res.data?.filters?.leafCategories || res.data?.filters?.categories || res.data?.dataProvider?.filters?.leafCategories || [];
      const categoryList = Array.isArray(categoryRows) ? categoryRows : categoryRows?.item ? (Array.isArray(categoryRows.item) ? categoryRows.item : [categoryRows.item]) : categoryRows && typeof categoryRows === 'object' && (categoryRows.id || categoryRows.category_id) ? [categoryRows] : [];
      for (const c of categoryList) {
        const id = String(c?.id ?? c?.category_id ?? ''); const label = String(c?.name ?? c?.category_name ?? c?.title ?? '');
        if (id && label) categoryNames.set(id, label);
      }
      if (!extracted.recognized) {
        return { success: false, items: [], error: `قالب پاسخ API کسری پلاس در صفحه ${page} قابل تشخیص نیست؛ از همگام‌سازی ناقص جلوگیری شد.` };
      }
      if (extracted.pageCount !== undefined) expectedPageCount = extracted.pageCount;
      if (extracted.totalCount !== undefined) expectedTotalCount = extracted.totalCount;
      const pageItems = extracted.items;
      if (pageItems.length === 0) {
        if ((expectedPageCount !== undefined && page < expectedPageCount) || extracted.hasMore === true) {
          return { success: false, items: [], error: `API کسری پلاس در صفحه ${page} پیش از پایان اعلام‌شده کاتالوگ، صفحهٔ خالی برگرداند.` };
        }
        break;
      }

      let addedThisPage = 0;
      for (const item of pageItems) {
        const key = String(item?.id ?? item?.product_id ?? item?.productId ?? item?.uuid ?? item?.sku ?? item?.barcode ?? '');
        if (!key) {
          return { success: false, items: [], error: `حداقل یک کالا در صفحه ${page} فاقد شناسهٔ قابل اتکاست؛ از ورود ناقص کاتالوگ جلوگیری شد.` };
        }
        if (!seenIds.has(key)) { seenIds.add(key); allItems.push(item); addedThisPage++; }
      }
      if (pageItems.length === 0) break;
      if (expectedPageCount !== undefined && page >= expectedPageCount) break;
      if (extracted.hasMore === false) break;
      if (expectedPageCount === undefined && expectedTotalCount !== undefined && allItems.length >= expectedTotalCount) break;
      // Without pagination metadata, even a short page is not proof that the source has no more pages.
      // Probe the next page; an empty page ends the feed, while repeated/non-advancing pages fail safely.
      if (addedThisPage === 0) {
        return { success: false, items: [], error: `صفحهٔ ${page} از API کسری پلاس تکراری بود؛ احتمال نادیده‌گرفتن شمارهٔ صفحه وجود دارد، بنابراین کاتالوگ ناقص پذیرفته نشد.` };
      }
      page++;
    }

    if (page > MAX_PAGES) return { success: false, items: [], error: `کاتالوگ کسری پلاس از سقف ایمن ${MAX_PAGES} صفحه بیشتر شد؛ همگام‌سازی ناقص پذیرفته نشد.` };
    if (expectedTotalCount !== undefined && allItems.length < expectedTotalCount) {
      return { success: false, items: [], error: `کاتالوگ ناقص دریافت شد: ${allItems.length} کالا از ${expectedTotalCount} کالای اعلام‌شده.` };
    }
    if (allItems.length === 0) return { success: false, items: [], error: 'API کسری پلاس کاتالوگ خالی برگرداند؛ برای جلوگیری از ناموجودشدن اشتباه کالاها، همگام‌سازی انجام نشد.' };

    const normalizedItems = allItems.map((raw: any) => {
      const category = categoryNames.get(String(raw?.category_id ?? raw?.categoryId ?? ''));
      return normalizeKasraProduct({ ...raw, category: raw?.category ?? category, categoryName: raw?.categoryName ?? category, category_name: raw?.category_name ?? category });
    }).filter((it: any) => it.id !== undefined && it.id !== null && String(it.id).trim() !== '');

    // The public catalog endpoint contains identity/image/category metadata but omits price and stock.
    // Enrich those records from the corresponding public storefront detail pages; never invent prices.
    let cursor = 0;
    const workers = Array.from({ length: Math.min(4, normalizedItems.length) }, async () => {
      while (cursor < normalizedItems.length) {
        const index = cursor++; const item = normalizedItems[index];
        if (Number(item.price) > 0 && item.stockKnown) continue;
        const slug = String(item.slug || item.url_slug || '');
        if (!slug) { item.priceMissing = !(Number(item.price) > 0); continue; }
        const url = `https://plus.kasrapars.ir/product/${encodeURIComponent(slug)}`;
        const page = await fetchKasraPage(url, 20000);
        if (page.ok) {
          const enriched = parseKasraProductPage(page.text, { ...item, sourceUrl: url });
          normalizedItems[index] = { ...enriched, category: item.category, categoryName: item.categoryName, category_name: item.category_name, supplierId: 'kasra', supplierName: 'کسری پلاس (Kasra Plus)' };
        } else { item.priceMissing = !(Number(item.price) > 0); item.detailFetchError = `HTTP ${page.status || 'network'}`; }
      }
    });
    await Promise.all(workers);
    const productsNeedingPriceCount = normalizedItems.filter((it: any) => !(Number(it.price) > 0)).length;
    // A complete identity catalog remains useful even when an individual price
    // cannot be read: core sync imports such rows as inactive `needs_price` records.
    // Do not discard all 324 products just because price parsing needs admin review.
    const meta = { sourceUrlCount: normalizedItems.length, productsNeedingPriceCount, priceExtractionFailedCount: productsNeedingPriceCount };
    // Do not cache a badly degraded price snapshot. Otherwise a first run that
    // cannot parse prices can poison every manual retry for the full cache TTL.
    const maxMissingPricesForCache = Math.max(3, Math.ceil(normalizedItems.length * 0.1));
    if (String(supplier.baseUrl || '').includes('api.kasrapars.ir')) {
      if (productsNeedingPriceCount <= maxMissingPricesForCache) {
        kasraCatalogCache = { at: Date.now(), items: normalizedItems.map((item: any) => ({ ...item })), meta };
      } else {
        kasraCatalogCache = null;
        console.warn(`[KasraAdapter] Not caching degraded catalogue: ${productsNeedingPriceCount}/${normalizedItems.length} products have no extracted price; next sync will retry detail pages.`);
      }
    }
    return { success: true, items: normalizedItems, meta };
  },
};

let hamrahTelTokenCache: { token: string; expiresAt: number } | null = null;

export function clearHamrahTelTokenCache() {
  hamrahTelTokenCache = null;
}

async function getHamrahTelAuthToken(supplier?: Supplier): Promise<string | null> {
  const now = Date.now();
  if (hamrahTelTokenCache && hamrahTelTokenCache.expiresAt > now + 60000) {
    return hamrahTelTokenCache.token;
  }

  const url = supplier?.baseUrl && supplier.baseUrl.includes('graphql') ? supplier.baseUrl : 'https://core-api.hamrahtel.com/graphql/';
  const query = `
    mutation TokenCreate($phoneNumber: String!, $password: String!) {
      tokenCreate(phoneNumber: $phoneNumber, password: $password) {
        token
        errors {
          message
        }
      }
    }
  `;
  const phoneNumber = supplier?.username || process.env.HAMRAHTEL_PHONE;
  const password = supplier?.password || process.env.HAMRAHTEL_PASSWORD;
  if (!phoneNumber || !password) return null;
  const body = JSON.stringify({
    query,
    variables: { phoneNumber, password },
  });

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
      body,
    });
    const data = (await res.json()) as any;
    const token = data?.data?.tokenCreate?.token;
    if (token) {
      hamrahTelTokenCache = { token, expiresAt: now + 7 * 24 * 3600 * 1000 };
      return token;
    }
  } catch (err) {
    console.error('Hamrah Tel Auth Error:', err);
  }
  return null;
}

export const HamrahTelAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'hamrahtel',
  name: 'همراه تل (Hamrah Tel)',
  async fetchCatalog(supplier: Supplier) {
    if (!supplier.enabled) {
      return { success: false, items: [], error: 'تأمین‌کننده غیرفعال است' };
    }

    try {
      const token = await getHamrahTelAuthToken(supplier);
      if (!token) {
        return {
          success: false,
          items: [],
          error: 'خطا در احراز هویت با نام کاربری و رمز عبور همراه تل',
        };
      }

            // Fetch mobile category (140+ phones) + root products + targeted searches for current store products
      const queryCombined = `
        query GetCombinedProducts($first: Int!) {
          mobileCategory: category(slug: "mobile") {
            products(first: $first) {
              edges {
                node {
                  id
                  name
                  slug
                  thumbnail {
                    url
                  }
                  variants {
                    id
                    name
                    sku
                    pricing {
                      price {
                        gross {
                          amount
                          currency
                        }
                      }
                    }
                    quantityAvailable
                  }
                }
              }
            }
          }
          rootProducts: products(first: $first) {
            edges {
              node {
                id
                name
                slug
                thumbnail {
                  url
                }
                variants {
                  id
                  name
                  sku
                  pricing {
                    price {
                      gross {
                        amount
                        currency
                      }
                    }
                  }
                  quantityAvailable
                }
              }
            }
          }
        }
      `;

      const res = await fetch('https://core-api.hamrahtel.com/graphql/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `JWT ${token}`,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        },
        body: JSON.stringify({ query: queryCombined, variables: { first: 100 } }),
      });

      const data = (await res.json()) as any;
      const mobileEdges = data?.data?.mobileCategory?.products?.edges || [];
      const rootEdges = data?.data?.rootProducts?.edges || [];
      const nodeMap = new Map<string, any>();
      for (const e of [...mobileEdges, ...rootEdges]) {
        if (e?.node?.id) nodeMap.set(e.node.id, e.node);
      }

      // If main query yielded products, no need for hundreds of slow individual queries
      if (nodeMap.size === 0) {
        try {
          const storeProducts = readJsonFile<any[]>(path.join(DATA_DIR, 'products.json'), []);
          for (const p of storeProducts.slice(0, 15)) {
            const searchKey = p.model || (p.name || "").match(/\b(A\d+|S\d+|iPhone\s*\d+|Note\s*\d+)/i)?.[0];
          if (searchKey) {
            const searchQuery = `
              query SearchP($search: String!) {
                products(first: 10, filter: { search: $search }) {
                  edges {
                    node {
                      id
                      name
                      slug
                      variants {
                        id
                        name
                        sku
                        pricing {
                          price {
                            gross {
                              amount
                              currency
                            }
                          }
                        }
                        quantityAvailable
                      }
                    }
                  }
                }
              }
            `;
            const sRes = await fetch('https://core-api.hamrahtel.com/graphql/', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `JWT ${token}`,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
              },
              body: JSON.stringify({ query: searchQuery, variables: { search: searchKey } }),
            });
            const sData = (await sRes.json()) as any;
            for (const se of sData?.data?.products?.edges || []) {
              if (se?.node?.id) nodeMap.set(se.node.id, se.node);
            }
          }
        }
      } catch (err) {
        console.warn("Targeted Hamrah Tel search error:", err);
      }
    }

      const edges = Array.from(nodeMap.values()).map(n => ({ node: n }));
      const items: any[] = [];

      for (const edge of edges) {
        const node = edge.node;
        if (!node) continue;

        const variants = (node.variants || []).map((v: any) => {
          const rawPrice = v.pricing?.price?.gross?.amount ? Math.round(Number(v.pricing.price.gross.amount)) : 0;
          const stock = Number(v.quantityAvailable || 0);
          return {
            id: v.id,
            name: v.name || 'پیش‌فرض',
            color: v.name || 'پیش‌فرض',
            color_name: v.name || 'پیش‌فرض',
            sku: v.sku,
            price: rawPrice,
            stock,
            inStock: stock > 0,
          };
        });

        const activeVariant = variants.find((v: any) => v.price > 0 && v.inStock) || variants[0];
        const defaultPrice = activeVariant ? activeVariant.price : 0;
        const totalStock = variants.reduce((sum: number, v: any) => sum + (v.stock || 0), 0);

        const img = node.thumbnail?.url || '';
        items.push({
          id: node.id,
          name: node.name,
          title: node.name,
          persianName: node.name,
          slug: node.slug,
          sku: node.variants?.[0]?.sku,
          price: defaultPrice,
          stock: totalStock,
          image: img,
          images: img ? [img] : [],
          variants,
        });
      }

      return { success: true, items };
    } catch (err: any) {
      return {
        success: false,
        items: [],
        error: `خطا در دریافت کاتالوگ همراه تل: ${err?.message || err}`,
      };
    }
  },
};

// The source catalog is crawled from Ehadish's public sitemap. Cache a complete
// successful snapshot to avoid downloading every product page on each 5-minute sync.
let ehadishCatalogCache: { at: number; items: any[]; meta: Record<string, number> } | null = null;
const EHADISH_CACHE_TTL_MS = 4 * 60 * 1000; // Refresh cache before the 5-minute polling cycle.
const EHADISH_TIMEOUT_MS = 25000;
// Ehadish intermittently rate-limits bursts; a smaller worker pool plus retry avoids
// rejecting a complete sitemap because one or two product pages timed out.
const EHADISH_CONCURRENCY = 4;

function decodeEhadishText(raw: string): string {
  return String(raw || '')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&').replace(/&quot;|&#34;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
    .replace(/&#x([0-9a-f]+);/gi, (_m, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)))
    .replace(/[\u200b-\u200f\ufeff]/g, '').replace(/\s+/g, ' ').trim();
}

function ehadishNumber(raw: string | undefined): number | undefined {
  if (!raw) return undefined;
  const normalized = raw.replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632));
  const digits = normalized.replace(/[^0-9]/g, '');
  if (!digits) return undefined;
  const n = Number(digits);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

async function fetchEhadishText(url: string): Promise<{ ok: boolean; status: number; text: string; error?: string }> {
  let last: { ok: boolean; status: number; text: string; error?: string } = { ok: false, status: 0, text: '', error: 'خطای شبکه' };
  // Retry transient network, timeout, throttling and server errors. A genuine 404
  // is returned immediately because stale URLs are expected in a large sitemap.
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 PuzzleKalaSupplierSync/1.1',
          Accept: 'text/html,application/xml,application/xhtml+xml,*/*;q=0.8',
          'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.7',
          'Cache-Control': 'no-cache',
        },
        signal: AbortSignal.timeout(EHADISH_TIMEOUT_MS),
      });
      if (response.ok) return { ok: true, status: response.status, text: await response.text() };
      last = { ok: false, status: response.status, text: '', error: `HTTP ${response.status}` };
      if (response.status === 404) return last;
      const retryableStatus = response.status >= 500 || [403, 408, 425, 429].includes(response.status);
      if (!retryableStatus) return last;
    } catch (err: any) {
      last = { ok: false, status: 0, text: '', error: err?.message || 'خطای شبکه' };
    }
    if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 500 * (2 ** attempt)));
  }
  return last;
}

function sitemapLocs(xml: string): string[] {
  return [...xml.matchAll(/<loc>\s*([^<]+?)\s*<\/loc>/gi)].map((m) => decodeEhadishText(m[1])).filter(Boolean);
}

function isEhadishHost(hostname: string): boolean {
  const host = hostname.toLowerCase();
  return host === 'ehadish.com' || host.endsWith('.ehadish.com');
}

async function crawlEhadishCategoryListings(base: URL): Promise<string[]> {
  const home = await fetchEhadishText(base.toString());
  if (!home.ok) throw new Error(`صفحهٔ اصلی هدیش هم قابل دریافت نیست: ${home.error || home.status}`);
  const productUrls = new Set<string>();
  const categoryQueue: string[] = [];
  const seenCategories = new Set<string>();
  const collectLinks = (html: string, fromUrl: string) => {
    for (const match of html.matchAll(/(?:href|data-href)\s*=\s*["']([^"']+)["']/gi)) {
      const raw = decodeEhadishText(match[1]);
      try {
        const parsed = new URL(raw, fromUrl);
        if (!isEhadishHost(parsed.hostname)) continue;
        // Product detail URLs are singular /product/...; plural /products/... are listings.
        if (/^\/product\//i.test(parsed.pathname) && /\/\d+[-/]/.test(parsed.pathname)) {
          productUrls.add(parsed.toString());
        } else if (/^\/products\//i.test(parsed.pathname)) {
          parsed.hash = '';
          if (!seenCategories.has(parsed.toString())) categoryQueue.push(parsed.toString());
        }
      } catch { /* ignore malformed hrefs */ }
    }
  };
  collectLinks(home.text, base.toString());

  // Sitemap access is not reliable on every host. Crawl public category/list pages as a
  // fallback, including pagination links; never treat a category page as a product.
  const MAX_CATEGORY_PAGES = 1200;
  const CONCURRENCY = 10;
  while (categoryQueue.length && seenCategories.size < MAX_CATEGORY_PAGES) {
    const batch: string[] = [];
    while (categoryQueue.length && batch.length < CONCURRENCY && seenCategories.size + batch.length < MAX_CATEGORY_PAGES) {
      const next = categoryQueue.shift()!;
      if (seenCategories.has(next)) continue;
      seenCategories.add(next);
      batch.push(next);
    }
    const pages = await Promise.all(batch.map(async (url) => ({ url, response: await fetchEhadishText(url) })));
    for (const { url, response } of pages) {
      if (response.ok) collectLinks(response.text, url);
    }
  }
  if (!productUrls.size) throw new Error('نه نقشهٔ سایت قابل استفاده بود و نه از صفحات دسته‌بندی هدیش نشانی محصول استخراج شد.');
  return [...productUrls];
}

async function getEhadishProductUrls(baseUrl: string): Promise<string[]> {
  const base = new URL(baseUrl);
  const robots = await fetchEhadishText(new URL('/robots.txt', base).toString());
  const declared: string[] = [];
  if (robots.ok) {
    for (const line of robots.text.split(/\r?\n/)) {
      const match = line.match(/^\s*sitemap\s*:\s*(\S+)/i);
      if (!match) continue;
      try {
        const parsed = new URL(match[1], base);
        if (isEhadishHost(parsed.hostname) && /\.xml(?:\?|$)/i.test(parsed.href)) declared.push(parsed.toString());
      } catch { /* malformed sitemap declaration */ }
    }
  }

  const fallback = ['/sitemap.xml', '/sitemap_index.xml', '/sitemap-index.xml', '/wp-sitemap.xml']
    .map((candidate) => new URL(candidate, base).toString());
  const rootCandidates = [...new Set(declared.length ? declared : fallback)];
  const queue: string[] = [];
  const fetchedRootText = new Map<string, string>();
  for (const candidate of rootCandidates) {
    const response = await fetchEhadishText(candidate);
    if (!response.ok) continue;
    if (!/<(?:sitemapindex|urlset)\b/i.test(response.text) || !sitemapLocs(response.text).length) continue;
    queue.push(candidate);
    fetchedRootText.set(candidate, response.text);
  }
  if (!queue.length && declared.length) {
    // A robots.txt entry may be stale; try the common alternatives before failing.
    for (const candidate of fallback) {
      const response = await fetchEhadishText(candidate);
      if (!response.ok || !/<(?:sitemapindex|urlset)\b/i.test(response.text) || !sitemapLocs(response.text).length) continue;
      if (!fetchedRootText.has(candidate)) {
        queue.push(candidate);
        fetchedRootText.set(candidate, response.text);
      }
    }
  }
  if (!queue.length) {
    console.warn('[EhadishAdapter] Sitemap unavailable; falling back to public category listings.');
    return crawlEhadishCategoryListings(base);
  }

  const seenSitemaps = new Set<string>();
  const productUrls = new Set<string>();
  const MAX_SITEMAPS = 2000;
  while (queue.length) {
    const sitemapUrl = queue.shift()!;
    if (seenSitemaps.has(sitemapUrl)) continue;
    if (seenSitemaps.size >= MAX_SITEMAPS) throw new Error(`تعداد نقشه‌های سایت از سقف ایمن ${MAX_SITEMAPS} بیشتر شد؛ کاتالوگ کامل تأیید نشد.`);
    seenSitemaps.add(sitemapUrl);
    let xml = fetchedRootText.get(sitemapUrl);
    if (xml === undefined) {
      const response = await fetchEhadishText(sitemapUrl);
      if (!response.ok) throw new Error(`دریافت نقشهٔ سایت هدیش ناموفق بود: ${sitemapUrl} — ${response.error || response.status}`);
      xml = response.text;
    }
    const locs = sitemapLocs(xml);
    if (/<sitemapindex\b/i.test(xml)) {
      for (const loc of locs) {
        try {
          const parsed = new URL(loc);
          if (isEhadishHost(parsed.hostname) && /\.xml(?:\?|$)/i.test(parsed.href)) queue.push(parsed.toString());
        } catch { /* invalid sitemap loc is ignored; valid entries continue */ }
      }
      continue;
    }
    for (const loc of locs) {
      try {
        const parsed = new URL(loc);
        if (!isEhadishHost(parsed.hostname)) continue;
        const pathName = parsed.pathname.toLowerCase();
        if (/\/product\//i.test(pathName) || /\/product-[^/]+\/?$/i.test(pathName)) {
          productUrls.add(parsed.toString());
        }
      } catch { /* invalid product loc is ignored */ }
    }
  }
  if (!productUrls.size) {
    console.warn('[EhadishAdapter] Sitemap had no product detail URLs; falling back to public category listings.');
    return crawlEhadishCategoryListings(base);
  }
  return [...productUrls];
}

function isEhadishHandsetRow(item: any): boolean {
  const title = String(item?.title || item?.name || item?.persianName || item?.product_name || '');
  const category = String(item?.category || item?.subcategory || '');
  const url = String(item?.sourceUrl || item?.url || 'https://www.ehadish.com/');
  const accessory = /accessor|لوازم\s*جانبی|قاب|کاور|کیف\s*موبایل|شارژر|کابل|گلس|محافظ\s*صفحه|هولدر|پایه\s*نگهدارنده|screen\s*protector|phone\s*case|mobile\s*case|charger|usb\s*cable/i.test(`${category} ${title}`);
  if (accessory) return false;
  let pathCategory = '';
  try { pathCategory = new URL(url).pathname.match(/category-([^/]+)/i)?.[1] || ''; } catch {}
  const mobileCategory = /گوشی\s*موبایل|گوشی\s*تلفن|تلفن\s*همراه|smartphone|mobile\s*phone|cell\s*phone/i.test(`${category} ${title}`)
    || /(?:^|[-\s])(?:mobile|mobiles|phone|phones|smartphone|smartphones|cellphone)(?:$|[-\s])/i.test(pathCategory);
  const knownHandsetModel = /\b(?:iphone\s*\d|galaxy\s*(?:s|a|z|m|f)\s*\d{1,3}|redmi\s*(?:note\s*)?\d{1,3}|poco\s*[fxmc]\s*\d{1,3}|pixel\s*\d{1,3}|oneplus\s*\d{1,3}|xiaomi\s*\d{1,2}|huawei\s*(?:mate|nova|p|y)\s*\d{1,3}|honor\s*(?:magic|x|play)?\s*\d{1,3}|realme\s*(?:gt|c)?\s*\d{1,3}|oppo\s*(?:reno|find|a|f|k)?\s*\d{1,3}|vivo\s*(?:x|v|y|t)?\s*\d{1,3}|infinix\s*(?:note|hot|smart|zero|gt)\s*\d{0,3}|tecno\s*(?:spark|camon|pova|phantom)\s*\w*|nokia\s*\d{2,4}|motorola\s*(?:edge|moto\s*g|razr)\s*\d{1,3})\b/i.test(title);
  return mobileCategory || (!accessory && knownHandsetModel);
}

function isEhadishPhoneHandset(html: string, url: string): boolean {
  const u = new URL(url);
  const pathCategory = (u.pathname.match(/category-([^/]+)/i)?.[1] || '').toLowerCase();
  const titleRaw = html.match(/id=["']?ProductNameFa["']?\s*>\s*([^<]+)</i)?.[1]
    || html.match(/class=["'][^"']*productNameFa[^"']*["']\s*>\s*([^<]+)</i)?.[1]
    || html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]
    || html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] || '';
  const title = decodeEhadishText(titleRaw);
  const categoryRaw = html.match(/class=["'][^"']*cat[^"']*["'][^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i)?.[1] || '';
  const category = decodeEhadishText(categoryRaw);
  const text = `${category} ${pathCategory} ${title}`;
  const accessory = /accessor|لوازم\s*جانبی|قاب|کاور|کیف\s*موبایل|شارژر|کابل|گلس|محافظ\s*صفحه|هولدر|پایه\s*نگهدارنده|screen\s*protector|phone\s*case|mobile\s*case|charger|usb\s*cable/i.test(text);
  if (accessory) return false;
  const mobileCategory = /(?:^|[-\s])(?:mobile|mobiles|phone|phones|smartphone|smartphones|cellphone)(?:$|[-\s])/i.test(pathCategory)
    || /گوشی\s*موبایل|گوشی\s*تلفن|تلفن\s*همراه|smartphone|mobile\s*phone|cell\s*phone/i.test(`${category} ${title}`);
  const knownHandsetModel = /\b(?:iphone\s*\d|galaxy\s*(?:s|a|z|m|f)\s*\d{1,3}|redmi\s*(?:note\s*)?\d{1,3}|poco\s*[fxmc]\s*\d{1,3}|pixel\s*\d{1,3}|oneplus\s*\d{1,3}|xiaomi\s*\d{1,2}|huawei\s*(?:mate|nova|p|y)\s*\d{1,3}|honor\s*(?:magic|x|play)?\s*\d{1,3}|realme\s*(?:gt|c)?\s*\d{1,3}|oppo\s*(?:reno|find|a|f|k)?\s*\d{1,3}|vivo\s*(?:x|v|y|t)?\s*\d{1,3}|infinix\s*(?:note|hot|smart|zero|gt)\s*\d{0,3}|tecno\s*(?:spark|camon|pova|phantom)\s*\w*|nokia\s*\d{2,4}|motorola\s*(?:edge|moto\s*g|razr)\s*\d{1,3})\b/i.test(title);
  return mobileCategory || (!accessory && knownHandsetModel);
}

export function parseEhadishProduct(html: string, url: string): any | null {
  const urlObj = new URL(url);
  const lastPath = urlObj.pathname.split('/').filter(Boolean).pop() || '';
  const idMatch = lastPath.match(/(?:^|[-/])(\d+)(?:-|$)/) || urlObj.pathname.match(/\/(\d+)-/);
  // Some supplier URLs use a slug without a numeric product ID. Derive a stable
  // internal key from the canonical path instead of silently dropping the product.
  const id = idMatch?.[1] || `url-${createHash('sha1').update(urlObj.pathname.toLowerCase()).digest('hex').slice(0, 12)}`;

  const titleRaw = html.match(/id=["']?ProductNameFa["']?\s*>\s*([^<]+)</i)?.[1]
    || html.match(/class=["'][^"']*productNameFa[^"']*["']\s*>\s*([^<]+)</i)?.[1]
    || html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]
    || html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1];
  const title = decodeEhadishText(titleRaw || '');
  if (title.length < 3) return null;

  const structuredPrices: string[] = [];
  // Supplier pages may publish price only in Product/Offer JSON-LD, even when the
  // visible price widget is rendered by client-side JavaScript.
  for (const match of html.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const parsed = JSON.parse(match[1]);
      const visit = (node: any) => {
        if (!node || typeof node !== 'object') return;
        if (Array.isArray(node)) { node.forEach(visit); return; }
        const type = Array.isArray(node['@type']) ? node['@type'].join(' ') : String(node['@type'] || '');
        if (/Product|Offer|AggregateOffer/i.test(type)) {
          const offer = node.offers;
          for (const value of [node.price, node.lowPrice, node.highPrice, node.priceSpecification?.price,
            ...(Array.isArray(offer) ? offer.flatMap((o: any) => [o?.price, o?.lowPrice, o?.highPrice]) : [offer?.price, offer?.lowPrice, offer?.highPrice])]) {
            if (value !== undefined && value !== null) structuredPrices.push(String(value));
          }
        }
        Object.values(node).forEach(visit);
      };
      visit(parsed);
    } catch { /* malformed JSON-LD is ignored; other price signals are still checked */ }
  }
  const visibleTextForPrice = decodeEhadishText(html);
  const visiblePrice = visibleTextForPrice.match(/(?:قیمت|price)\s*[:：]?\s*([0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.]{4,})\s*(?:تومان|ریال)?/i)?.[1];
  const currencyPrice = visibleTextForPrice.match(/([0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.]{5,})\s*(?:تومان|ریال)/i)?.[1];
  const priceCandidates = [
    ...structuredPrices,
    visiblePrice,
    currencyPrice,
    html.match(/<meta[^>]*(?:property|name)=["'](?:product:price:amount|og:price:amount)["'][^>]*content=["']([^"']+)/i)?.[1],
    html.match(/<meta[^>]*content=["']([^"']+)["'][^>]*(?:property|name)=["'](?:product:price:amount|og:price:amount)["']/i)?.[1],
    html.match(/itemprop=["']price["'][^>]*content=["']([^"']+)/i)?.[1],
    html.match(/content=["']([^"']+)["'][^>]*itemprop=["']price["']/i)?.[1],
    html.match(/(?:data-price|data-product-price|data-price-value)=["']([^"']+)/i)?.[1],
    html.match(/class=["'][^"']*bx-price[^"']*["'][^>]*>([\s\S]{0,180}?)<\//i)?.[1],
    html.match(/class=bx-price[^>]*>([\s\S]{0,180}?)<\//i)?.[1],
    html.match(/class=["'][^"']*(?:product-price|price-current|price)[^"']*["'][^>]*>([\s\S]{0,180}?)<\//i)?.[1],
    html.match(/"price"\s*:\s*"?([0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬.]*)"?/i)?.[1],
  ];
  const price = priceCandidates.map((candidate) => ehadishNumber(candidate ? decodeEhadishText(candidate.replace(/<[^>]+>/g, ' ')) : undefined)).find((n) => n && n > 0);
  const priceMissing = !price; // Preserve the catalog row, but never make an unpriced product sellable.

  const imageRaw = html.match(/property=["']og:image["'][^>]*content=["']([^"']+)/i)?.[1]
    || html.match(/content=["']([^"']+)["'][^>]*property=["']og:image/i)?.[1]
    || html.match(/src=["'](\/Images\/Product\/[^"']+)["']/i)?.[1]
    || html.match(/src=["'](https?:\/\/[^"']+\.(?:webp|png|jpe?g)(?:\?[^"']*)?)["']/i)?.[1];
  let image = '';
  try { image = imageRaw ? new URL(decodeEhadishText(imageRaw), urlObj.origin).toString() : ''; } catch { image = ''; }

  const categoryFromUrl = (urlObj.pathname.match(/category-([^/]+)/i)?.[1] || '').toLowerCase();
  const categoryText = decodeEhadishText(html.match(/class=["'][^"']*cat[^"']*["'][^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i)?.[1] || '');
  // Keep the supplier's own category label verbatim for product import. Use URL
  // slug only when the source page does not expose a visible category label.
  const category = categoryText || categoryFromUrl || 'کالای دیجیتال';
  const categorySignals = `${categoryText} ${categoryFromUrl}`;
  const isAccessoryCategory = /accessor|لوازم\s*جانبی|کاور|قاب|کیف\s*موبایل|شارژر|کابل|گلس|محافظ|هولدر|مبدل|آداپتور|mobile-accessories/i.test(`${categorySignals} ${title}`);
  const isMobileCategory = !isAccessoryCategory && (
    /(?:^|[-\s])(?:mobile|phone|smartphone)(?:$|[-\s])/i.test(categoryFromUrl)
    || /گوشی موبایل|گوشی تلفن|تلفن همراه|smartphone|mobile phone/i.test(`${categoryText} ${title}`)
  );

  // Exclude every mobile handset (iPhone and Android); keep phone accessories.
  if (isEhadishPhoneHandset(html, url)) return null;

  const addToBasketSection = html.match(/(?:AddToBasket|add.?to.?cart|افزودن\s*به\s*سبد)[\s\S]{0,350}/i)?.[0] || '';
  const hasAddToBasket = /AddToBasket|add.?to.?cart|افزودن\s*به\s*سبد|افزودن به سبد خرید/i.test(html);
  const stockSection = html.match(/<(?:div|span|p)[^>]*(?:stock-status|product-stock|availability|productAvailability|stockStatus|StockStatus)[^>]*>[\s\S]*?<\/(?:div|span|p)>/i)?.[0] || '';
  const stockEvidence = `${stockSection} ${addToBasketSection}`;
  const hasOutOfStock = /(?:ناموجود|اتمام موجودی|عدم موجودی|out\s*of\s*stock|sold\s*out)/i.test(decodeEhadishText(stockEvidence));
  const addButtonTag = html.match(/<(?:button|a|input)\b[^>]*(?:AddToBasket|add.?to.?cart)[^>]*>/i)?.[0] || '';
  const disabledAddButton = /\bdisabled(?:\s|=|>|$)|aria-disabled=["']?true/i.test(addButtonTag);
  // Do not infer stock from a disabled add button or unrelated page text.
  const inStock = hasAddToBasket && !hasOutOfStock && !disabledAddButton;
  const brand = decodeEhadishText(html.match(/class=["'][^"']*brand[^"']*["'][^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i)?.[1] || '');
  const slug = lastPath.replace(/^\d+-?/, '').slice(0, 80);
  return {
    id, product_id: id, sku: id, name: title, title, persianName: title,
    brand: brand || undefined, category, price: price || 0, priceMissing, stock: inStock ? 1 : 0, inStock: Boolean(inStock),
    // No recognizable stock widget is unknown, not proof of out-of-stock.
    stockKnown: Boolean(hasOutOfStock || hasAddToBasket || disabledAddButton),
    is_available: Boolean(inStock), site_visible: 1, image: image || undefined, images: image ? [image] : [],
    slug, supplierId: 'ehadish', supplierName: 'هدیش (Ehadish)',
    sourceUrl: url,
  };
}

async function fetchEhadishCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string; meta?: Record<string, number> }> {
  if (ehadishCatalogCache && Date.now() - ehadishCatalogCache.at < EHADISH_CACHE_TTL_MS) {
    return { success: true, items: ehadishCatalogCache.items.map((item) => ({ ...item })), meta: { ...ehadishCatalogCache.meta } };
  }
  try {
    const urls = await getEhadishProductUrls(supplier.baseUrl || 'https://www.ehadish.com/');
    const parsed: any[] = [];
    const failures: string[] = [];
    let excludedMobilePhonesCount = 0;
    let productsNeedingPriceCount = 0;
    const unparsedProductPages: string[] = [];
    let next = 0;
    const workers = Array.from({ length: Math.min(EHADISH_CONCURRENCY, urls.length) }, async () => {
      while (next < urls.length) {
        const index = next++;
        const url = urls[index];
        const page = await fetchEhadishText(url);
        if (!page.ok) {
          // Stale 404 URLs are normal in large sitemaps; transient/network failures invalidate the snapshot.
          if (page.status !== 404) failures.push(`${url}: ${page.error || page.status}`);
          continue;
        }
        if (isEhadishPhoneHandset(page.text, url)) { excludedMobilePhonesCount++; continue; }
        const product = parseEhadishProduct(page.text, url);
        if (product) { parsed.push(product); if (product.priceMissing) productsNeedingPriceCount++; }
        else unparsedProductPages.push(url);
      }
    });
    await Promise.all(workers);
    if (!parsed.length) {
      const firstFailure = failures[0] || (unparsedProductPages[0] ? `${unparsedProductPages[0]}: نام/مشخصات قابل استخراج نبود` : 'هیچ کالای قابل‌شناسایی پیدا نشد');
      return { success: false, items: [], error: `از ${urls.length} نشانی هدیش هیچ کالای قابل‌شناسایی دریافت نشد؛ وضعیت قبلی حفظ شد. نمونه: ${firstFailure}` };
    }
    const unique = [...new Map(parsed.map((p) => [String(p.id), p])).values()];
    const failedPagesCount = failures.length + unparsedProductPages.length;
    const catalogComplete = failedPagesCount === 0;
    const meta = { sourceUrlCount: urls.length, excludedMobilePhonesCount, productsNeedingPriceCount, catalogComplete: catalogComplete ? 1 : 0, failedPagesCount, unparsedProductPagesCount: unparsedProductPages.length };
    const warning = catalogComplete ? undefined : `کاتالوگ هدیش به‌صورت ناقص دریافت شد: ${failures.length} صفحه با خطای دریافت و ${unparsedProductPages.length} صفحه با مشخصات غیرقابل‌استخراج. کالاهای دریافت‌شده ثبت می‌شوند؛ وضعیت کالاهای غایب از این فهرست تغییر نمی‌کند. نمونه: ${failures[0] || unparsedProductPages[0]}`;
    // Cache only complete snapshots. A partial snapshot must be retried next time.
    if (catalogComplete) ehadishCatalogCache = { at: Date.now(), items: unique, meta };
    console.log(`[EhadishAdapter] ${catalogComplete ? 'Complete' : 'Partial'} sitemap crawl: ${urls.length} URLs, ${unique.length} non-phone products, ${excludedMobilePhonesCount} mobile handsets excluded, ${productsNeedingPriceCount} missing prices, ${failedPagesCount} unresolved pages.`);
    return { success: true, items: unique, meta, ...(warning ? { error: warning } : {}) };
  } catch (err: any) {
    return { success: false, items: [], error: `خطا در دریافت کاتالوگ هدیش: ${err?.message || err}` };
  }
}


export const EhadishAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'ehadish',
  name: 'هدیش (Ehadish)',
  async fetchCatalog(supplier: Supplier) {
    return fetchEhadishCatalog(supplier);
  },
};

const ADAPTERS: Record<string, SupplierAdapter> = {
  kasra: KasraAdapter,
  hamrahtel: HamrahTelAdapter,
  ehadish: EhadishAdapter,
};

export function registerSupplierAdapter(adapter: SupplierAdapter) {
  ADAPTERS[adapter.id] = adapter;
}

export const getAdapter = (s: { id: string; name: string }): SupplierAdapter => ADAPTERS[s.id] || { ...UniversalSupplierAdapter, id: s.id, name: s.name };


// ============================================================================
// 7. Core Multi-Supplier Sync & Pricing Engine
//    نسخه اختصاصی کسری پلاس: قیمت کالا = قیمت تأمین‌کننده × (۱ + درصد مصوب)؛ مقدار پیش‌فرض ۵٪ و فقط یک‌بار.
// ============================================================================

let isSyncRunning = false;

interface SupEntry { supplierId: string; supplierName: string; colorName: string; price: number; inStock: boolean; stock?: number }
interface SyncCtx {
  details: Record<string, { matched: any[]; colors: any[]; ambiguous: any[] }>;
  markupRate: number;
  frozenSupplierIds: Set<string>;
  supplierName: (id: string) => string;
  nowIso: string;
  anyFailed: boolean;
}

const isColorGroup = (g: any) => g && (g.type === 'color' || g.name === 'رنگ' || (typeof g.title === 'string' && g.title.includes('رنگ')));
const pLabel = (p: any) => String(p.persianName || p.name || p.id);

/** اختلاف ۱۰ برابری با قیمت فعلی سایت = تقریباً قطعاً اشتباه واحد (ریال/تومان)؛ فقط همین حالت خاص نگه داشته می‌شود. */
export function looksLikeUnitMismatch(oldPrice: any, newPrice: number): boolean {
  const o = Number(oldPrice);
  if (!(o > 0) || !(newPrice > 0)) return false;
  const r = newPrice / o;
  return (r >= 8 && r <= 12.5) || (r >= 0.08 && r <= 0.125);
}

const bestOf = (es: SupEntry[]): SupEntry => es.reduce((a, b) => (b.price > a.price ? b : a), es[0]);

/** قیمت‌گذاری یک کالا بر اساس تطبیق‌های قطعی تأمین‌کنندگان؛ true یعنی چیزی تغییر کرد. */
function priceProduct(product: any, matches: SupplierProductMatch[], ctx: SyncCtx): boolean {
  const { details, markupRate, frozenSupplierIds, nowIso } = ctx;
  const label = pLabel(product);
  const review = (supplierId: string, row: any) => details[supplierId]?.ambiguous.push({ productId: product.id, productName: label, ...row });
  let changed = false;

  const entries: SupEntry[] = [];
  for (const m of matches) {
    for (const v of m.variants) {
      entries.push({ supplierId: m.supplierId, supplierName: ctx.supplierName(m.supplierId), colorName: v.colorName || '', price: Number(v.sourcePrice) || 0, inStock: v.inStock, stock: v.stock });
    }
  }
  const live = (es: SupEntry[]) => es.filter((e) => e.inStock && e.price > 0);

  const groups: any[] = Array.isArray(product.variants) ? product.variants : [];
  const colorGroup = groups.find(isColorGroup) || null;
  const options: any[] = colorGroup && Array.isArray(colorGroup.options) ? colorGroup.options : [];

  // ---------------------------------------------------------------- کالای دارای رنگ
  if (options.length > 0) {
    const colored = entries.filter((e) => e.colorName);
    const global = entries.filter((e) => !e.colorName);
    const supNames = [...new Set(colored.map((e) => e.colorName))];
    const map = mapColors(options.map((o) => `${o.name || ''} ${o.value || ''}`), supNames);
    const hasLive = (name: string) => live(colored.filter((e) => e.colorName === name)).length > 0;
    const unresolvedSup = [
      ...map.ambiguousSupplier.map((a) => supNames[a.supplier]),
      ...map.unmatchedSupplier.map((i) => supNames[i]),
    ].filter(hasLive);
    const fullyResolved = unresolvedSup.length === 0;

    for (const name of unresolvedSup) {
      for (const sid of new Set(colored.filter((e) => e.colorName === name).map((e) => e.supplierId))) {
        const amb = map.ambiguousSupplier.find((a) => supNames[a.supplier] === name);
        review(sid, {
          kind: 'color',
          reason: amb
            ? `رنگ «${name}» تأمین‌کننده با چند رنگ کالای شما شبیه است (${amb.masters.map((i) => options[i].name).join('، ')})؛ قیمت اعمال نشد`
            : `رنگ «${name}» تأمین‌کننده با هیچ رنگ ثبت‌شده‌ی کالای شما تطبیق نخورد؛ اگر این رنگ را می‌فروشید، آن را در کالا ثبت یا نام آن را اصلاح کنید`,
          candidates: [],
        });
      }
    }

    const touched = new Set<string>();
    let highest = 0, refId = '', refName = '';

    options.forEach((opt, oi) => {
      const pair = map.pairs.find((p) => p.master === oi);
      const names = pair ? pair.supplier.map((i) => supNames[i]) : [];
      const es = [...colored.filter((e) => names.includes(e.colorName)), ...global];

      if (es.length === 0) return; // در مرحله‌ی بعد (رنگ‌های بدون تطبیق) بررسی می‌شود

      touched.add(opt.id);
      const liveEs = live(es);
      if (liveEs.length === 0) {
        // همه‌ی تأمین‌کنندگانِ این رنگ صراحتاً ناموجود گفته‌اند
        if (ctx.anyFailed || (opt.referenceSupplierId && frozenSupplierIds.has(opt.referenceSupplierId))) return;
        if (opt.inStock !== false || opt.stock !== 0) { opt.inStock = false; opt.stock = 0; changed = true; }
        return;
      }
      const best = bestOf(liveEs);
      const finalPrice = Math.round(best.price * (1 + markupRate));
      for (const e of es) details[e.supplierId]?.colors.push({ productId: product.id, productName: label, color: opt.name, supplierPrice: e.price, sitePrice: finalPrice, usedForSitePrice: e === best, approximate: Boolean(pair?.loose) });

      if (finalPrice > highest) { highest = finalPrice; refId = best.supplierId; refName = best.supplierName; }
      const stockNow = best.stock !== undefined && Number.isFinite(Number(best.stock)) ? Math.max(0, Number(best.stock)) : (opt.stock > 0 ? opt.stock : 0);
      if (opt.sourcePrice !== best.price || opt.price !== finalPrice || opt.referenceSupplierId !== best.supplierId || opt.inStock !== true || opt.markupRate !== markupRate) {
        opt.sourcePrice = best.price;
        opt.markupRate = markupRate;
        opt.price = finalPrice;
        opt.referenceSupplierId = best.supplierId;
        opt.referenceSupplierName = best.supplierName;
        opt.inStock = true;
        opt.stock = stockNow;
        changed = true;
      }
    });

    // رنگ‌هایی از کالای شما که هیچ ردیفی از تأمین‌کننده به آن‌ها نگاشت نشد
    for (const opt of options) {
      if (touched.has(opt.id)) continue;
      if (!fullyResolved) continue; // مطمئن نیستیم ناموجود است یا فقط نام دیگری دارد → وضعیت قبلی حفظ می‌شود
      if (ctx.anyFailed || (opt.referenceSupplierId && frozenSupplierIds.has(opt.referenceSupplierId))) continue;
      if (opt.inStock !== false || opt.stock !== 0) { opt.inStock = false; opt.stock = 0; changed = true; }
    }

    // قیمت پایه و اختلاف رنگ‌ها
    const inStockOpts = options.filter((o) => o.inStock && Number(o.price) > 0);
    const base = inStockOpts.length ? Math.max(...inStockOpts.map((o) => Number(o.price))) : 0;
    if (base > 0 && highest === 0) { highest = base; }
    if (highest > 0 && product.price !== highest) {
      product.price = highest;
      product.sourcePrice = Math.round(highest / (1 + markupRate));
      product.syncedPrice = highest;
      changed = true;
    }
    for (const opt of options) {
      const delta = opt.inStock && typeof opt.price === 'number' && highest > 0 ? opt.price - highest : 0;
      if (opt.priceDelta !== delta) { opt.priceDelta = delta; changed = true; }
    }
    options.sort((a, b) => (b.inStock ? 1 : 0) - (a.inStock ? 1 : 0));
    const anyStock = options.some((o) => o.inStock === true);
    if (product.inStock !== anyStock) { product.inStock = anyStock; changed = true; }
    product.colors = options.map((o) => ({
      id: o.id, name: o.name, colorCode: o.colorCode || '#1e293b', price: o.price || product.price,
      priceDelta: o.priceDelta || 0, inStock: Boolean(o.inStock), stock: o.inStock ? (o.stock ?? null) : 0,
    }));
    if (refName && product.referenceSupplierName !== refName) {
      product.referenceSupplierId = refId; product.referenceSupplierName = refName; product.supplierName = refName; changed = true;
    }
    product.lastSyncedAt = nowIso;
    product.syncStatus = fullyResolved ? 'synced' : 'needs_review';
    return changed;
  }

  // ---------------------------------------------------------------- کالای بدون رنگ ثبت‌شده
  const liveAll = live(entries);
  const distinctPrices = new Set(liveAll.map((e) => e.price));
  if (liveAll.length === 0) {
    // تطبیق قطعی هست ولی هیچ تأمین‌کننده‌ی سالمی موجودی ندارد → ناموجود (قیمت قبلی حفظ می‌شود)
    const dependsOnFailed = ctx.anyFailed || Boolean(product.referenceSupplierId && frozenSupplierIds.has(product.referenceSupplierId));
    if (!dependsOnFailed && product.inStock !== false) { product.inStock = false; changed = true; }
    product.lastSyncedAt = nowIso; product.syncStatus = 'synced';
    return changed;
  }
  const best = bestOf(liveAll);
  const finalPrice = Math.round(best.price * (1 + markupRate));
  for (const e of liveAll) details[e.supplierId]?.colors.push({ productId: product.id, productName: label, color: 'قیمت واحد (بدون رنگ)', supplierPrice: e.price, sitePrice: finalPrice, usedForSitePrice: e === best });
  if (product.price !== finalPrice || product.sourcePrice !== best.price || product.referenceSupplierId !== best.supplierId || product.inStock !== true) {
    product.price = finalPrice;
    product.sourcePrice = best.price;
    product.syncedPrice = finalPrice;
    product.referenceSupplierId = best.supplierId;
    product.referenceSupplierName = best.supplierName;
    product.supplierName = best.supplierName;
    product.inStock = true;
    changed = true;
  }
  product.lastSyncedAt = nowIso;
  product.syncStatus = 'synced';
  return changed;
}

// ----------------------------------------------------------------------------
// ساخت خودکار کالا از تأمین‌کننده‌ها — همه کالاها؛ از هدیش فقط گوشی‌های موبایل حذف می‌شوند.
// حذف‌شده‌ها در data/supplier_ignored.json ثبت می‌شوند تا دوباره ساخته نشوند. با settings.autoCreateFromSuppliers=false خاموش می‌شود.
// ----------------------------------------------------------------------------
export const IGNORED_FILE = 'supplier_ignored.json';
const autoHash = (s: string) => createHash('sha1').update(s).digest('hex').slice(0, 10);

function storefrontCategoryId(categorySlug: string): string {
  const map: Record<string, string> = {
    mobile: 'cat-mobile',
    laptop: 'cat-laptop',
    tablet: 'cat-tablet',
    smartwatch: 'cat-watch',
    audio: 'cat-audio',
    powerbank: 'cat-powerbank',
    chargers: 'cat-chargers',
    'mobile-accessories': 'cat-mobile-accessories',
    'computer-accessories': 'cat-computer-accessories',
    'other-digital': 'cat-other-digital',
  };
  return map[categorySlug] || 'cat-other-digital';
}

/** Returns explicit source stock status; undefined means the supplier did not provide reliable evidence. */
function supplierStockState(item: any): boolean | undefined {
  if (!item || typeof item !== 'object') return undefined;
  if (item.stockKnown === false) return undefined;
  const numericKeys = ['stock', 'quantity', 'qty', 'quantity_available', 'quantityAvailable', 'stock_quantity', 'inventory_quantity'];
  for (const key of numericKeys) {
    if (item[key] !== undefined && item[key] !== null && item[key] !== '') {
      const n = Number(item[key]);
      if (Number.isFinite(n)) return n > 0;
    }
  }
  const boolKeys = ['inStock', 'in_stock', 'is_available', 'isAvailable', 'available', 'no_longer_available', 'site_visible', 'is_visible', 'isVisible', 'active', 'is_active'];
  for (const key of boolKeys) {
    const value = item[key];
    if (value === true || value === 1 || value === '1' || value === 'true') return key === 'no_longer_available' ? false : true;
    if (value === false || value === 0 || value === '0' || value === 'false') return key === 'no_longer_available' ? true : false;
  }
  const status = String(item.status ?? item.availability ?? '').toLowerCase();
  if (/out.?of.?stock|unavailable|ناموجود|اتمام موجودی/.test(status)) return false;
  if (/in.?stock|available|موجود/.test(status)) return true;
  const groups = [item.variants, item.colors, item.product_variants, item.productVariants].filter(Array.isArray).flat();
  if (groups.length) {
    const states = groups.map((v: any) => supplierStockState(v));
    if (states.some((v: any) => v === true)) return true;
    if (states.every((v: any) => v === false)) return false;
  }
  return undefined;
}

function autoCreateProducts(
  masters: any[], suppliers: Supplier[], catalogs: Record<string, any[]>, consumed: Record<string, Set<string>>, settings: any, nowIso: string, options: { dryRun?: boolean } = {},
): any[] {
  // Limited Kasra/Ehadish integration: every source catalog row becomes its own
  // PuzzleKala product. Never merge by title/model across suppliers or within a feed.
  void settings;
  const existingKeys = new Set(masters.filter((p) => p?.autoKey).map((p) => String(p.autoKey)));
  const existingIds = new Set(masters.map((p) => String(p?.id)));
  const existingSourceIds = new Set<string>();
  for (const p of masters) {
    if (!p?.autoCreated) continue;
    const source = String(p.supplierId || p.source || '');
    const sourceId = String(p.sourceProductId || '');
    if (source && sourceId) existingSourceIds.add(`${source}|${sourceId}`);
    const match = p.supplierMatches?.[source];
    const ids = Array.isArray(match?.itemIds) ? match.itemIds : match?.supplierProductId != null ? [match.supplierProductId] : [];
    for (const id of ids) if (source) existingSourceIds.add(`${source}|${String(id)}`);
  }
  const out: any[] = [];
  for (const sup of suppliers) {
    for (const item of catalogs[sup.id] || []) {
      const itemId = String(item?.id ?? item?.product_id ?? '');
      if (!itemId) continue;
      if (sup.id === 'ehadish' && isEhadishHandsetRow(item)) continue;
      const title = String(item?.title || item?.name || item?.persianName || item?.product_name || item?.product_name_en || '').trim();
      if (title.length < 3) continue;
      const key = `${sup.id}|id:${itemId}`;
      if (existingKeys.has(key) || existingSourceIds.has(`${sup.id}|${itemId}`)) continue;
      const identity = identityOfItem(item);
      // Supplier title is preserved byte-for-byte after trimming outer whitespace;
      // do not remove color/model/variant text from the imported name.
      const displayTitle = title;
      const id = `prod-auto-${autoHash(key)}`;
      if (existingIds.has(id)) continue;
      const rawCategory = item?.categoryName ?? item?.category_name ?? item?.supplierCategory ?? item?.category ?? item?.subcategory ?? item?.categoryLabel ?? '';
      const sourceCategory = typeof rawCategory === 'string'
        ? rawCategory.trim()
        : String(rawCategory?.name ?? rawCategory?.category_name ?? rawCategory?.title ?? '').trim();
      const cls = classifyProduct({ name: displayTitle, persianName: displayTitle, id, category: sourceCategory || item?.category || item?.subcategory });
      // Storefront uses a stable category ID for navigation, while categoryLabel,
      // supplierCategory and sourceCategory preserve the supplier's exact category.
      const category = storefrontCategoryId(cls.categorySlug);
      const categoryLabel = sourceCategory || cls.category;
      const variants = buildVariants([item]);
      const markupPercent = 5; // Fixed business rule: source price + 5%, never compounded.
      const sourcePrices = [
        ...variants.map((v) => Number(v.sourcePrice)),
        Number(item.price ?? item.sell_price ?? item.sellPrice ?? item.sourcePrice ?? item.source_price ?? 0),
      ].filter((n) => Number.isFinite(n) && n > 0);
      const hasValidPrice = sourcePrices.length > 0;
      const sourceStockState = supplierStockState(item);
      const groupHasStock = sourceStockState === true || (sourceStockState === undefined && variants.some((v) => v.inStock));
      const colorOptions: any[] = [];
      const seenColors = new Set<string>();
      for (const variant of variants) {
        if (!variant.colorName) continue;
        const color = colorKey(variant.colorName) || variant.colorName;
        if (seenColors.has(color)) continue;
        seenColors.add(color);
        colorOptions.push({
          id: `${id}-c${colorOptions.length + 1}`, name: variant.colorName, value: variant.colorName,
          colorCode: '#64748b', priceDelta: 0,
          price: variant.sourcePrice > 0 ? Math.round(variant.sourcePrice * 1.05) : 0,
          sourcePrice: variant.sourcePrice, inStock: variant.inStock,
          stock: variant.inStock ? Math.max(1, Number(variant.stock) || 1) : 0,
        });
      }
      const rawImages = Array.isArray(item.images) ? item.images : [];
      const rawImageCandidates = [item.image, item.image_url, item.imageUrl, item.thumbnail, item.thumbnail_url, item.src, ...rawImages.map((v: any) => typeof v === 'string' ? v : v?.url ?? v?.src ?? v?.image)].filter((v: any) => typeof v === 'string' && v.trim());
      const sourceUrl = String(item.sourceUrl || item.url || (sup.id === 'ehadish' ? 'https://www.ehadish.com/' : 'https://plus.kasrapars.ir/'));
      const sourceImages = [...new Set(rawImageCandidates.map((v: string) => { try { return new URL(v, sourceUrl).toString(); } catch { return v; } }))];
      const sourcePrice = sourcePrices.length ? Math.max(...sourcePrices) : 0;
      const product = {
        ...item, // Retain original supplier specifications and metadata unchanged.
        supplierOriginalVariants: item.variants ?? item.colors ?? item.product_variants ?? item.productVariants ?? undefined,
        id, name: displayTitle, persianName: displayTitle, brand: cls.brand,
        category, categoryLabel, supplierCategory: categoryLabel, sourceCategory: categoryLabel,
        categorySlug: cls.categorySlug, subcategory: categoryLabel,
        price: hasValidPrice ? Math.round(sourcePrice * 1.05) : 0,
        sourcePrice: hasValidPrice ? sourcePrice : 0,
        stock: groupHasStock ? Math.max(1, Number(item.stock ?? item.quantity) || 1) : 0,
        inStock: groupHasStock, active: hasValidPrice, images: sourceImages, image: sourceImages[0] || item.image || item.image_url || undefined,
        slug: `${displayTitle.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80)}-${autoHash(key).slice(0, 6)}`,
        description: String(item.description || item.short_description || displayTitle),
        source: sup.id, supplierId: sup.id, supplierName: sup.name, referenceSupplierId: sup.id,
        referenceSupplierName: sup.name, sourceProductId: itemId, autoCreated: true, autoKey: key,
        sourceImages, sourceUrl: item.sourceUrl || item.url || undefined,
        createdAt: nowIso.slice(0, 10), syncStatus: hasValidPrice ? 'synced' : 'needs_price',
        priceMissing: !hasValidPrice, sourcePriceMissing: !hasValidPrice, adminStatusLabel: hasValidPrice ? (groupHasStock ? 'قیمت‌گذاری خودکار فعال' : 'ناموجود در منبع') : 'قیمت دریافت نشده؛ فروش غیرفعال',
        supplierMatches: { [sup.id]: { supplierProductId: itemId, itemIds: [itemId], supplierName: sup.name, confirmedBy: 'auto', confirmedAt: nowIso } },
        ...(colorOptions.length ? { variants: [{ type: 'color', title: 'انتخاب رنگ', options: colorOptions }] } : {}),
      };
      out.push(product);
      existingKeys.add(key);
      existingIds.add(id);
      existingSourceIds.add(`${sup.id}|${itemId}`);
    }
  }
  if (out.length && !options.dryRun) recordAuditLog('supplier_auto_create', `${out.length} کالای مستقل از کاتالوگ کسرا پلاس و هدیش ثبت شد؛ فقط نرخ افزایش قیمت روی قیمت همان تأمین‌کننده اعمال شد.`, 'multi-supplier-sync', { ids: out.slice(0, 50).map((p: any) => p.id) });
  return out;
}

function refreshExistingAutoCreatedProducts(
  masters: any[], suppliers: Supplier[], catalogs: Record<string, any[]>, settings: any, nowIso: string,
): number {
  let refreshed = 0;
  const markup = 5; // Fixed 5% rule; never compound from the previously displayed price.
  for (const product of masters) {
    if (!product?.autoCreated) continue;
    const source = String(product.supplierId || product.source || '');
    const supplier = suppliers.find((s) => s.id === source);
    if (!supplier) continue;
    const sourceId = String(product.sourceProductId || product.supplierMatches?.[source]?.supplierProductId || '');
    if (!sourceId) continue;
    const item = (catalogs[source] || []).find((row: any) => String(row?.id ?? row?.product_id ?? '') === sourceId);
    if (!item || (source === 'ehadish' && isEhadishHandsetRow(item))) continue;
    const rawCategory = item?.categoryName ?? item?.category_name ?? item?.supplierCategory ?? item?.category ?? item?.subcategory ?? item?.categoryLabel ?? '';
    const sourceCategory = typeof rawCategory === 'string'
      ? rawCategory.trim()
      : String(rawCategory?.name ?? rawCategory?.category_name ?? rawCategory?.title ?? '').trim();
    if (sourceCategory) {
      product.categoryLabel = sourceCategory;
      product.supplierCategory = sourceCategory;
      product.sourceCategory = sourceCategory;
      product.subcategory = sourceCategory;
    }
    const variants = buildVariants([item]);
    const prices = [...variants.map((v) => Number(v.sourcePrice)), Number(item.price ?? item.sell_price ?? item.sellPrice ?? item.sourcePrice ?? item.source_price ?? 0)]
      .filter((n) => Number.isFinite(n) && n > 0);
    const hasPrice = prices.length > 0;
    const sourcePrice = hasPrice ? Math.max(...prices) : Number(product.sourcePrice) || 0;
    const stockState = supplierStockState(item);
    // Missing/invalid source price is not a price update: preserve last valid source and storefront prices.
    // Missing stock evidence is not an out-of-stock signal: preserve the last known stock state.
    const effectiveInStock = stockState === undefined ? Boolean(product.inStock) : stockState;
    product.autoKey = `${source}|id:${sourceId}`;
    product.sourceProductId = sourceId;
    product.source = source;
    product.supplierId = source;
    product.supplierName = supplier.name;
    product.referenceSupplierId = source;
    product.referenceSupplierName = supplier.name;
    product.supplierMatches = { [source]: { supplierProductId: sourceId, itemIds: [sourceId], supplierName: supplier.name, confirmedBy: 'auto', confirmedAt: nowIso } };
    if (hasPrice) {
      product.sourcePrice = sourcePrice;
      product.price = Math.round(sourcePrice * 1.05);
      product.syncedPrice = product.price;
      product.active = true;
      product.priceMissing = false;
      product.sourcePriceMissing = false;
      product.syncStatus = 'synced';
    } else {
      // Keep the last valid price and active state when the supplier temporarily omits price.
      product.priceMissing = !(Number(product.price) > 0);
      product.sourcePriceMissing = true;
      product.syncStatus = 'price_unavailable_preserved';
    }
    product.inStock = effectiveInStock;
    if (stockState !== undefined) {
      const sourceStock = Number(item.stock ?? item.quantity ?? item.qty ?? 0);
      product.stock = stockState ? Math.max(1, Number.isFinite(sourceStock) ? sourceStock : 1) : 0;
    }
    product.adminStatusLabel = Number(product.price) > 0
      ? (product.inStock ? 'قیمت‌گذاری خودکار فعال' : 'ناموجود در منبع')
      : 'قیمت دریافت نشده؛ فروش غیرفعال';
    const rawImages = Array.isArray(item.images) ? item.images : [];
    const imageCandidates = [item.image, item.image_url, item.imageUrl, item.thumbnail, item.thumbnail_url, item.src, ...rawImages.map((v: any) => typeof v === 'string' ? v : v?.url ?? v?.src ?? v?.image)].filter((v: any) => typeof v === 'string' && v.trim());
    const sourceUrl = String(item.sourceUrl || item.url || (source === 'ehadish' ? 'https://www.ehadish.com/' : 'https://plus.kasrapars.ir/'));
    const sourceImages = [...new Set(imageCandidates.map((v: string) => { try { return new URL(v, sourceUrl).toString(); } catch { return v; } }))];
    product.images = sourceImages;
    product.sourceImages = sourceImages;
    product.image = sourceImages[0] || undefined;
    product.sourceUrl = item.sourceUrl || item.url || product.sourceUrl;
    const latestTitle = String(item?.title || item?.name || item?.persianName || item?.product_name || item?.product_name_en || '').trim();
    if (latestTitle.length >= 3) { product.name = latestTitle; product.persianName = latestTitle; product.title = latestTitle; }
    for (const field of ['description', 'short_description', 'specifications', 'specs', 'attributes', 'features', 'technical_specs', 'technicalSpecifications']) {
      if (item[field] !== undefined) product[field] = item[field];
    }
    if (product.supplierOriginalVariants === undefined) product.supplierOriginalVariants = item.variants ?? item.colors ?? item.product_variants ?? item.productVariants;
    const options: any[] = [];
    const seenColors = new Set<string>();
    for (const variant of variants) {
      if (!variant.colorName) continue;
      const color = colorKey(variant.colorName) || variant.colorName;
      if (seenColors.has(color)) continue;
      seenColors.add(color);
      options.push({ id: `${product.id}-c${options.length + 1}`, name: variant.colorName, value: variant.colorName, colorCode: '#64748b', priceDelta: 0, price: variant.sourcePrice > 0 ? Math.round(variant.sourcePrice * 1.05) : 0, sourcePrice: variant.sourcePrice, inStock: variant.inStock, stock: variant.inStock ? Math.max(1, Number(variant.stock) || 1) : 0 });
    }
    if (options.length && hasPrice) {
      if (product.supplierOriginalVariants === undefined) product.supplierOriginalVariants = item.variants ?? item.colors ?? item.product_variants ?? item.productVariants;
      product.variants = [{ type: 'color', title: 'انتخاب رنگ', options }];
    }
    product.lastSyncedAt = nowIso;
    refreshed++;
  }
  return refreshed;
}

export async function executeMultiSupplierSync(
  onUpdateNotify?: (() => void) | any,
  options: { dryRun?: boolean } = {}
): Promise<{
  success: boolean;
  message: string;
  updatedMasterProducts: number;
  plannedChanges?: Array<{ productId: string; productName: string; changeType: 'created' | 'updated'; before?: any; after: any }>;
  dryRun?: boolean;
  supplierStats: Record<string, any>;
  timestamp: string;
}> {
  // Concurrency Guard: Mutex Lock
  if (isSyncRunning) {
    return {
      success: false,
      message: 'همگام‌سازی تأمین‌کنندگان در حال حاضر در حال اجراست؛ لطفاً شکیبا باشید.',
      updatedMasterProducts: 0,
      supplierStats: {},
      timestamp: new Date().toISOString(),
    };
  }

  isSyncRunning = true;
  const nowIso = new Date().toISOString();

  try {
    currentRules = loadMatchingRules();
    const suppliers = getSuppliersList();
    // This build is intentionally limited to Kasra Plus and Ehadish only.
    const enabledSuppliers = suppliers.filter((s) => s.enabled && (s.id === 'kasra' || s.id === 'ehadish'));
    const productsPath = path.join(DATA_DIR, 'products.json');

    // درصد مصوب افزایش قیمت (پیش‌فرض ۵٪)
    const settings = readJsonFile<any>(path.join(DATA_DIR, 'settings.json'), {});
    // Fixed limited-integration rule: exactly 5% on each supplier's own source price.
    const approvedMarkupPercent = 5;

    const supplierCatalogs: Record<string, any[]> = {};
    const supplierCatalogMeta: Record<string, Record<string, number>> = {};
    const supplierStats: Record<string, any> = {};

    // 1. Fetch catalogs from all enabled suppliers in PARALLEL
    await Promise.all(
      enabledSuppliers.map(async (sup) => {
        const adapter = ADAPTERS[sup.id] || { ...UniversalSupplierAdapter, id: sup.id, name: sup.name };
        sup.lastSyncAt = nowIso;

        try {
          const fetchRes = await adapter.fetchCatalog(sup);
          if (fetchRes.success && Array.isArray(fetchRes.items)) {
            // A successful HTTP response with an empty catalog is not safe evidence
            // that the supplier has zero products. Treat it as an unavailable feed so
            // a transient/auth/pagination failure cannot turn every matched product
            // into out-of-stock.
            if (fetchRes.items.length === 0) {
              sup.status = 'unavailable';
              sup.lastError = 'کاتالوگ تأمین‌کننده خالی دریافت شد؛ برای جلوگیری از صفر/ناموجود شدن کاذب، وضعیت قبلی حفظ شد.';
              supplierCatalogs[sup.id] = [];
            } else {
              sup.status = 'connected';
              const rawMeta = fetchRes.meta || {};
              const rawItems = fetchRes.items;
              const sourceCatalogComplete = rawMeta.catalogComplete !== 0;
              sup.catalogComplete = sourceCatalogComplete;
              // A partial supplier snapshot is usable for importing pages that were
              // fetched, but it must not be treated as evidence that missing products
              // are out of stock. Keep a visible warning and retry next sync.
              // Enforce the Hadish phone exclusion centrally as well as in the HTML parser,
              // so no alternative adapter/test fixture can accidentally import Android/iPhone handsets.
              const acceptedItems = sup.id === 'ehadish' ? rawItems.filter((item: any) => !isEhadishHandsetRow(item)) : rawItems;
              const additionallyExcludedPhones = rawItems.length - acceptedItems.length;
              supplierCatalogMeta[sup.id] = {
                ...rawMeta,
                sourceUrlCount: Number(rawMeta.sourceUrlCount ?? rawItems.length),
                excludedMobilePhonesCount: Number(rawMeta.excludedMobilePhonesCount || 0) + additionallyExcludedPhones,
                productsNeedingPriceCount: Math.max(Number(rawMeta.productsNeedingPriceCount || 0), acceptedItems.filter((item: any) => !(Number(item?.price || item?.sell_price || item?.sourcePrice || 0) > 0)).length),
              };
              if (sourceCatalogComplete) sup.lastSuccessAt = nowIso;
              sup.lastError = sourceCatalogComplete ? null : (fetchRes.error || `کاتالوگ ${sup.name} ناقص دریافت شد؛ وضعیت کالاهای غایب حفظ می‌شود.`);
              supplierCatalogs[sup.id] = acceptedItems;
            }
          } else {
            sup.status = 'unavailable';
            sup.lastError = fetchRes.error || 'پاسخ نامعتبر از تأمین‌کننده';
            supplierCatalogs[sup.id] = [];
          }
        } catch (err: any) {
          sup.status = 'error';
          sup.lastError = err.message || 'خطا در برقراری ارتباط';
          supplierCatalogs[sup.id] = [];
        }

        sup.matchedCount = 0;
        sup.ambiguousCount = 0;
        sup.variantsCount = 0;
        sup.inStockColorsCount = 0;

        const catItems = supplierCatalogs[sup.id] || [];
        const itemInStock = (it: any) => {
          if (!it || typeof it !== 'object') return false;
          if (it.no_longer_available === true || it.is_available === false || it.is_available === 0 || it.is_available === '0' || it.site_visible === 0 || it.site_visible === '0' || it.is_visible === false || it.active === false || it.is_active === 0) return false;
          const variants = [...(Array.isArray(it.variants) ? it.variants : []), ...(Array.isArray(it.colors) ? it.colors : []), ...(Array.isArray(it.product_variants) ? it.product_variants : []), ...(Array.isArray(it.productVariants) ? it.productVariants : [])];
          if (variants.length > 0) return variants.some((v: any) => {
            const stock = kasraNumber(v?.stock ?? v?.quantity ?? v?.qty ?? v?.quantity_available ?? v?.quantityAvailable ?? v?.stock_quantity ?? v?.inventory_quantity);
            if (stock !== undefined) return stock > 0;
            return [v?.inStock, v?.in_stock, v?.is_available, v?.isAvailable, v?.available].some((x) => x === true || x === 1 || x === '1' || x === 'true');
          });
          const rawStock = kasraNumber(it.stock ?? it.quantity ?? it.qty ?? it.quantity_available ?? it.quantityAvailable ?? it.stock_quantity ?? it.inventory_quantity);
          if (rawStock !== undefined) return rawStock > 0;
          if (it.inStock === true || it.in_stock === true || it.is_available === true || it.is_available === 1 || it.site_visible === 1 || it.site_visible === true || it.is_visible === true || it.isVisible === true) return true;
          // Price alone is not proof of inventory; avoid reporting unavailable stock as available.
          return false;
        };
        const fetchedOk = sup.status === 'connected';
        // اگر دریافت کاتالوگ ناموفق بود، آمار قبلی حفظ می‌شود (به‌جای صفر شدن)
        const srcTotal = fetchedOk ? catItems.length : sup.sourceTotalProducts ?? 0;
        const srcCatalogUrlCount = fetchedOk ? (supplierCatalogMeta[sup.id]?.sourceUrlCount ?? catItems.length) : sup.sourceCatalogUrlCount ?? srcTotal;
        const srcInStock = fetchedOk ? catItems.filter(itemInStock).length : sup.sourceInStockProducts ?? 0;
        const srcOutOfStock = Math.max(0, srcTotal - srcInStock);

        sup.sourceTotalProducts = srcTotal;
        sup.sourceCatalogUrlCount = srcCatalogUrlCount;
        sup.sourceInStockProducts = srcInStock;
        sup.sourceOutOfStockProducts = srcOutOfStock;

        supplierStats[sup.id] = {
          name: sup.name,
          enabled: sup.enabled,
          status: sup.status,
          lastError: sup.lastError,
          sourceTotalProducts: srcTotal,
          sourceCatalogUrlCount: srcCatalogUrlCount,
          sourceInStockProducts: srcInStock,
          sourceOutOfStockProducts: srcOutOfStock,
          excludedMobilePhonesCount: supplierCatalogMeta[sup.id]?.excludedMobilePhonesCount ?? sup.excludedMobilePhonesCount ?? 0,
          productsNeedingPriceCount: supplierCatalogMeta[sup.id]?.productsNeedingPriceCount ?? 0,
          catalogComplete: fetchedOk && supplierCatalogMeta[sup.id]?.catalogComplete !== 0,
          matchedCount: 0,
          ambiguousCount: 0,
          variantsCount: 0,
          inStockColorsCount: 0,
        };
      })
    );

    // کالاهای فروشگاه «بعد از» دریافت کاتالوگ‌ها خوانده می‌شوند و تا لحظه‌ی ذخیره هیچ await ی در کار نیست؛
    // پس ویرایش هم‌زمان مدیر روی کالاها با همگام‌سازی روی هم نمی‌نویسد.
    const masterProducts: any[] = readJsonFile<any[]>(productsPath, []);
    const originalProducts = JSON.parse(JSON.stringify(masterProducts));
    const masterIdsAtStart = masterProducts.map((p: any) => p?.id);

    // تأمین‌کننده‌های «منجمد»: خطادار یا غیرفعال — آخرین قیمت/موجودی اعمال‌شده از آن‌ها دست‌نخورده می‌ماند
    // جزئیات تطبیق برای نمایش با کلیک روی باکس‌های آماری
    const details: Record<string, { matched: any[]; colors: any[]; ambiguous: any[] }> = {};
    for (const sup of enabledSuppliers) details[sup.id] = { matched: [], colors: [], ambiguous: [] };
    let updatedProductsCount = 0;
    const identityIssues: any[] = [];
    for (const p of masterProducts) {
      if (!p || typeof p !== 'object') continue;
      const idn = identityOfProduct(p);
      if (idn.category === 'accessory' || p.autoCreated) continue;
      const why = !idn.model ? 'مدل کالا از نام آن قابل تشخیص نیست؛ نام را به شکل «برند + مدل + رم/حافظه» اصلاح کنید' : idn.conflicts.length ? `نام و توضیحات کالا در این مشخصات متناقض‌اند: ${idn.conflicts.map((f) => FIELD_FA[f] || f).join('، ')}` : '';
      if (why) identityIssues.push({ productId: p.id, productName: pLabel(p), kind: 'product', reason: why, candidates: [] });
    }

    // 3. تطبیق کالاهای موجود فروشگاه با کاتالوگ کسری پلاس و هدیش و قیمت‌گذاری
    const consumed: Record<string, Set<string>> = {};
    for (const sup of enabledSuppliers) consumed[sup.id] = new Set();
    // Refresh each supplier-created product from its original supplier only.
    const refreshedAutoCreated = refreshExistingAutoCreatedProducts(
      masterProducts,
      enabledSuppliers.filter((s) => s.status === 'connected'),
      supplierCatalogs,
      settings,
      nowIso,
    );
    updatedProductsCount += refreshedAutoCreated;
    // This limited integration intentionally does not match or merge supplier rows with existing products.
    // Catalog items are copied as independent records; pricing is applied only from each item's own supplier.

    // Mark supplier-created products unavailable only after that supplier's complete feed succeeds.
    // Failed feeds are frozen and never cause a false out-of-stock transition.
    if (!options.dryRun) {
      for (const sup of enabledSuppliers.filter((s) => s.status === 'connected' && supplierCatalogMeta[s.id]?.catalogComplete !== 0)) {
        const liveIds = new Set((supplierCatalogs[sup.id] || []).map((it: any) => String(it?.id ?? it?.product_id ?? '')).filter(Boolean));
        for (const p of masterProducts) {
          if (!p?.autoCreated || !String(p.autoKey || '').startsWith(`${sup.id}|`)) continue;
          const match = p.supplierMatches?.[sup.id];
          const itemIds = Array.isArray(match?.itemIds) ? match.itemIds.map(String) : match?.supplierProductId != null ? [String(match.supplierProductId)] : [];
          if (itemIds.length && !itemIds.some((id: string) => liveIds.has(id))) {
            const changed = p.inStock !== false || Number(p.stock) !== 0 || p.syncStatus !== 'supplier_unavailable';
            p.inStock = false;
            p.stock = 0;
            p.lastSyncedAt = nowIso;
            p.syncStatus = 'supplier_unavailable';
            if (changed) updatedProductsCount++;
          }
        }
      }
    }

    // No cross-supplier matching or cross-supplier price fallback is allowed.

    // Import every identifiable catalog item from both suppliers; exclude only Ehadish mobile handsets. Unpriced products remain inactive.
    const created = autoCreateProducts(masterProducts, enabledSuppliers.filter((s) => s.status === 'connected'), supplierCatalogs, consumed, settings, nowIso, options);
    for (const np of created) masterProducts.push(np);
    updatedProductsCount += created.length;

    // شمارنده‌های باکس‌ها دقیقاً از همان فهرست‌های جزئیات ساخته می‌شود (عدد باکس = تعداد ردیف‌های جزئیات)
    const detailsPath = path.join(DATA_DIR, 'supplier_match_details.json');
    const savedDetails = readJsonFile<Record<string, any>>(detailsPath, {});
    for (const sup of enabledSuppliers) {
      const d = details[sup.id];
      d.matched = Array.from(new Map(d.matched.map((m: any) => [`${m.productId}:${m.supplierProductId ?? ''}`, m])).values());
      d.colors = Array.from(new Map(d.colors.map((m: any) => [`${m.productId}:${m.color}:${m.supplierPrice}`, m])).values());
      const importedProducts = masterProducts.filter((p: any) => p?.autoCreated && (String(p.autoKey || '').startsWith(`${sup.id}|`) || Array.isArray(p.supplierMatches?.[sup.id]?.itemIds) || p.supplierMatches?.[sup.id]?.supplierProductId != null));
      // Keep the details modal consistent with the dashboard for auto-imported products too.
      for (const product of importedProducts) {
        const sourceMatch = product.supplierMatches?.[sup.id] || {};
        const itemIds = Array.isArray(sourceMatch.itemIds) ? sourceMatch.itemIds.map(String) : sourceMatch.supplierProductId != null ? [String(sourceMatch.supplierProductId)] : [];
        d.matched.push({
          productId: String(product.id), productName: pLabel(product), confidence: 'exact',
          reason: 'ثبت خودکار از کاتالوگ تأمین‌کننده', supplierProductId: itemIds[0] || product.sourceProductId || '',
          itemIds,
        });
        for (const variant of (Array.isArray(product.variants) ? product.variants : [])) {
          for (const option of (Array.isArray(variant.options) ? variant.options : [])) {
            const color = String(option.name || option.value || '').trim();
            if (!color) continue;
            d.colors.push({
              productId: String(product.id), productName: pLabel(product), color,
              productColor: color, supplierColor: color, supplierPrice: Number(option.sourcePrice ?? option.price) || 0,
              supplierProductId: itemIds[0] || product.sourceProductId || '',
              reason: 'رنگ ثبت‌شده از کاتالوگ تأمین‌کننده',
            });
          }
        }
      }
      d.matched = Array.from(new Map(d.matched.map((m: any) => [`${m.productId}:${m.supplierProductId ?? ''}`, m])).values());
      d.colors = Array.from(new Map(d.colors.map((m: any) => [`${m.productId}:${m.color}:${m.supplierPrice}`, m])).values());
      // Dashboard linked count includes both existing master matches
      // from the supplier; a successfully imported catalog must not misleadingly show 0.
      const linkedMasterProductIds = new Set<string>([
        ...d.matched.map((m: any) => String(m.productId || '')).filter(Boolean),
        ...importedProducts.map((p: any) => String(p.id || '')).filter(Boolean),
      ]);
      sup.matchedCount = Math.min(sup.sourceTotalProducts || linkedMasterProductIds.size, linkedMasterProductIds.size);
      const linkedColors = new Set<string>();
      for (const color of d.colors) linkedColors.add(`${String(color.productId || '')}:${colorKey(String(color.color || ''))}`);
      for (const product of importedProducts) {
        for (const variant of (Array.isArray(product.variants) ? product.variants : [])) {
          for (const option of (Array.isArray(variant.options) ? variant.options : [])) {
            const color = String(option.name || option.value || '').trim();
            if (color) linkedColors.add(`${String(product.id || '')}:${colorKey(color)}`);
          }
        }
      }
      sup.inStockColorsCount = linkedColors.size;
      sup.ambiguousCount = d.ambiguous.length;
      const importedInStock = importedProducts.filter((p: any) => p.inStock === true && Number(p.stock) > 0).length;
      const importedNeedsPrice = importedProducts.filter((p: any) => !(Number(p.price) > 0) || p.priceMissing === true).length;
      sup.importedProductsCount = importedProducts.length;
      sup.importedInStockProductsCount = importedInStock;
      sup.importedOutOfStockProductsCount = importedProducts.filter((p: any) => !(p.inStock === true && Number(p.stock) > 0)).length;
      sup.productsNeedingPriceCount = Math.max(Number(supplierStats[sup.id].productsNeedingPriceCount || 0), importedNeedsPrice);
      sup.excludedMobilePhonesCount = Number(supplierStats[sup.id].excludedMobilePhonesCount || 0);
      sup.catalogComplete = sup.status === 'connected' && supplierCatalogMeta[sup.id]?.catalogComplete !== 0;
      Object.assign(supplierStats[sup.id], { matchedCount: sup.matchedCount, inStockColorsCount: sup.inStockColorsCount, ambiguousCount: sup.ambiguousCount, importedProductsCount: sup.importedProductsCount, importedInStockProductsCount: sup.importedInStockProductsCount, importedOutOfStockProductsCount: sup.importedOutOfStockProductsCount, productsNeedingPriceCount: sup.productsNeedingPriceCount, excludedMobilePhonesCount: sup.excludedMobilePhonesCount, catalogComplete: sup.catalogComplete });
      savedDetails[sup.id] = { ...d, updatedAt: nowIso };
    }
    savedDetails._store = { matched: [], colors: [], ambiguous: identityIssues, updatedAt: nowIso };
    if (!options.dryRun) writeJsonFile(detailsPath, savedDetails);

    // قاعده‌ی ثابت: کالاهای موجود هرگز حذف/جابه‌جا نمی‌شوند؛ تنها اضافه‌شده‌ها کالاهای غیرگوشی ساخته‌شده‌ی خودکارند.
    const keptOk = masterIdsAtStart.every((id, i) => masterProducts[i]?.id === id);
    const extrasOk = masterProducts.slice(masterIdsAtStart.length).every((p: any) => p?.autoCreated === true && String(p?.id).startsWith('prod-auto-'));
    if (!keptOk || !extrasOk) {
      throw new Error('همگام‌سازی نباید کالایی حذف/جابه‌جا کند یا کالای غیرمجاز بسازد؛ ذخیره‌سازی متوقف شد.');
    }

    if (!options.dryRun && updatedProductsCount > 0) {
      writeJsonFile(productsPath, masterProducts);
    }
    if (!options.dryRun) saveSuppliersList(suppliers);

    if (!options.dryRun && typeof onUpdateNotify === 'function' && updatedProductsCount > 0) {
      onUpdateNotify();
    }

    const connectedCount = enabledSuppliers.filter((s) => s.status === 'connected').length;
    const totalMatched = Object.values(supplierStats).reduce((a, s: any) => a + (s.matchedCount || 0), 0);

    const incompleteSuppliers = enabledSuppliers.filter((s) => s.status === 'connected' && supplierCatalogMeta[s.id]?.catalogComplete === 0);
    const message =
      enabledSuppliers.length === 0
        ? 'هیچ تأمین‌کننده فعال و قابل دسترسی برای همگام‌سازی پیدا نشد.'
        : `همگام‌سازی انجام شد — ${enabledSuppliers.length} تأمین‌کننده محدود (کسری پلاس و هدیش) بررسی شدند (${connectedCount} متصل)، ${enabledSuppliers.filter((s) => s.status === 'connected').reduce((n, s) => n + Number(s.importedProductsCount || 0), 0)} کالای خودکار ثبت‌شده؛ هر کالا مستقل و فقط با قیمت تأمین‌کننده خودش + ۵٪ به‌روزرسانی شد. ${created.length ? created.length + ' کالای جدید ثبت شد. ' : ''}${incompleteSuppliers.length ? `هشدار: کاتالوگ ${incompleteSuppliers.map((s) => s.name).join('، ')} ناقص دریافت شد؛ وضعیت کالاهای غایب حفظ شد.` : ''}`;

    if (!options.dryRun) recordAuditLog('multi_supplier_sync', message, 'admin', { enabledCount: enabledSuppliers.length, connectedCount, totalMatched, updatedProductsCount, markupPercent: approvedMarkupPercent });

    const beforeById = new Map(originalProducts.map((p: any) => [String(p?.id), p]));
    // Keep the full change set for durable history. The response is capped separately
    // so a large catalogue cannot silently lose history events after item 500.
    const allPlannedChanges = masterProducts.flatMap((after: any) => {
      const before = beforeById.get(String(after?.id));
      if (!before) return [{ productId: String(after?.id || ''), productName: pLabel(after), changeType: 'created' as const, after }];
      if (JSON.stringify(before) === JSON.stringify(after)) return [];
      return [{ productId: String(after?.id || ''), productName: pLabel(after), changeType: 'updated' as const, before, after }];
    });
    const plannedChanges = allPlannedChanges.slice(0, 500);

    // سابقهٔ افزایشی قیمت/موجودی؛ پیش‌نمایش هیچ تاریخچه‌ای را نمی‌نویسد.
    // تغییر بیش از ۳۰٪ فقط علامت‌گذاری می‌شود و به‌تنهایی تصمیم خودکار یا لغو سفارش ایجاد نمی‌کند.
    if (!options.dryRun && plannedChanges.length) {
      const historyPath = path.join(DATA_DIR, 'supplier_price_stock_history.json');
      const history = readJsonFile<any[]>(historyPath, []);
      const events: any[] = [];
      const collect = (c: any) => {
        const before = c.before || {};
        const after = c.after || {};
        const push = (variantId: string, name: string, oldPrice: any, newPrice: any, oldStock: any, newStock: any, supplierId?: string) => {
          const op = Number(oldPrice), np = Number(newPrice);
          const hasPrices = Number.isFinite(op) && op > 0 && Number.isFinite(np) && np > 0;
          const pct = hasPrices ? ((np - op) / op) * 100 : null;
          const anomaly = pct !== null && Math.abs(pct) > 30;
          if (oldPrice === newPrice && oldStock === newStock) return;
          events.push({ id: `${nowIso}:${c.productId}:${variantId}:${events.length}`, timestamp: nowIso, productId: c.productId, productName: c.productName, variantId, variantName: name, supplierId: supplierId || after.referenceSupplierId || null, oldPrice: oldPrice ?? null, newPrice: newPrice ?? null, oldStock: oldStock ?? null, newStock: newStock ?? null, priceChangePercent: pct === null ? null : Math.round(pct * 100) / 100, anomaly, anomalyReason: anomaly ? `تغییر قیمت ${Math.round(pct! * 100) / 100}٪؛ ثبت خودکار انجام شد (این هشدار مانع اعمال قیمت نیست)` : null, reviewStatus: 'recorded' });
        };
        const beforeOpts = new Map<string, any>();
        for (const g of Array.isArray(before.variants) ? before.variants : []) for (const o of Array.isArray(g.options) ? g.options : []) beforeOpts.set(String(o.id || o.name), o);
        for (const g of Array.isArray(after.variants) ? after.variants : []) for (const o of Array.isArray(g.options) ? g.options : []) {
          const key = String(o.id || o.name), old = beforeOpts.get(key);
          push(key, String(o.name || o.value || key), old?.price, o.price, old?.stock, o.stock, o.referenceSupplierId);
        }
        if (!Array.isArray(after.variants) || !after.variants.some((g: any) => Array.isArray(g.options) && g.options.length)) push(String(c.productId), c.productName, before.price, after.price, before.stock, after.stock, after.referenceSupplierId);
      };
      allPlannedChanges.forEach(collect);
      if (events.length) {
        const validHistory = Array.isArray(history) ? history : [];
        writeJsonFile(historyPath, [...validHistory, ...events].slice(-5000));
      }
    }
    return { success: true, message: options.dryRun ? `پیش‌نمایش انجام شد؛ ${plannedChanges.length} تغییر پیشنهادی، بدون ذخیره در فایل‌های داده.` : message, updatedMasterProducts: updatedProductsCount, plannedChanges, dryRun: !!options.dryRun, supplierStats, timestamp: nowIso };
  } finally {
    isSyncRunning = false;
  }
}
