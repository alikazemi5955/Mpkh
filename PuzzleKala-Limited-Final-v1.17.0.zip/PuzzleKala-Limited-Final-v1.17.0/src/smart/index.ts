// ثبت هوشمند چندمنبعی: مدیر نام/مشخصات کالا یا لینک آن را می‌دهد؛ شواهد از چند منبع جمع می‌شود،
// هر شاهد با هویت درخواست تطبیق داده می‌شود و فقط شاهد هم‌خوان وارد فرم می‌شود. هیچ مقدار حدسی (مثل 8/256) نیست.
import { parseQuery, type ParsedQuery } from './queryParser.js';
import { canonicalLabel } from '../identity.js';
import { verifyEvidence, type Verified, type Rejected } from './verify.js';
import { defaultSources, type Evidence, type EvidenceSource, type Spec } from './sources.js';
import { buildNames, dedupeColors, subcategoryOf, CATEGORY_OF, REQUIRED_SPECS, WARRANTY_18M, faCapacity, type Draft } from './validate.js';
import { analyze, defaultFetchBuffer, loadSharp, saveImages, selectImages, type Candidate, type ImageDeps } from './images.js';

export interface SmartDeps { sources?: EvidenceSource[]; images?: ImageDeps; saveRoot?: string }
const slugOf = (name: string) => name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || `product-${Date.now()}`;
const PRIORITY = (s: string) => (s === 'url' ? 0 : s === 'digikala' ? 1 : s === 'gemini' ? 2 : 3);
const pairOf = (v: Verified) => `${v.identity.ram ?? '?'}/${v.identity.storage ?? '?'}`;

export interface EvidenceConflict {
  field: string;
  values: { value: string; source: string; url?: string; title: string }[];
}

/**
 * Finds conflicting claims across independently verified sources. We don't silently
 * let source priority erase a disagreement: the draft can still be prepared, but it
 * is explicitly marked for human review with source-level evidence.
 */
export function detectEvidenceConflicts(items: Verified[]): EvidenceConflict[] {
  const fieldKey = (label: string) => {
    const raw = label.toLowerCase();
    if (/باتری|battery/.test(raw)) return 'battery';
    if (/نمایشگر|صفحه نمایش|screen|display/.test(raw)) return 'screen';
    if (/وزن|weight/.test(raw)) return 'weight';
    if (/ابعاد|dimension/.test(raw)) return 'dimensions';
    if (/دوربین|camera/.test(raw)) return 'camera';
    return canonicalLabel(label).trim();
  };
  const byField = new Map<string, Map<string, EvidenceConflict['values'][number]>>();
  for (const item of items) {
    for (const spec of item.ev.specs || []) {
      const field = fieldKey(String(spec.label || '')).trim();
      const value = String(spec.value || '').trim().replace(/\s+/g, ' ');
      if (!field || !value) continue;
      // Ignore broad generic labels: they are not safe keys for comparison.
      if (field.length > 40 || /^(ویژگی|مشخصه|description|details|other)$/i.test(field)) continue;
      const normalized = value.toLocaleLowerCase('fa-IR').replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[\s،,؛;]+/g, ' ').trim();
      const values = byField.get(field) || new Map<string, EvidenceConflict['values'][number]>();
      if (!values.has(normalized)) values.set(normalized, { value, source: item.ev.sourceLabel, url: item.ev.url, title: item.ev.title });
      byField.set(field, values);
    }
  }
  return [...byField.entries()]
    .filter(([, values]) => values.size > 1)
    .map(([field, values]) => ({ field, values: [...values.values()].slice(0, 6) }));
}

export async function smartRegister(query: string, deps: SmartDeps = {}) {
  const q: ParsedQuery = parseQuery(query);
  const warnings: string[] = [], stages: string[] = [];
  const fail = (message: string, extra: any = {}) => ({ success: false as const, message, warnings, diagnostics: { parsed: { brand: q.identity.brand, model: q.identity.model, modifiers: q.identity.modifiers, ram: q.ram, storage: q.storage }, ...extra } });

  if (!q.url && !q.identity.model) return fail('مدل از متن شما تشخیص داده نشد. مثال: «سامسونگ A57 12/256» یا «iPhone 16 Pro 256»، یا لینک صفحه‌ی محصول را بدهید.', { stage: 'parse' });
  if (q.identity.conflicts.length) return fail('ورودی شما متناقض است (' + q.identity.conflicts.join('، ') + ')؛ آن را دقیق‌تر بنویسید.', { stage: 'parse' });

  // ۱) جمع‌آوری شواهد از همه‌ی منابع، به‌صورت موازی؛ شکست یک منبع بقیه را نمی‌شکند
  const sources = deps.sources ?? defaultSources;
  const status: Record<string, string> = {};
  const all: Evidence[] = [];
  await Promise.all(sources.map(async (s) => {
    try { const r = await s.find(q); status[s.id] = `${r.length} شاهد`; all.push(...r); stages.push(s.id); }
    catch (e: any) { status[s.id] = 'خطا: ' + (e?.message || 'نامشخص'); }
  }));
  if (!all.length) return fail('هیچ منبعی اطلاعاتی برای این کالا برنگرداند. اتصال اینترنت را بررسی کنید، لینک صفحه‌ی محصول را بدهید، یا GEMINI_API_KEY را تنظیم کنید. اطلاعات حدسی وارد نمی‌شود.', { stage: 'evidence', sources: status });

  // ۲) تطبیق دقیق هر شاهد با درخواست
  const good: Verified[] = [], bad: Rejected[] = [];
  for (const ev of all) { const v = verifyEvidence(q, ev); if (v.ok) good.push({ ev, identity: v.identity }); else bad.push({ ev, reasons: v.reasons }); }
  const rejectedSample = bad.slice(0, 6).map((b) => ({ title: b.ev.title.slice(0, 90), source: b.ev.sourceLabel, reasons: b.reasons }));
  if (!good.length) return fail('شاهد قابل‌اعتمادی که دقیقاً با درخواست شما (برند، مدل، نسخه، رم و حافظه) بخواند پیدا نشد؛ برای جلوگیری از ثبت اشتباه، چیزی وارد نشد.', { stage: 'verify', sources: status, rejected: rejectedSample });

  // ۳) روشن‌کردن رم/حافظه — هرگز پیش‌فرض نمی‌گذاریم
  let ram = q.ram, storage = q.storage;
  const need = REQUIRED_SPECS[q.identity.category] || [];
  const pairs = new Map<string, Verified[]>();
  for (const g of good) { if ((g.identity.ram !== null || g.identity.storage !== null)) { const k = pairOf(g); pairs.set(k, [...(pairs.get(k) || []), g]); } }
  let chosen = good;
  let variantList: string[] = [];
  if ((ram === undefined && need.includes('ram')) || (storage === undefined && need.includes('storage'))) {
    const keys = [...pairs.keys()];
    if (keys.length === 1) {
      const g = pairs.get(keys[0])![0];
      ram ??= g.identity.ram ?? undefined; storage ??= g.identity.storage ?? undefined;
      warnings.push(`رم/حافظه در درخواست نبود؛ طبق شاهد (${g.ev.sourceLabel}) ${ram ? 'رم ' + ram + ' و ' : ''}حافظه ${storage} ثبت شد — لطفاً بررسی کنید.`);
    } else if (keys.length > 1) {
      // چند نسخه: اطلاعات عمومی مدل پر می‌شود ولی رم/حافظه خالی می‌ماند (حدس زده نمی‌شود) و نسخه‌ها در هشدار فهرست می‌شوند
      variantList = keys;
      const first = good.slice().sort((a, b) => PRIORITY(a.ev.source) - PRIORITY(b.ev.source))[0];
      const k0 = pairOf(first);
      good.splice(0, good.length, ...pairs.get(k0)!);
      warnings.push(`این مدل چند نسخه دارد (${keys.join('، ')} — رم/حافظه). مشخصات عمومی پر شد ولی رم و حافظه خالی ماند؛ نسخه‌ی دقیق را در جستجو بنویسید (مثلاً «${q.brandFa || ''} ${q.modelText} ${keys[0].replace('?', '')}») یا نام و مشخصات را دستی کامل کنید.`);
    } else {
      return fail('رم/حافظه این کالا در درخواست شما نبود و منابع هم آن را روشن نکردند. نسخه‌ی دقیق را بنویسید (مثلاً 8/256).', { stage: 'variants', sources: status });
    }
  }
  // فقط شواهد هم‌نسخه (یا بدون نسخه) نگه داشته می‌شوند
  chosen = variantList.length ? good : good.filter((g) => (ram === undefined || g.identity.ram === null || g.identity.ram === ram) && (storage === undefined || g.identity.storage === null || g.identity.storage === storage));
  if (!chosen.length) return fail('شاهدی با همین رم/حافظه پیدا نشد؛ نسخه‌ی درخواستی در منابع موجود نیست یا اشتباه نوشته شده است.', { stage: 'verify', sources: status, rejected: rejectedSample });
  chosen.sort((a, b) => PRIORITY(a.ev.source) - PRIORITY(b.ev.source) || b.ev.specs.length - a.ev.specs.length);
  const evidenceConflicts = detectEvidenceConflicts(chosen);
  if (evidenceConflicts.length) warnings.push(`منابع درباره‌ی ${evidenceConflicts.length} مشخصه اختلاف دارند؛ قبل از انتشار باید مقادیر و منبع هرکدام بررسی شود.`);

  // ۴) تکمیل جزئیات (فقط برای چند شاهد برتر)
  await Promise.all(chosen.slice(0, 3).map(async (c) => {
    if (!c.ev.load) return;
    try { const more = await c.ev.load(); if (more) c.ev = { ...c.ev, ...more, images: [...new Set([...(more.images || []), ...c.ev.images])] }; } catch { /* ادامه */ }
  }));

  // ۵) ادغام: رنگ و مشخصات از بهترین منبع «غیر‌تأمین‌کننده»، تأمین‌کننده فقط جایگزین؛ عکس‌ها از همه
  const rich = chosen.filter((c) => !c.ev.source.startsWith('supplier'));
  const pickList = <T,>(sel: (e: Evidence) => T[]) => { for (const c of [...rich, ...chosen]) { const l = sel(c.ev); if (l.length) return l; } return [] as T[]; };
  const colors = dedupeColors(pickList((e) => e.colors));
  const specs: Spec[] = []; const seenSpec = new Set<string>();
  for (const c of rich) for (const s of c.ev.specs) { if (variantList.length && /رم|حافظه|ظرفیت|ram|storage|memory/i.test(s.label)) continue; const k = s.label.replace(/\s+/g, ''); if (!seenSpec.has(k)) { seenSpec.add(k); specs.push(s); } }
  const best = chosen[0];
  const idBase = q.identity.model ? q.identity : best.identity; // اگر فقط لینک داده شده، هویت از شاهد تأییدشده می‌آید
  const { name, persianName, brandFa } = buildNames(q, idBase, ram, storage, chosen.map((c) => c.ev.title).find((t) => /^[\x20-\x7e]+$/.test(t)));
  const category = idBase.category;
  const sourceDescription = rich.map((c) => c.ev.description).find((d) => d && d.length > 40)?.trim() || '';
  const cleanSpecs = specs.slice(0, 60).filter((s) => s.label?.trim() && s.value?.trim());
  const keyFeatures = cleanSpecs.slice(0, 6).map((s) => `${s.label}: ${s.value}`);
  // وقتی منبع توضیح فارسی ندارد، متن قابل استفاده را فقط از هویت و مشخصات تأییدشده می‌سازیم؛
  // هیچ ویژگی فنی یا نظر مشتری ساختگی تولید نمی‌شود.
  const verifiedSummary = cleanSpecs.slice(0, 4).map((s) => `${s.label}: ${s.value}`).join('؛ ');
  const description = sourceDescription || (verifiedSummary
    ? `${persianName} با مشخصات ثبت‌شده شامل ${verifiedSummary}. این توضیحات بر پایه مشخصات استخراج‌شده تهیه شده و پیش از انتشار باید با منبع محصول تطبیق داده شود.`
    : `${persianName}. اطلاعات فنی کافی از منابع در دسترس استخراج نشد؛ مشخصات و جزئیات تکمیلی پیش از انتشار باید توسط مدیر بررسی و تکمیل شود.`);
  const fullDescription = [
    `معرفی کالا: ${persianName}.`,
    verifiedSummary ? `مشخصات تأییدشده در این پیش‌نویس: ${verifiedSummary}.` : 'در حال حاضر مشخصات فنی تأییدشده کافی برای شرح جزئیات در دسترس نیست.',
    'وضعیت محتوا: پیش‌نویس تولیدشده از اطلاعات منابع؛ پیش از انتشار، صحت مشخصات، نسخه، رنگ و سازگاری آن‌ها را بررسی کنید.'
  ].join('\n\n');
  const review = `بررسی اولیه ${persianName}: ` + (cleanSpecs.length
    ? `بر اساس ${cleanSpecs.length} مشخصه استخراج‌شده، موارد قابل ارزیابی عبارت‌اند از ${verifiedSummary || cleanSpecs.slice(0, 3).map((s) => `${s.label}: ${s.value}`).join('؛ ')}. این متن تحلیل اولیه بر پایه مشخصات است، نه نظر خریدار یا آزمون مستقل. قبل از انتشار، مشخصات و نتیجه‌گیری‌ها را بازبینی کنید.`
    : 'منابع فعلی اطلاعات فنی کافی برای ارزیابی قابل اتکا ارائه نکردند. این بخش نظر خریدار یا بررسی آزمایشگاهی نیست؛ پس از تکمیل مشخصات فنی، تحلیل دقیق‌تری تهیه شود.');
  const draft: Draft = {
    name, persianName, brand: brandFa, modelCode: chosen.map((c) => c.ev.modelCode).find(Boolean), category: CATEGORY_OF[category] || 'other',
    subcategory: subcategoryOf(idBase.brand, category), ram, storage, releaseYear: chosen.map((c) => c.ev.releaseYear).find(Boolean),
    description, fullDescription, review,
    keyFeatures: keyFeatures.length ? keyFeatures : ['مدل و هویت کالا از ورودی مدیر استخراج شده است؛ مشخصات فنی نیازمند تکمیل دستی است.'], tags: [brandFa, idBase.model].filter(Boolean) as string[],
    warranty: WARRANTY_18M, colors, technicalSpecs: cleanSpecs, images: [],
  };
  if (!colors.length) warnings.push('هیچ رنگی از منابع پیدا نشد؛ رنگ‌ها را دستی وارد کنید.');
  if (specs.length < 6) warnings.push(`مشخصات فنی کم است (${specs.length} مورد).`);
  if (!sourceDescription) warnings.push('توضیح مستقیم از منبع پیدا نشد؛ متن معرفی و بررسی اولیه فقط از هویت/مشخصات موجود ساخته شده و باید پیش از انتشار بازبینی شود.');
  if (!cleanSpecs.length) warnings.push('هیچ مشخصه فنی تأییدشده‌ای استخراج نشد؛ متن بررسی، ارزیابی فنی محسوب نمی‌شود.');

  // ۶) عکس‌ها (از همه‌ی شواهد تأییدشده)
  const cands: Candidate[] = []; let rank = 0;
  for (const c of chosen) for (const url of c.ev.images) if (!cands.some((x) => x.url === url)) cands.push({ url, source: c.ev.source, rank: rank++ });
  const sharp = deps.images && 'sharp' in deps.images ? deps.images.sharp : await loadSharp();
  const fetchBuf = deps.images?.fetchBuffer ?? defaultFetchBuffer;
  const got = (await Promise.all(cands.slice(0, 14).map(async (c) => { const b = await fetchBuf(c.url); return b ? analyze(c, b, sharp) : null; }))).filter(Boolean) as any[];
  const sel = selectImages(got); warnings.push(...sel.warnings);
  draft.images = sel.selected.length ? await saveImages(slugOf(draft.name), sel.selected, sharp, deps.saveRoot) : [];
  if (draft.images.length < 4) warnings.push('تعداد عکس‌های معتبر کمتر از ۴ است.');

  // ۷) اطمینان: تعداد منابع مستقل هم‌نظر
  const agreeing = new Set(chosen.map((c) => c.ev.source.split(':')[0] === 'supplier' ? 'supplier' : c.ev.source)).size;
  let score = agreeing >= 3 ? 0.9 : agreeing === 2 ? 0.8 : 0.6;
  score -= Math.min(0.3, warnings.length * 0.04);
  score = Math.max(0, Math.min(1, Number(score.toFixed(2))));
  return {
    success: true as const,
    product: { ...draft, ram: faCapacity(ram), storage: faCapacity(storage), source: 'puzzlekala' },
    meta: { confidence: score, parsedQuery: { brand: q.identity.brand, model: q.identity.model, modifiers: q.identity.modifiers, ram, storage }, needsReview: score < 0.8 || warnings.length > 0, warnings, stages,
      sources: chosen.slice(0, 6).map((c) => ({ title: c.ev.title, url: c.ev.url || '', source: c.ev.sourceLabel, specsCount: c.ev.specs.length, imageCount: c.ev.images.length })), sourceStatus: status, rejected: rejectedSample, evidenceConflicts, ...(variantList.length ? { variants: variantList } : {}) },
  };
}
export { parseQuery };
