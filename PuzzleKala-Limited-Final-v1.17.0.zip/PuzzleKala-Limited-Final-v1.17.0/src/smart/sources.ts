// منابع شواهد ثبت هوشمند. هیچ منبعی اجباری نیست: دیجی‌کالا فقط «یکی از منابع» است.
// منابع: ۱) دیجی‌کالا ۲) هر لینک صفحه‌ی محصول (JSON-LD/متا/جدول مشخصات) ۳) کاتالوگ تأمین‌کننده‌ها (فقط‌خواندنی)
//        ۴) Gemini با جستجوی گوگل (فقط اگر GEMINI_API_KEY تنظیم شده باشد).
// هر شاهد قبل از استفاده با هویت درخواست مدیر تطبیق داده می‌شود (verify.ts)؛ چیزی بی‌بررسی وارد فرم نمی‌شود.
import { isSafeUrl } from './images.js';
import type { ParsedQuery } from './queryParser.js';
import { brandNames } from './queryParser.js';
import { getSuppliersList, getAdapter } from '../supplierEngine.js';

export interface Spec { title?: string; label: string; value: string }
export interface Evidence {
  source: string;            // شناسه‌ی منبع: digikala | url | supplier:<id> | gemini
  sourceLabel: string;
  title: string;             // عنوان کامل کالا در آن منبع (شامل رم/حافظه) — مبنای تطبیق
  url?: string;
  images: string[];
  colors: { name: string; colorCode?: string }[];
  specs: Spec[];
  description?: string;
  modelCode?: string;
  releaseYear?: number;
  /** تکمیل تنبل جزئیات (فقط برای شواهدی که تأیید شدند صدا زده می‌شود) */
  load?: () => Promise<Partial<Evidence> | null>;
}
export interface EvidenceSource { id: string; label: string; find(q: ParsedQuery): Promise<Evidence[]> }

const ctlFetch = async (url: string, ms: number, init: RequestInit = {}) => {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try { // A user-supplied product URL must not be allowed to redirect the server to an internal address.
    return await fetch(url, { ...init, redirect: 'error', signal: ctl.signal, headers: { 'User-Agent': 'Mozilla/5.0 PuzzleKalaBot', ...(init.headers || {}) } }); } finally { clearTimeout(t); }
};
const getJson = async (url: string, ms = 9000): Promise<any | null> => {
  try { const r = await ctlFetch(url, ms, { headers: { Accept: 'application/json' } }); return r.ok ? await r.json() : null; } catch { return null; }
};
const searchTerms = (q: ParsedQuery) => [q.brandEn, q.modelText, q.storage ? `${q.storage}GB` : ''].filter(Boolean).join(' ');

// ------------------------------------------------------------------ دیجی‌کالا
export const digikalaSource: EvidenceSource = {
  id: 'digikala', label: 'دیجی‌کالا',
  async find(q) {
    // جستجوی فارسی و انگلیسی با هم (دیجی‌کالا برای نام فارسی برند بهتر جواب می‌دهد)
    const fa = [q.brandFa, q.modelText, q.storage ? `${q.storage} گیگابایت` : ''].filter(Boolean).join(' ');
    const rs = await Promise.all([searchTerms(q), fa].filter((t, i, a) => t && a.indexOf(t) === i).map((t) => getJson(`https://api.digikala.com/v1/search/?q=${encodeURIComponent(t)}&page=1`)));
    const seenIds = new Set<number>();
    const list = rs.flatMap((d) => (Array.isArray(d?.data?.products) ? d.data.products : [])).filter((p: any) => p?.id && !seenIds.has(p.id) && seenIds.add(p.id));
    if (!list.length) return [];
    return list.slice(0, 16).map((p: any): Evidence | null => {
      const id = Number(p.id), title = String(p.title_fa || ''); if (!id || !title) return null;
      const main = p.images?.main?.url?.[0];
      return {
        source: 'digikala', sourceLabel: 'دیجی‌کالا', title, url: `https://www.digikala.com/product/dkp-${id}/`,
        images: main ? [String(main).split('?')[0]] : [], colors: [], specs: [],
        async load() {
          const dd = await getJson(`https://api.digikala.com/v2/product/${id}/`); const pp = dd?.data?.product; if (!pp) return null;
          const images = [pp.images?.main?.url?.[0], ...(pp.images?.list || []).map((i: any) => i?.url?.[0])].filter(Boolean).map((u: string) => u.split('?')[0]);
          const colors = (pp.colors || []).map((c: any) => ({ name: String(c.title || ''), colorCode: c.hex_code ? '#' + String(c.hex_code).replace('#', '') : undefined })).filter((c: any) => c.name);
          const specs: Spec[] = [];
          for (const g of pp.specifications || []) for (const a of g.attributes || []) { const v = Array.isArray(a.values) ? a.values.join('، ') : ''; if (a.title && v) specs.push({ title: g.title, label: String(a.title), value: v }); }
          return { images, colors, specs };
        },
      };
    }).filter(Boolean) as Evidence[];
  },
};

// ------------------------------------------------------------------ لینک دلخواه (هر فروشگاه/سایت)
const decode = (s: string) => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ');
const stripTags = (s: string) => decode(s.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
const meta = (html: string, key: string) => {
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*>`, 'i'); const m = html.match(re)?.[0];
  return m ? decode(m.match(/content=["']([^"']*)["']/i)?.[1] || '') : '';
};

/** استخراج شاهد از HTML یک صفحه‌ی محصول: JSON-LD → متا → جدول مشخصات (بدون وابستگی به سایت خاص) */
export function evidenceFromHtml(html: string, pageUrl: string): Evidence | null {
  let title = '', images: string[] = [], description = '', colors: Evidence['colors'] = [], modelCode: string | undefined;
  for (const m of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    let data: any; try { data = JSON.parse(m[1].trim()); } catch { continue; }
    const stack = Array.isArray(data) ? [...data] : [data];
    while (stack.length) {
      const n = stack.shift(); if (!n || typeof n !== 'object') continue;
      if (Array.isArray(n['@graph'])) stack.push(...n['@graph']);
      const type = [].concat(n['@type'] || []).join(',');
      if (/Product/i.test(type) && !title) {
        title = String(n.name || ''); description = String(n.description || '');
        modelCode = n.mpn || n.model || n.sku || undefined;
        const im = [].concat(n.image || []).map((x: any) => (typeof x === 'string' ? x : x?.url)).filter(Boolean); images.push(...im);
        if (n.color) colors.push(...String(n.color).split(/[,،/]/).map((c) => ({ name: c.trim() })).filter((c) => c.name));
      }
    }
  }
  if (!title) title = meta(html, 'og:title') || stripTags(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || '');
  if (!description) description = meta(html, 'og:description') || meta(html, 'description');
  const og = meta(html, 'og:image'); if (og) images.push(og);
  images = [...new Set(images.map((u) => { try { return new URL(u, pageUrl).toString(); } catch { return ''; } }).filter(Boolean))];
  const specs: Spec[] = [];
  for (const row of html.matchAll(/<tr[^>]*>\s*<t[hd][^>]*>([\s\S]*?)<\/t[hd]>\s*<t[hd][^>]*>([\s\S]*?)<\/t[hd]>\s*<\/tr>/gi)) {
    const label = stripTags(row[1]), value = stripTags(row[2]);
    if (label && value && label.length < 60 && value.length < 300) specs.push({ label, value });
    if (specs.length >= 60) break;
  }
  for (const row of html.matchAll(/<dt[^>]*>([\s\S]*?)<\/dt>\s*<dd[^>]*>([\s\S]*?)<\/dd>/gi)) {
    const label = stripTags(row[1]), value = stripTags(row[2]);
    if (label && value && label.length < 60 && value.length < 300 && specs.length < 60) specs.push({ label, value });
  }
  if (!title) return null;
  const host = (() => { try { return new URL(pageUrl).hostname.replace(/^www\./, ''); } catch { return 'url'; } })();
  return { source: 'url', sourceLabel: host, title: title.slice(0, 250), url: pageUrl, images, colors, specs, description: description.slice(0, 1500), modelCode: modelCode ? String(modelCode) : undefined };
}

export const urlSource: EvidenceSource = {
  id: 'url', label: 'لینک واردشده',
  async find(q) {
    if (!q.url || !isSafeUrl(q.url)) return [];
    try {
      const r = await ctlFetch(q.url, 12000, { headers: { Accept: 'text/html' } });
      if (!r.ok) return [];
      const html = (await r.text()).slice(0, 2_000_000);
      const ev = evidenceFromHtml(html, q.url);
      return ev ? [ev] : [];
    } catch { return []; }
  },
};

// ------------------------------------------------------------------ کاتالوگ تأمین‌کننده‌ها (فقط شاهد؛ هیچ کالایی از اینجا ساخته نمی‌شود)
export const supplierCatalogSource: EvidenceSource = {
  id: 'supplier', label: 'کاتالوگ تأمین‌کنندگان',
  async find(q) {
    const out: Evidence[] = [];
    const sups = getSuppliersList().filter((s) => s.enabled);
    await Promise.all(sups.map(async (s) => {
      try {
        const r = await getAdapter(s).fetchCatalog(s);
        for (const it of (r.success ? r.items : []).slice(0, 5000)) {
          const title = String(it?.title || it?.name || it?.product_name_en || it?.product_name || it?.persianName || '').trim();
          if (!title) continue;
          const vars: any[] = Array.isArray(it.variants) ? it.variants : Array.isArray(it.colors) ? it.colors : [];
          const colors = vars.map((v) => String(typeof v === 'string' ? v : v?.color || v?.color_name || v?.name || '')).filter(Boolean).map((name) => ({ name }));
          const imgs = [it.image, it.image_url, ...(Array.isArray(it.images) ? it.images : [])].map((x: any) => (typeof x === 'string' ? x : x?.url)).filter(Boolean);
          out.push({ source: `supplier:${s.id}`, sourceLabel: s.name, title, images: imgs, colors, specs: [] });
        }
      } catch { /* تأمین‌کننده‌ی خراب نباید کل ثبت را بشکند */ }
    }));
    // فقط ردیف‌هایی که حداقل برند/مدل شبیه درخواست دارند نگه داشته می‌شوند (ارزان‌ترین فیلتر پیش از تطبیق دقیق)
    const m = q.identity.model;
    return m ? out.filter((e) => e.title.toLowerCase().replace(/[\s\-_]/g, '').includes(m.replace(/\s/g, ''))).slice(0, 40) : [];
  },
};

// ------------------------------------------------------------------ Gemini + جستجوی گوگل (اختیاری)
export const geminiSource: EvidenceSource = {
  id: 'gemini', label: 'Gemini (جستجوی وب)',
  async find(q) {
    const key = process.env.GEMINI_API_KEY; if (!key) return [];
    const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
    const ask = `کالای مورد نظر: «${q.normalized || q.raw}»${q.url ? ` (لینک: ${q.url})` : ''}\nبا جستجوی وب، مشخصات رسمی دقیقاً همین کالا را پیدا کن. اگر چند نسخه (رم/حافظه/شبکه) دارد، فقط نسخه‌ای را بیاور که با درخواست می‌خواند؛ اگر رم/حافظه در درخواست نیست، همه‌ی نسخه‌ها را در variants بیاور. هرگز حدس نزن؛ مقدار نامعلوم را خالی بگذار.\nفقط یک JSON معتبر برگردان با این ساختار:\n{"title":"نام کامل رسمی کالا شامل مدل و رم و حافظه","modelCode":"","releaseYear":0,"variants":[{"ram":0,"storage":0}],"colors":[{"name":"","hex":""}],"specs":[{"group":"","label":"","value":""}],"description":"توضیح فارسی کوتاه و واقعی","imageUrls":[]}`;
    try {
      const r = await ctlFetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`, 45000, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: ask }] }], tools: [{ google_search: {} }], generationConfig: { temperature: 0 } }),
      });
      if (!r.ok) return [];
      const j: any = await r.json();
      const text = (j?.candidates?.[0]?.content?.parts || []).map((p: any) => p.text || '').join('');
      const json = text.match(/\{[\s\S]*\}/)?.[0]; if (!json) return [];
      const d = JSON.parse(json);
      const links: string[] = (j?.candidates?.[0]?.groundingMetadata?.groundingChunks || []).map((c: any) => c?.web?.uri).filter(Boolean);
      const base = {
        source: 'gemini', sourceLabel: 'Gemini (جستجوی وب)', url: links[0],
        images: (Array.isArray(d.imageUrls) ? d.imageUrls : []).map(String).filter((u: string) => isSafeUrl(u)),
        colors: (Array.isArray(d.colors) ? d.colors : []).map((c: any) => ({ name: String(c?.name || '').trim(), colorCode: c?.hex ? '#' + String(c.hex).replace('#', '') : undefined })).filter((c: any) => c.name),
        specs: (Array.isArray(d.specs) ? d.specs : []).map((s: any) => ({ title: s?.group ? String(s.group) : undefined, label: String(s?.label || '').trim(), value: String(s?.value || '').trim() })).filter((s: Spec) => s.label && s.value),
        description: d.description ? String(d.description) : undefined, modelCode: d.modelCode ? String(d.modelCode) : undefined, releaseYear: Number(d.releaseYear) || undefined,
      };
      const [brandEn] = brandNames(q.identity.brand);
      const vars: any[] = Array.isArray(d.variants) && d.variants.length ? d.variants : [{}];
      const title0 = String(d.title || '').trim();
      return vars.slice(0, 6).map((v) => {
        const cap = [v?.ram ? `${v.ram}GB RAM` : '', v?.storage ? `${v.storage}GB` : ''].filter(Boolean).join(' ');
        // اگر عنوان خود رم/حافظه را دارد همان؛ وگرنه ظرفیت هر نسخه به آن افزوده می‌شود
        const title = /\d\s*(gb|گیگ|tb|ترا)/i.test(title0) && vars.length === 1 ? title0 : `${title0 || [brandEn, q.modelText].filter(Boolean).join(' ')} ${cap}`.trim();
        return { ...base, title } as Evidence;
      }).filter((e) => e.title);
    } catch { return []; }
  },
};

export const defaultSources: EvidenceSource[] = [digikalaSource, urlSource, supplierCatalogSource, geminiSource];
