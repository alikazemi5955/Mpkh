// ساخت پیش‌نویس کالا از شواهد تأییدشده. هیچ مقدار پیش‌فرض ساختگی (مثل 8/256) در کار نیست.
import type { Identity } from '../identity.js';
import { brandNames, type ParsedQuery } from './queryParser.js';
import type { Spec } from './sources.js';
import { colorKey } from '../identity.js';

export const WARRANTY_18M = 'گارانتی ۱۸ ماهه شرکتی';
const HEX = /^#[0-9a-f]{6}$/i;

export interface Draft {
  name: string; persianName: string; brand: string; modelCode?: string; category: string; subcategory: string;
  ram?: number; storage?: number; releaseYear?: number; description: string; fullDescription: string; review?: string;
  keyFeatures: string[]; tags: string[]; warranty: string;
  colors: { name: string; nameEn?: string; colorCode: string; available?: boolean }[];
  technicalSpecs: Spec[];
  images: string[];
}

export const CATEGORY_OF: Record<string, string> = { phone: 'mobile', tablet: 'tablet', laptop: 'laptop', console: 'console', accessory: 'accessory', other: 'other' };
const FA_KIND: Record<string, string> = { phone: 'گوشی موبایل', tablet: 'تبلت', laptop: 'لپ‌تاپ', console: 'کنسول بازی' };
/** این مشخصه‌ها برای هویت کالا در هر دسته الزامی‌اند؛ اگر نه ورودی و نه منابع روشنشان نکنند، ثبت انجام نمی‌شود */
export const REQUIRED_SPECS: Record<string, ('ram' | 'storage')[]> = { phone: ['ram', 'storage'], tablet: ['ram', 'storage'], laptop: ['ram', 'storage'], console: ['storage'] };

export const faCapacity = (gb?: number | null) => (gb ? (gb >= 1024 ? `${gb / 1024} ترابایت` : `${gb} گیگابایت`) : undefined);

export function fixColor(c: any) {
  const name = String(c?.name || '').trim();
  let code = String(c?.colorCode || c?.hex || '').trim(); if (code && !code.startsWith('#')) code = '#' + code;
  return { name, nameEn: c?.nameEn ? String(c.nameEn).trim() : undefined, colorCode: HEX.test(code) ? code.toLowerCase() : '#64748b', available: c?.available !== false };
}
export function dedupeColors(list: any[]) {
  const seen = new Set<string>(), out: ReturnType<typeof fixColor>[] = [];
  for (const c of list) { const f = fixColor(c); if (!f.name) continue; const k = colorKey(f.name) || f.name.toLowerCase(); if (!seen.has(k)) { seen.add(k); out.push(f); } }
  return out;
}

/** «A57» → «A57»، «iphone 16» → «iPhone 16»؛ ترتیب نسخه‌ها مطابق متن ورودی است */
export function prettyModel(id: Identity, order: string): string {
  const low = order.toLowerCase();
  const mods = [...id.modifiers].sort((a, b) => low.indexOf(a) - low.indexOf(b));
  const w = (id.model || '').split(' ').map((x) => (x === 'iphone' ? 'iPhone' : x === 'ipad' ? 'iPad' : /^[a-z]{1,3}\d+[a-z]*$/.test(x) ? x.toUpperCase() : /^\d/.test(x) ? x : x[0]?.toUpperCase() + x.slice(1)));
  return [...w, ...mods.map((m) => m[0].toUpperCase() + m.slice(1)), id.network || ''].filter(Boolean).join(' ');
}

export function buildNames(q: ParsedQuery, id: Identity, ram?: number, storage?: number, latinTitle?: string) {
  const [brandEn, brandFa] = brandNames(id.brand);
  const model = prettyModel(id, q.normalized);
  const cap = [ram ? `${ram}GB` : '', storage ? (storage >= 1024 ? `${storage / 1024}TB` : `${storage}GB`) : ''].filter(Boolean).join(' ');
  const name = (latinTitle && /^[\x20-\x7e]+$/.test(latinTitle) ? latinTitle : `${brandEn} ${model} ${cap}`).replace(/\s+/g, ' ').trim();
  const kind = FA_KIND[id.category];
  const persianName = kind
    ? `${kind} ${brandFa || brandEn} مدل ${model}${storage ? ` ظرفیت ${faCapacity(storage)}` : ''}${ram ? ` و رم ${faCapacity(ram)}` : ''}`.replace(/\s+/g, ' ').trim()
    : name;
  return { name, persianName, brandFa: brandFa || brandEn };
}

export const subcategoryOf = (brand: string, category: string) =>
  category !== 'phone' ? '' :
  brand === 'apple' ? 'گوشی آیفون (Apple)' : brand === 'samsung' ? 'گوشی سامسونگ (Samsung)' :
  (brand === 'xiaomi' || brand === 'poco') ? 'گوشی شیائومی و پوکو' : 'سایر برندهای موبایل';
