# PuzzleKala 1.17.0 — limited supplier mirror

This is a full standalone project package, based on the existing project tree with the limited supplier engine and server changes overlaid. The legacy storefront bundle is byte-for-byte unchanged from the supplied baseline.

- Limited suppliers: Kasra Plus and Ehadish only.
- Ehadish mobile handsets excluded; Ehadish accessories remain eligible.
- Every supplier product is kept independent and linked to its own supplier.
- Storefront price auto-updates to rounded source price × 1.05; no approval gate blocks valid price updates.
- Failed/incomplete supplier responses preserve the last known valid price and stock. Explicit out-of-stock signals update stock to zero without deleting the product.
- Initial sync + 5-minute polling; manual admin sync; cart snapshots refresh every 30 seconds only while cart contains products.
- Default test admin remains `admin` / `admin123` in development/test. Production disables it unless `PUZZLEKALA_TEST_MODE=true`.

Tests in this environment are simulation/contract tests; live supplier access and Google AI Studio runtime behavior must be checked after import. Five-minute polling is eventual consistency, not guaranteed instant mirroring.
