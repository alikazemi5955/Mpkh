## نسخه 1.14.7 — اصلاح قیمت SSR کسری پلاس و بازیابی صفحات هدیش

- استخراج قیمت هدیش از داده‌های ساختاریافتهٔ JSON-LD (`Product`/`Offer`) و متن قابل مشاهدهٔ «قیمت ... تومان» نیز انجام می‌شود؛ قیمت‌های نامعتبر همچنان قابل فروش نیستند.
- اگر sitemap در دسترس نباشد یا نشانی محصول ندهد، خزنده از صفحات دسته‌بندی عمومی هدیش به‌عنوان مسیر جایگزین استفاده می‌کند؛ مسیرهای جمع `/products/...` به‌اشتباه به‌عنوان صفحهٔ محصول تفسیر نمی‌شوند.
- محصولات بدون قیمت در پنل مدیریت با «ثبت قیمت» و «نیازمند قیمت» مشخص می‌شوند و تا ثبت قیمت معتبر، فعال‌سازی آن‌ها غیرفعال است؛ دیگر صفر به‌عنوان قیمت عادی نمایش داده نمی‌شود.
- تشخیص دسته‌بندی لوازم جانبی قبل از fallback گوشی انجام می‌شود؛ کابل، آداپتور، شارژر، محافظ، هولدر و اکسسوری‌های سازگار با برندهای موبایل نباید به دستهٔ گوشی سقوط کنند.
- دسته‌بندی منبع هنگام ساخت محصول خودکار نیز به موتور تشخیص داده می‌شود.
- **محدودیت تأیید:** اتصال زندهٔ هدیش از محیط ساخت قابل آزمایش نبود. این نسخه اتصال را به‌صورت واقعی تأییدشده ادعا نمی‌کند؛ پس از بارگذاری باید از وضعیت هدیش و گزارش آخرین خطا، علت واقعی اتصال بررسی شود.

## نسخه 1.14.4 — ممیزی نهایی رابط و جریان همگام‌سازی

- رابط مدیریت تأمین‌کنندگان با نسخهٔ ثابت دو منبع (کسری‌پلاس و هدیش) هماهنگ شد؛ مقدار پیش‌فرض ساختگی برای تعداد کالاهای هماهنگ حذف شد.
- وضعیت همگام‌سازی در خطا دیگر پیام موفقیت نشان نمی‌دهد.
- آمار ثبت‌شده، موجودِ ثبت‌شده، نیازمند بررسی قیمت و گوشی‌های حذف‌شدهٔ هدیش در داشبورد اضافه شد.
- فیلتر تأمین‌کنندهٔ هدیش در فهرست کالاها اضافه شد و لینک مرجع کالاهای هدیش به نشانی واقعی منبع اشاره می‌کند.
- مسیر جزئیات تطبیق مبهم، شناسهٔ هدیش و فهرست شناسه‌های ردیف‌ها را نیز بررسی می‌کند.
- شناسهٔ نسخه در `VERSION`، `package.json` و `metadata.json` یکسان‌سازی شد.

این نسخه هنوز نیازمند اجرای build استاندارد و همگام‌سازی زنده در محیط میزبانی است؛ آزمون‌های محلی به‌تنهایی دسترسی به کاتالوگ واقعی تأمین‌کننده را اثبات نمی‌کنند.

<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Puzzle Kala — v1.9.2\n\nRun and deploy the existing AI Studio app


## نسخه 1.9.4

- هنگام ثبت سفارش، نشانی ذخیره‌شده با `addressId` اعتبارسنجی و به‌صورت snapshot ذخیره می‌شود؛ نشانی پیش‌فرض حساب نیز قابل استفاده است.
- لغو مدیریتی به دلیل نیاز دارد؛ ویرایش عمومی سفارش نمی‌تواند اطلاعات مالی یا snapshot نشانی را تغییر دهد.
- مسیر ثبت اقدام مالی دستی مدیر با توضیح و تأیید صریح افزوده شده است؛ این مسیر اتصال درگاه پرداخت نیست.
- اعتبارسنجی کد ملی و ایمیل تکراری هنگام ثبت‌نام سخت‌گیرانه‌تر شده است.
- جزئیات و محدودیت‌ها در `HANDOFF-1.9.4.md` ثبت شده‌اند.

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ad862811-4856-4c46-86ff-976f652efc56

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Production security notes

- Administrative APIs require a real persisted admin session token. Legacy `x-sync-client: puzzle-bridge` and magic admin tokens are not trusted.
- Supplier credentials are stripped from public supplier/status responses.
- Virtual employees and supplier synchronization endpoints require the admin role.
- Set `ADMIN_RESET_PASSWORD` only for a one-time recovery, then remove it from the environment.
- Do not commit `.env`, session files, or real supplier credentials.
- Production serves the Vite `dist/` app while keeping `/legacy/*` as a compatibility runtime for the current UI.

## First production startup

1. Copy `.env.example` to `.env`.
2. Set a long, unique `ADMIN_RESET_PASSWORD` (at least 16 characters).
3. Start the server once so the admin password is hashed into `data/users.json`.
4. Remove `ADMIN_RESET_PASSWORD` from `.env` and restart the server.
5. Change the admin username/password from the admin panel after first login.

The packaged data intentionally contains no working default admin password and no personal customer record.


## قاعده‌ی تأمین‌کننده‌ها (v1.9.0)

**اصل ۱ — گوشی موبایل: فقط ثبت دستی مدیر.** هیچ گوشی‌ای از تأمین‌کننده‌ها وارد فروشگاه نمی‌شود؛ مدیر خودش ثبت می‌کند (ثبت هوشمند یا دستی) و قوانین قیمت/موجودی روی آن اعمال می‌شود.
**اصل ۱-ب — سایر کالاها خودکار ساخته می‌شوند:** هر کالای غیرگوشی که در تأمین‌کننده موجود و دارای قیمت باشد و هنوز در سایت نباشد (تبلت، کنسول، لوازم جانبی، ...) خودکار ساخته و قیمت‌گذاری می‌شود (شناسه‌ی `prod-auto-...`). اگر مدیر یکی از آن‌ها را حذف کند، دوباره ساخته نمی‌شود (`data/supplier_ignored.json`). خاموش‌کردن: `autoCreateFromSuppliers: false` در `data/settings.json`. این کالاها اگر در تأمین‌کننده ناموجود شوند در سایت هم ناموجود می‌شوند. کالاهای قبلی هرگز حذف یا جابه‌جا نمی‌شوند.

**اصل ۲ — تطبیق بر پایه‌ی «هویت کالا»، نه شباهت نام:** برای هر کالا (و هر ردیف تأمین‌کننده) این مشخصه‌ها خوانده می‌شود: برند، مدل، نسخه‌ی مدل (Pro / Ultra / FE / Plus / Slim ...)، رم، حافظه، شبکه 4G/5G، سیم‌کارت، پارت‌نامبر، ریجن، پردازنده، گرافیک و اندازه‌ی صفحه. دو کالا فقط وقتی یکی‌اند که **همه‌ی مشخصه‌های مشترک برابر** باشد:
- A57 رم ۸ با A57 رم ۱۲، یا A57 با A57 FE / A56 / A57 Ultra هرگز یکی نمی‌شوند.
- اگر کالای شما رم یا حافظه دارد ولی تأمین‌کننده ننوشته، قیمت اعمال **نمی‌شود** و ردیف به «نیازمند بررسی» می‌رود.
- شبکه و سیم‌کارت «نرم»‌اند: اگر تأمین‌کننده ننوشته ولی ردیف هم‌خانواده‌ی 4G/5G دیگری هم دارد، مبهم است؛ در غیر این صورت پذیرفته می‌شود.
- لوازم جانبی (قاب، گلس، شارژر...) هیچ‌وقت جای دستگاه نمی‌نشیند.
- مشخصه‌ی جدید و ناشناخته: فایل اختیاری `data/matching-rules.json` را بسازید (نمونه پایین) تا مشخصه‌های بیشتری اجباری شوند.

**اصل ۳ — قیمت و موجودی:**
- قیمت هر رنگ = بالاترین قیمت میان همه‌ی تأمین‌کننده‌هایی که آن رنگ را **موجود** دارند × (۱ + `supplierMarkupPercent`٪)، پیش‌فرض ۵٪.
- رنگ‌ها بر اساس معنی تطبیق می‌خورند («Navy» = «سرمه‌ای»). رنگ مبهم یا ناشناخته هرگز قیمت نمی‌گیرد و باعث ناموجود شدن رنگ‌های شما هم نمی‌شود.
- رنگی فقط وقتی ناموجود می‌شود که همه‌ی رنگ‌های موجود تأمین‌کننده شناسایی شده باشد و هیچ تأمین‌کننده‌ی فعالی خطا نداده باشد.
- اگر قیمت جدید حدود ۱۰ برابر (یا یک‌دهم) قیمت فعلی باشد (احتمالاً اشتباه تأمین‌کننده)، اعمال نمی‌شود و در «نیازمند بررسی» می‌آید. جهش‌های عادی (حتی بیش از ۳۰٪) اعمال می‌شوند.
- همه‌ی قیمت‌های تأمین‌کننده‌ها «تومان» فرض می‌شوند و هیچ تبدیل ریال/تومانی انجام نمی‌شود.
- تأیید دستی مدیر («تأیید تطبیق» در پنل تأمین‌کنندگان) پذیرفته می‌شود، مگر مشخصات صریحاً متناقض باشد.

نمونه‌ی `data/matching-rules.json` (همه‌ی کلیدها اختیاری):
```json
{
  "requiredIfMasterHas": ["ram", "storage", "part", "region", "cpu", "gpu", "screen"],
  "softFields": ["network", "sim"],
  "requiredByCategory": { "phone": ["ram", "storage"], "laptop": ["ram", "storage", "cpu"] },
  "identityLabels": ["نوع پنل"]
}
```

## ثبت هوشمند چندمنبعی (v1.9.0)

ثبت هوشمند به دیجی‌کالا وابسته نیست. ورودی: نام کالا (فارسی/انگلیسی، مثل «سامسونگ A57 12/256») و/یا **لینک صفحه‌ی محصول هر فروشگاه**. منابع (همه موازی و اختیاری):
1. دیجی‌کالا
2. لینک واردشده (JSON-LD، متا و جدول مشخصات هر سایت)
3. کاتالوگ تأمین‌کننده‌ها (فقط به‌عنوان شاهد؛ کالایی از آن ساخته نمی‌شود)
4. Gemini با جستجوی گوگل — فقط اگر `GEMINI_API_KEY` تنظیم شده باشد (`GEMINI_MODEL` اختیاری)

هر شاهد با همان موتور هویت کالا با درخواست شما تطبیق داده می‌شود؛ شاهد با مدل/نسخه/رم/حافظه‌ی متفاوت رد می‌شود. رم و حافظه **هرگز پیش‌فرض** نمی‌شوند: اگر ننوشته باشید و چند نسخه وجود داشته باشد، نسخه‌ها فهرست می‌شوند تا انتخاب کنید.

## اجرا و ذخیره‌سازی

- اجرا: `npm install` سپس `npm start` (پورت ۳۰۰۰).
- داده‌ها فایل‌های JSON در پوشه‌ی `data/` هستند. برای هاست دائمی، مسیر دیسک پایدار را با `PUZZLEKALA_DATA_DIR` بدهید.
- تست‌ها: `npm test`.


## نسخه اصلاحی 1.9.2 — بررسی ایمنی اولیه

- موجودی پیش‌فرض ساختگی ۱۰ عددی حذف شد؛ نبود داده موجودی دیگر نباید به‌تنهایی موجودی مثبت بسازد.
- کالاهایی که ایجنت از منابع تأمین‌کننده کشف می‌کند به‌صورت پیش‌نویس غیرفعال و غیرقابل سفارش ثبت می‌شوند تا مدیر آن‌ها را بررسی کند.
- ثبت‌نام مشتری اکنون کد ملی ۱۰ رقمی و شماره تماس با طول معتبر را الزامی می‌کند. تأیید پیامکی هنوز پیاده‌سازی/پیکربندی نشده است و شماره به‌عنوان تأییدشده علامت نمی‌خورد.
- هزینه ارسال ارسالی از مرورگر دیگر پذیرفته نمی‌شود؛ تا زمان پیکربندی محاسبه امن سمت سرور، فقط مبلغ صفر پذیرفته می‌شود. این محدودیت موقت است و قبل از فروش واقعی باید با قواعد ارسال جایگزین شود.
- ثبت و لغو سفارش در Audit Log ثبت می‌شود؛ مشتری فقط سفارش خودش را در مرحله بررسی می‌تواند لغو کند و لغو هرگز به‌معنای تأیید بازپرداخت نیست.
- ویرایش عمومی سفارش توسط مدیر دیگر نمی‌تواند مبلغ، اقلام یا وضعیت پرداخت را از همان مسیر عمومی تغییر دهد.

**وضعیت اعتبارسنجی:** این ZIP یک مرحله اصلاحی است، نه تأیید آمادگی برای فروش واقعی. در محیط فعلی نصب وابستگی‌ها در زمان مجاز کامل نشد؛ بنابراین build و آزمون‌های خودکار هنوز اجرا و تأیید نشده‌اند. قبل از راه‌اندازی باید OTP پیامکی، درگاه پرداخت واقعی و تأیید server-to-server، پایگاه داده پایدار، نشانی‌های ذخیره‌شده، قوانین ارسال، بازپرداخت، نقش‌ها و تست انتها‌به‌انتها تکمیل و بررسی شوند.


## Project handoff\n\nSee [HANDOFF-1.9.2.md](./HANDOFF-1.9.2.md) for the changes in this archive, operational boundaries, and remaining work mapped from the Puzzle Kala specification.\n

## نسخه 1.9.3 — تکمیل منطق سفارش

- `POST /api/orders/quote` برای محاسبه قیمت نهایی در سمت سرور (قیمت کالا، ارسال و تخفیف معتبر).
- `GET/POST /api/account/addresses` برای مدیریت نشانی‌های ذخیره‌شده مشتری. برای POST مقدار `action` یکی از `add`, `update`, `delete`, `default` است.
- `GET/POST /api/returns` و `PUT /api/returns/:id` برای ثبت و رسیدگی به درخواست مرجوعی.
- همگام‌سازی گروهی سفارش‌ها نباید سوابق پرداخت/بازپرداخت یا سفارش‌های غایب در payload را حذف کند.

اتصال پیامک OTP و درگاه پرداخت واقعی عمداً به‌عنوان اتصال آماده/فعال ادعا نشده است؛ انتخاب سرویس و تنظیم محرمانه آن لازم است. آزمون هاست به مرحله انتقال پروژه موکول شده است.


## Release 1.9.6

See `HANDOFF-1.9.6.md` for the release delta, validation status, and remaining production prerequisites. Repeated return-status updates are now no-op operations and do not generate duplicate audit events.


## نسخه 1.9.7 — ایمنی موجودی و پاک‌سازی مدیریتی
- قیمت منفی/نامعتبر به صفر نرمال می‌شود؛ موجودی منفی یا کسری به موجودی قابل فروش تبدیل نمی‌شود.
- مقدار رشته‌ای `false` برای فعال‌بودن کالا دیگر به‌اشتباه `true` تفسیر نمی‌شود.
- پاک‌سازی داده‌های عملیاتی در پنل مدیریت نیازمند عبارت تأیید صریح و دلیل است؛ پیش از پاک‌سازی، نسخه پشتیبان timestampدار تهیه می‌شود و در صورت شکست نوشتن فایل‌ها، بازگردانی best-effort انجام می‌شود.
- ورودی تصاویر مرجوعی محدود به URL HTTPS یا مسیر محلی `/uploads/` می‌شود.


## نسخه 1.9.8 — ایمنی ثبت هوشمند کالا
- تطبیق شاهد اکنون مشخصات صریح رم و حافظه را از جدول مشخصات صفحه محصول هم می‌خواند.
- اگر مدیر نسخه مشخصی با رم/حافظه معین درخواست کند، شاهدی که این مشخصات را در عنوان یا مشخصات ساختاریافته ندارد، برای جلوگیری از انتساب رنگ/عکس/مشخصات نسخه اشتباه رد می‌شود.
- در فرم ثبت هوشمند، رنگ فرضی «مشکی»، قیمت پیش‌فرض و موجودی پیش‌فرض حذف شدند؛ اطلاعاتی که منبع ثابت نکرده باید توسط مدیر تعیین شود.
- اعتبارسنجی build و تست TypeScript در این بسته هنوز تأیید نشده؛ وابستگی‌ها در محیط ساخت نصب نشدند.


## نسخه 1.10.0 — بررسی شواهد متناقض ثبت هوشمند

ثبت هوشمند اکنون اختلاف مقادیر یک ویژگی میان منابع تأییدشده را در `meta.evidenceConflicts` گزارش می‌کند و کالا را برای بررسی مدیر علامت می‌زند. هیچ مقدار متناقضی بی‌صدا به‌عنوان مقدار قطعی انتخاب نمی‌شود. جزئیات پروژه‌های عمومی بررسی‌شده و محدودیت تست در `HANDOFF-1.10.0.md` آمده است.


## نسخه 1.11.0 — پیش‌نمایش امن همگام‌سازی تأمین‌کنندگان

- مسیر مدیریتی `POST /api/suppliers/sync-preview` همان دریافت و تطبیق کاتالوگ را اجرا می‌کند و تغییرات پیشنهادی را با `plannedChanges` برمی‌گرداند؛ این مسیر نباید فایل‌های داده، گزارش‌های دائمی یا اعلان‌های همگام‌سازی را تغییر دهد.
- مسیر عادی `POST /api/suppliers/sync` و `POST /api/suppliers/sync-all` همچنان همگام‌سازی واقعی انجام می‌دهند.
- این پیش‌نمایش برای بازبینی مدیر است؛ نتیجه آن مجوز خودکار برای تغییر داده‌ها یا سفارش‌گذاری نیست.
- تست مخصوص عدم تغییر فایل‌ها در حالت preview اضافه شده است؛ اجرای کامل تست‌ها/build هنوز انجام نشده و باید پس از نصب روی محیط مناسب اجرا شود.


## نسخه 1.12.2 — ممیزی سرتاسری و اصلاح خطاهای بین‌بخشی

- اصلاح ذخیره‌سازی محصولات: عملیات گروهی و ثبت/ویرایش کالای داخلی دیگر محصولات مدیریت‌شده توسط تأمین‌کنندگان را از `products.json` حذف نمی‌کند.
- جلوگیری از پذیرفته‌شدن شناسهٔ تأمین‌کننده به‌عنوان شناسهٔ کالای داخلی و جلوگیری از ویرایش مستقیم کالای تأمین‌کننده از مسیر ویرایش کالای داخلی.
- اعتبارسنجی تعداد سفارش: تعداد باید عدد صحیح باشد و تکرار یک شناسهٔ کالا در چند ردیف نیز در برابر موجودی جمع زده می‌شود.
- اگر تعرفه‌های ارسال صریح تعریف شده باشند، روش نامعتبر دیگر به هزینهٔ ارسال قدیمی سقوط نمی‌کند.
- ثبت هوشمند: دنبال‌کردن redirect برای نشانی‌های بیرونی غیرفعال شد؛ دریافت تصویر محدود به قالب‌های تصویری raster مجاز و حداکثر ۸ مگابایت است؛ اگر `sharp` نصب نباشد، پسوند فایل با قالب واقعی تصویر هماهنگ می‌شود.
- دستیار خرید: موجودی گزینه‌های رنگ از `variants[].options` نیز بررسی می‌شود و دیگر وضعیت تأمین‌کننده را به‌اشتباه «آماده تحویل از انبار» معرفی نمی‌کند.
- ذخیره‌سازی فایل JSON: نام فایل موقت در نوشتن هم‌زمان یکتا شد؛ JSON خراب/خالی قبل از استفاده از مقدار جایگزین به فایل بازیابی‌شدنی منتقل می‌شود؛ فیلدهای حساس در فرادادهٔ گزارش حسابرسی به‌صورت بازگشتی حذف می‌شوند.
- تست‌های تازه برای تعداد سفارش، موجودی رنگ‌ها و محدودیت URL افزوده شد.

## نسخه 1.12.1 — اصلاح ثبت تاریخچه در کاتالوگ بزرگ

- اصلاح: ثبت تاریخچه اکنون از مجموعه کامل تغییرات استفاده می‌کند؛ محدودیت ۵۰۰ مورد فقط برای پاسخ پیش‌نمایش است و دیگر رویدادهای تاریخچه را پس از مورد ۵۰۰ حذف نمی‌کند.
- اصلاح آزمون dry-run: فایل تاریخچه قیمت/موجودی نیز در بررسی عدم‌تغییر فایل‌ها گنجانده شد.

## نسخه 1.12.0 — تاریخچه قیمت/موجودی و علامت‌گذاری تغییرات غیرعادی

- تغییرات قیمت و موجودی محصولات/رنگ‌ها پس از همگام‌سازی موفق در فایل افزایشی `data/supplier_price_stock_history.json` ثبت می‌شود (حداکثر ۵۰۰۰ رویداد اخیر).
- تغییر قیمت بیش از ۳۰٪ نسبت به مقدار قبلی به‌عنوان مورد نیازمند بررسی مدیر علامت می‌خورد؛ این علامت به‌تنهایی سفارش را لغو نمی‌کند و اعلان خودکار نمی‌فرستد.
- مسیر مدیر `GET /api/suppliers/price-stock-history` تاریخچه را برمی‌گرداند و فیلترهای اختیاری `productId`، `supplierId`، `anomaliesOnly=true` و `limit` (۱ تا ۵۰۰) را می‌پذیرد.
- پیش‌نمایش همگام‌سازی (`POST /api/suppliers/sync-preview`) تاریخچه را تغییر نمی‌دهد.
- داده‌های تاریخی روی دیسک پایدار نگهداری شوند؛ اگر هاست فایل‌ها را در استقرار پاک می‌کند، `PUZZLEKALA_DATA_DIR` باید به فضای پایدار اشاره کند.
- اعتبارسنجی کامل تست/ساخت و آزمون روی هاست در این مرحله اجرا نشده است.

## نسخه 1.12.3 — اصلاحات ادامه ممیزی امنیتی

- پاک‌سازی بازگشتی فیلدهای حساس در تنظیمات، کاربران، کالاها و خروجی دستیار خرید به تابع مشترک `src/securitySanitizers.ts` منتقل شد.
- طول رمز ورودی در ورود و ثبت‌نام محدود به حداکثر ۲۵۶ نویسه شد.
- محدودکننده درخواست احراز هویت در برابر رشد بی‌حد Map محافظت بیشتری دارد.
- گزارش یافته‌ها و محدودیت‌های باقی‌مانده: `docs/audits/AUDIT-REPORT-v1.12.3-FA.md`.
- تست‌های جدید sanitizer با Node test runner موفق‌اند؛ build/lint کامل به دلیل نبود `vite/client` در محیط ممیزی تأیید نشده است.


## نسخه 1.12.4 — اصلاحات تکمیلی ممیزی

- پاک‌سازی عمیق اطلاعات حساس در حد عمق بازگشت اکنون fail-closed است و در مرز عمق، شیء اصلی را بازنمی‌گرداند.
- خروجی کالاهای پیشنهادی دستیار خرید از projection عمومی کالا عبور می‌کند تا فیلدهای داخلی قیمت/تأمین‌کننده افشا نشوند.
- تست‌های بازگشت اطلاعات محرمانه در ساختار بسیار تو‌در‌تو و حذف فیلدهای داخلی خروجی دستیار افزوده شد.

## نسخه 1.12.4 — تکمیل ممیزی امنیتی

- خروجی عمومی دستیار خرید اکنون از projection امن محصول عبور می‌کند تا اطلاعات داخلی قیمت/تأمین‌کننده افشا نشود.
- پاک‌سازی اطلاعات حساس در عمق بیش از ۱۲ سطح به‌صورت fail-closed عمل می‌کند.
- گزارش یافته و محدودیت اعتبارسنجی: `docs/audits/AUDIT-REPORT-v1.12.4-FA.md`.

## نسخه 1.12.5 — محدودسازی حافظه rate-limit

- حافظهٔ محدودکنندهٔ درخواست دستیار و ثبت هوشمند اکنون سقف سخت دارد و هنگام فشار، ورودی‌های قدیمی‌تر را حذف می‌کند.
- ثبت هوشمند دیگر توکن Authorization خام را به‌عنوان کلید حافظه نگه نمی‌دارد؛ محدودسازی بر اساس IP درخواست انجام می‌شود.

### 1.12.6 — Static code review corrections
- Coupon dates with malformed values now fail closed.
- Public coupon responses omit internal usage counters/limits; admin responses retain full coupon records.
- Admin order status updates enforce forward-only lifecycle transitions.
- Ticket updates validate allowed fields/statuses and bound reply length.
- Static review changes are not a substitute for production/integration testing.
- Assistant rate-limit buckets are pruned rather than globally cleared when the map grows.


### 1.12.7 — Final static review fixes
- Recursively remove supplier-only pricing/matching fields from public product responses.
- Detect prefixed/camelCase secret field names such as `adminPassword`, `supplierPassword`, `googleApiKey` and `sessionTokenHash`.
- Block ordinary cancellation of shipped/delivered orders and prevent full-refund action from treating partial refunds as full refunds.
- Validate wallet adjustment target and resulting balance; use UUID transaction IDs and best-effort rollback on ledger-write failure.
- Validate coupon codes/types/values/usage counters and replace prior coupon by case-insensitive code.
- Respect a valid `PORT` environment variable; production now fails clearly if the Vite `dist/` build is missing instead of serving uncompiled TSX.
- See `docs/audits/AUDIT-REPORT-v1.12.7-FA.md` for scope and remaining limitations.


## v1.12.8 — API hardening
- Public settings now use an explicit allowlist and sanitized public projections for shipping tiers and quick shortcuts.
- Admin order creation validates order item count, monetary bounds, ID uniqueness, and initial status.
- Legacy order sync rejects duplicate/invalid IDs, invalid statuses and invalid new order snapshots; existing order sync updates only operational metadata and permitted status transitions while preserving immutable/financial fields.
- Order updates now use an explicit mutable-field allowlist rather than a denylist.
- These are static code changes; deployment-level payment, browser and concurrency tests remain separate.

## v1.12.8 — Order/API hardening
- Public settings endpoint uses an explicit allowlist and safe projections.
- Admin order creation and legacy SyncBridge order creation validate item counts, IDs, statuses, and monetary snapshots.
- Existing-order SyncBridge updates preserve immutable financial/customer snapshots and only permit operational metadata plus valid status transitions.
- Order update endpoint uses an explicit mutable-field allowlist.
- Added unit tests for order workflow transitions and monetary consistency.
- 59 transpile-based tests passed; official `tsc --noEmit`/Vite build remains unverified because `vite/client` types are unavailable in the environment.


## v1.12.9 — Final static review and order snapshot hardening (2026-10-26)

- Added strict validation for manual/SyncBridge order-item snapshots: product identifier, integer quantity, positive finite unit price, line count, subtotal consistency, and safe numeric bounds.
- Admin-created and SyncBridge-created orders now store explicit `discountAmount` and `shippingFee` values even when they default to zero.
- Customer checkout now checks order-write success and does not silently ignore coupon usage-write failure. On coupon state/write failure, the route attempts to restore the prior order list and logs whether rollback succeeded.
- Full manual refund action now requires a cancelled order or an order already marked as awaiting refund, in addition to the existing paid-status and duplicate-refund checks.
- Coupon creation validates percentage discounts (maximum 100%), minimum order values, date syntax and date order.
- Critical order/return/ticket write paths now check the JSON writer result before reporting success.
- Added snapshot validation tests. All 60 repository tests passed using TypeScript `transpileModule` output and Node's test runner. This is not a substitute for official Vite build/type-check or deployed integration testing.

Known limitations remain: JSON storage is not a multi-file transactional database; coupon/order updates cannot be made fully atomic across processes with the current storage design. The official `tsc --noEmit` command is blocked in this environment because `vite/client` type definitions are not installed.


## نسخه اختصاصی کسری پلاس (1.13.2-kasra-live)

در این نسخه، شناسهٔ کالاهای واردشدهٔ خودکار در شناسهٔ عمومی نام تأمین‌کننده را ندارند؛ کلیدهای داخلی تطبیق تأمین‌کننده فقط برای همگام‌سازی مدیر نگه‌داری می‌شوند و از پاسخ عمومی محصول حذف می‌شوند.


- این بسته فقط تأمین‌کننده «کسری پلاس» را فعال نگه می‌دارد؛ تأمین‌کننده‌های دیگر از فهرست عملیاتی حذف می‌شوند.
- در هر چرخه همگام‌سازی (به‌صورت پیش‌فرض هر ۵ دقیقه)، کاتالوگ زنده کسری پلاس دریافت می‌شود.
- کالاهای دارای قیمت معتبر و موجودی تأییدشده، از جمله گوشی موبایل، به‌صورت خودکار به سایت افزوده و فعال/موجود می‌شوند.
- قیمت اولیه بر اساس قیمت کسری پلاس به‌علاوه درصد مصوب تنظیمات (پیش‌فرض ۵٪) محاسبه می‌شود؛ افزایش فقط یک‌بار اعمال می‌شود.
- اگر دریافت کاتالوگ با خطا مواجه شود، وضعیت قبلی حفظ می‌شود. اگر در دریافت موفق، کالای خودکار قبلی دیگر در فید نباشد، ناموجود می‌شود و حذف نمی‌شود.
- این همگام‌سازی «نزدیک به لحظه‌ای» است و در حالت پیش‌فرض حداکثر تا چرخه بعدی (۵ دقیقه) تغییر را منعکس می‌کند؛ همگام‌سازی ثانیه‌ای نیازمند webhook یا قابلیت push از سمت کسری پلاس است.


## نسخه 1.14.0 — کسری پلاس + هدیش

- نسخهٔ مستقل کسری پلاس حفظ شده و هدیش به‌عنوان تأمین‌کنندهٔ دوم اضافه شده است.
- کالاهای هدیش از نقشهٔ سایت و صفحات محصول خوانده می‌شوند؛ گوشی‌های آیفون هدیش حذف می‌شوند.
- برای کالاهای بدون قیمت واقعی، قیمت جایگزین یا ساختگی تولید نمی‌شود.
- کالاهای دارای قیمت ولی ناموجود نیز در دادهٔ فروشگاه ثبت می‌شوند و ناموجود می‌مانند.
- وضعیت و آمار هدیش از مسیرهای مدیریتی `/api/ehadish/status` و `/api/ehadish/stats` قابل بررسی است؛ اجرای همگام‌سازی فوری از `/api/ehadish/sync-now` ممکن است.
- توضیحات و محدودیت‌های استقرار در `HANDOFF-1.14.0-kasra-ehadish.md` آمده است.


## نسخه 1.14.1 — اصلاحات پس از عیب‌یابی

- اگر نشانی محصول هدیش شناسهٔ عددی نداشته باشد، از کلید پایدار مبتنی بر مسیر URL استفاده می‌شود تا کالا بی‌دلیل حذف نشود.
- تشخیص موجودی هدیش اصلاح شد: وضعیت ناموجود در بخش موجودی بررسی می‌شود و دکمهٔ غیرفعال افزودن به سبد، موجودی مثبت تلقی نمی‌شود.
- آزمون‌های جدید برای این حالت‌ها اضافه شدند.
- آزمون‌های خودکار موجود با اجرای محیطی مستقل: 56 از 56 موفق. ساخت نهایی Vite و اتصال زنده به هدیش/کسری در این محیط تأیید نشده‌اند.


## نسخه 1.14.2 — ورود کامل کاتالوگ و آمار دقیق داشبورد

- کسری پلاس و هدیش از یک قاعدهٔ مشترک ورود استفاده می‌کنند: تمام ردیف‌های قابل‌شناسایی کاتالوگ ثبت می‌شوند؛ کالای ناموجود با موجودی صفر ثبت می‌شود و کالای بدون قیمت واقعی فقط برای بررسی مدیر ثبت و غیرفعال می‌ماند.
- تنها استثنای هدیش، تمام گوشی‌های موبایل (آیفون و اندروید) است؛ لوازم جانبی گوشی، لپ‌تاپ و سایر کالاها حذف نمی‌شوند. این فیلتر در همگام‌سازی مرکزی نیز اعمال می‌شود.
- دریافت نقشهٔ سایت هدیش به‌صورت بازگشتی انجام می‌شود؛ اگر صفحه‌ای از کاتالوگ دریافت نشود یا اطلاعات اصلی محصول قابل‌خواندن نباشد، همگام‌سازی کامل اعلام نمی‌شود و وضعیت قبلی حفظ می‌شود.
- داشبورد خلاصهٔ هر تأمین‌کننده را نشان می‌دهد: کل نشانی‌های کالای منبع، کالاهای واجد شرایط ورود، کالاهای ثبت‌شده، تعداد موجود/ناموجود، کالاهای نیازمند قیمت و تعداد گوشی‌های هدیش که عمداً حذف شده‌اند.
- افزایش قیمت مصوب فقط یک‌بار اعمال می‌شود؛ اطلاعات تأمین‌کنندهٔ داخلی در شناسهٔ عمومی کالا افشا نمی‌شود.
- آزمون‌های خودکار در اجرای ایزولهٔ TypeScript transpile شده: 56 از 56 موفق. ساخت رسمی Vite و اتصال زندهٔ تأمین‌کنندگان در این محیط تأیید نشده است.


## نسخهٔ 1.14.3 — اصلاح همگام‌سازی، قیمت/موجودی، منبع کالا و دسته‌بندی

- کاتالوگ هدیش از طریق `robots.txt` و چند مسیر استاندارد نقشهٔ سایت کشف می‌شود؛ اگر دریافت نقشه یا صفحات ناقص باشد، همگام‌سازی کامل اعلام نمی‌شود.
- استخراج قیمت هدیش از متا تگ‌ها، JSON-LD و ساختارهای رایج قیمت گسترش یافت.
- استخراج قیمت کسری‌پلاس فیلدهای متداول بیشتر را پوشش می‌دهد.
- موجودی واقعی منبع از وجود قیمت جدا شد؛ کالای بدون قیمت برای بررسی مدیر ثبت می‌شود اما قابل فروش نیست.
- کالاهای خودکار موجود در همگام‌سازی بعدی به‌روزرسانی می‌شوند؛ قیمت صفر/قدیمی، وضعیت موجودی و نام منبع داخلی اصلاح می‌شود.
- داشبورد و جزئیات شامل کالاهای واردشده و رنگ‌های ثبت‌شده نیز می‌شود.
- دسته‌بندی فروشگاهی با شناسه‌های مورد استفادهٔ فروشگاه (`cat-mobile-accessories`، `cat-computer-accessories` و غیره) ذخیره می‌شود تا لوازم جانبی در دستهٔ گوشی نمایش داده نشود.
- آزمون‌های خودکار: 60 مورد موفق.
- محدودیت: ساخت نهایی Vite و اتصال زندهٔ تأمین‌کنندگان در این محیط تأیید نشده است.
